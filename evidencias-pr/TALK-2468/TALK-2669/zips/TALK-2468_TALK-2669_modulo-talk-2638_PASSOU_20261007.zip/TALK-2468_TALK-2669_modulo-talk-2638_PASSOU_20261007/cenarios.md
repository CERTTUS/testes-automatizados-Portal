# Cenários — Landing portal — tema e contrato (TALK-2666)

## 1. API

### CT-API-01 — Landing com tokens derivados
- **Dado** um link de portal válido
- **Quando** o BFF responde com `oTokensDerivados` (`--cor-primaria`, etc.)
- **Então** o envelope HTTP é 200 e o corpo inclui os tokens CSS

### CT-API-02 — Landing sem tokens (fail-open)
- **Dado** um link de portal válido
- **Quando** o BFF responde só com nome fantasia e logo
- **Então** HTTP 200 e landing segue utilizável (sem quebrar por ausência de tema)

## 2. Smoke automatizado

### CT-SMK-01 — Tela de acesso com marca
- **Dado** link válido aberto no navegador
- **Quando** a landing carrega
- **Então** aparece o nome da oficina e o formulário de telefone + botão Acessar

### CT-SMK-02 — Tema aplicado na landing
- **Dado** BFF retorna tokens de cor
- **Quando** a landing carrega
- **Então** o wrapper da página aplica as variáveis CSS (cores visíveis no escopo da rota)

### CT-SMK-03 — Link revogado sem formulário
- **Dado** um link revogado
- **Quando** o cliente abre o link
- **Então** vê mensagem de indisponível e não aparece formulário de telefone

### CT-SMK-04 — Shell autenticado com menu (TALK-2669 / D4_v2)
- **Dado** sessão válida no portal
- **Quando** o cliente abre a ordem de serviço autenticada
- **Então** vê barra superior com nome da oficina, abas Ordem de serviço e Boleto, e botão Sair
- **Cobre:** `devKey` TALK-2669 — layout pós-login

## 3. E2E — Caminho feliz

[GAP — WU Teste]

## 4. E2E — Caminho negativo

[GAP — WU Teste]

## 5. Manual (somente UI)

[GAP]
