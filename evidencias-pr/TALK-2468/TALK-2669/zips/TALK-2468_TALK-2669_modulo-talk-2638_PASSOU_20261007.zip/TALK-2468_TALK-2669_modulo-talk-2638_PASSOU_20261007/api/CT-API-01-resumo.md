# CT-API-01

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/portal/xK9mP2nQ4rS6tU8vW0yZ12
- **Prova:** resposta da API conforme cenário.
