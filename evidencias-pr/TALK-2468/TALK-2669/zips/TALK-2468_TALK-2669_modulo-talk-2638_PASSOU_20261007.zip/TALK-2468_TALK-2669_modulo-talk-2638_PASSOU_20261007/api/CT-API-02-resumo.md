# CT-API-02

- **HTTP:** 410
- **URL:** http://127.0.0.1:3333/portal/tokRevogadoXXXXXXXXXXXX
- **Prova:** resposta da API conforme cenário.
