# LEIA-ME — Evidências QA_PRE_CR

Percorra os PNG na ordem numérica (`01-`, `02-`, …, `99-tela-final`).

| CT | Pasta | Sequência | O que cada imagem mostra |
|----|-------|-----------|--------------------------|
| CT-SMK-01 | `smoke/prints/CT-SMK-01/` | 01-landing-marca.png, 02-formulario-acesso.png, 99-tela-final.png, pontual-01-landing-marca.png, pontual-02-formulario-acesso.png, pontual-tela-final.png | landing marca → formulario acesso → tela final do CT → pontual 01 landing marca → pontual 02 formulario acesso → pontual tela final |
| CT-SMK-02 | `smoke/prints/CT-SMK-02/` | 01-wrapper-tema.png, 02-cor-primaria-aplicada.png, 99-tela-final.png, pontual-01-wrapper-tema.png, pontual-02-cor-primaria-aplicada.png, pontual-tela-final.png | wrapper tema → cor primaria aplicada → tela final do CT → pontual 01 wrapper tema → pontual 02 cor primaria aplicada → pontual tela final |
| CT-SMK-03 | `smoke/prints/CT-SMK-03/` | 01-link-revogado.png, 02-sem-formulario.png, 99-tela-final.png, pontual-01-link-revogado.png, pontual-02-sem-formulario.png, pontual-tela-final.png | link revogado → sem formulario → tela final do CT → pontual 01 link revogado → pontual 02 sem formulario → pontual tela final |
| CT-SMK-04 | `smoke/prints/CT-SMK-04/` | 01-shell-autenticado.png, 02-menu-os-boleto-sair.png, 99-tela-final.png, pontual-01-shell-autenticado.png, pontual-02-menu-os-boleto-sair.png, pontual-tela-final.png | shell autenticado → menu os boleto sair → tela final do CT → pontual 01 shell autenticado → pontual 02 menu os boleto sair → pontual tela final |

## API

- **CT-API-01:** `api/CT-API-01-response.json` + `api/CT-API-01-resumo.md`
- **CT-API-02:** `api/CT-API-02-response.json` + `api/CT-API-02-resumo.md`
