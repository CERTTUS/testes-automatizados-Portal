# resultado-execucao-dev

> Dev: `TALK-2669` | HU: `TALK-2468` | Módulo: `modulo-talk-2638`
> Data: 2026-10-07T16:25:36.240Z

Veredito: **PASSOU**

Comando: `npm run test:pre-cr (specs) -- --modulo modulo-talk-2638 --dev-key TALK-2669 --parent-key TALK-2468`
Ambiente: `local`

---

## O que foi testado (linguagem de tela)

- CT-API-01 — Landing com tokens derivados
- CT-API-02 — Landing sem tokens (fail-open)
- CT-SMK-01 — Tela de acesso com marca
- CT-SMK-02 — Tema aplicado na landing
- CT-SMK-03 — Link revogado sem formulário
- CT-SMK-04 — Shell autenticado com menu (TALK-2669 / D4_v2)

E2E e checklist manual: WU Teste (não executados neste hop).

---

## Resumo

| Métrica | Valor |
|---------|-------|
| Jest | 0 com prova |
| API | 2 com prova |
| Smoke | 4 com prova |
| Duração | — |

---

## Evidências por CT (obrigatório no PASS)

| CT | Tipo | Status | Arquivo de prova |
|----|------|--------|------------------|
| CT-API-01 | api | PASSOU | `api/CT-API-01-response.json` |
| CT-API-02 | api | PASSOU | `api/CT-API-02-response.json` |
| CT-SMK-01 | smoke | PASSOU | `smoke/prints/CT-SMK-01/99-tela-final.png` |
| CT-SMK-02 | smoke | PASSOU | `smoke/prints/CT-SMK-02/99-tela-final.png` |
| CT-SMK-03 | smoke | PASSOU | `smoke/prints/CT-SMK-03/99-tela-final.png` |
| CT-SMK-04 | smoke | PASSOU | `smoke/prints/CT-SMK-04/99-tela-final.png` |
