# CT-API-09

- **HTTP:** 200
- **URL:** http://127.0.0.1:13333/portal/tokLogoHorizontalT3105
- **Prova:** resposta da API conforme cenário.
