# CT-API-15

- **HTTP:** 200
- **URL:** http://127.0.0.1:13333/cliente/os/tokLogoHorizontalT3105
- **Prova:** resposta da API conforme cenário.
