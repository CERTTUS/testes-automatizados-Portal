# CT-API-10

- **HTTP:** 200
- **URL:** http://127.0.0.1:13333/portal/tokSemLogoOficinaT3105
- **Prova:** resposta da API conforme cenário.
