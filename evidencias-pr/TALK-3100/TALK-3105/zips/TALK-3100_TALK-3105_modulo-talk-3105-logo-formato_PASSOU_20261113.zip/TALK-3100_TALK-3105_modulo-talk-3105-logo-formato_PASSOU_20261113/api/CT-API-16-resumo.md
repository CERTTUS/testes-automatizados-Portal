# CT-API-16

- **HTTP:** 200
- **URL:** http://127.0.0.1:13333/cliente/os/tokSemLogoOficinaT3105
- **Prova:** resposta da API conforme cenário.
