# LEIA-ME — Evidências QA_PRE_CR

Percorra os PNG na ordem numérica (`01-`, `02-`, …, `99-tela-final`).

| CT | Pasta | Sequência | O que cada imagem mostra |
|----|-------|-----------|--------------------------|
| CT-API-09 | `api/` | CT-API-09-response.json, CT-API-09-resumo.md | resposta da API + resumo do CT |
| CT-API-10 | `api/` | CT-API-10-response.json, CT-API-10-resumo.md | resposta da API + resumo do CT |
| CT-API-15 | `api/` | CT-API-15-response.json, CT-API-15-resumo.md | resposta da API + resumo do CT |
| CT-API-16 | `api/` | CT-API-16-response.json, CT-API-16-resumo.md | resposta da API + resumo do CT |

## API

- **CT-API-09:** `api/CT-API-09-response.json` + `api/CT-API-09-resumo.md`
- **CT-API-10:** `api/CT-API-10-response.json` + `api/CT-API-10-resumo.md`
- **CT-API-15:** `api/CT-API-15-response.json` + `api/CT-API-15-resumo.md`
- **CT-API-16:** `api/CT-API-16-response.json` + `api/CT-API-16-resumo.md`
