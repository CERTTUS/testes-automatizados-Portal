# Cenários de teste — `modulo-talk-3105-logo-formato`

> Produto: **Portal do Cliente** (`portal`) · repo de testes `testes-automatizados-Portal`
> História (parentKey): **TALK-3100** · Dev do hop: **TALK-3105** · subtarefa Cenários: **TALK-3102** (Concluído - Aprovado; CT-MAN-06/07/08 importados por título, ver § 5)
> Base: `contexto-pr.md` (passo 1) e `jest-validacao.md` (passo 0)
> Pipeline: **QA_PRE_CR** (hop Dev) · modo `api-smoke` · `proibidoE2e: true`
> `cenariosOrigem: gerado-na-dev` + herdados de `modulo-talk-3103-cor-texto-elementos/cenarios.md` (CT-API-09 e CT-API-10, escritos lá como `pendente-irma:TALK-3105`; ajustados aqui para a entrega real)
> Stack deste hop: **Vitest (produto) + API (Playwright projeto `api`)**. Smoke e E2E ficam para a WU Teste.
> Formato: **Título → Descrição → Cenário (BDD)** · passos no **infinitivo**
> Data: 2026-11-12

## Legenda

| Tag | Significado |
|-----|-------------|
| **[EXISTE]** | Já automatizado (spec ou teste existente) |
| **[NOVO]** | Cenário novo — candidato a automação (passo 4, depois do gate) |
| **[HERDADO]** | Escrito no módulo da irmã TALK-3103 como `pendente-irma:TALK-3105`; passa a ser deste módulo, com o texto ajustado |
| **[IMPORTADO]** | Vem da subtarefa Cenários TALK-3102 (MeloQA); manual, executado na WU Teste |

**Modalidades:** `manual` · `automacao-api` · `automacao-playwright` · `jest`
**Prioridade:** P0 · P1 · P2
**Exige stub:** `sim` = o automatizador acrescenta massa em `scripts/qa/stub-ms-portal-landing.mjs` (repo de testes) antes do spec; `não` = roda com o stub de hoje.

**Classificação humano x runner** (rule `qa-automacao-sem-humano`): todos os CT-API abaixo vão até PASS sem ninguém interagir. É HTTP direto no BFF, com massa do stub MS (8087) e, nos CTs de detalhe, sessão aberta por `obterCookiePortalSessao` (login por telefone com o número autorizado do stub). Os CT-MAN da TALK-3102 dependem de subir arquivo no editor do Talk e olhar a tela: ficam em `## 5. Manual`.

---

## 0. Escopo e inventário do pai

### Entrega deste hop (TALK-3105)

- Diff do produto (`portalcliente-web`, branch `feat/TALK-3100-cores-logo-portal`, working tree não commitado): **só CSS** em `src/styles/autenticado-d4.css`. Menu do topo da O.S.: logo com altura 40px e largura automática até `min(160px, 40vw)` (antes, caixa 40x40). Esqueleto do menu fixo em 40px. Rodapé: altura 48px, largura automática até 160px, `flex-shrink: 0`. Login sem mudança (caixa 90% x 130px com `contain`).
- O Talk recorta a logo em Quadrada (1:1, 1024x1024) ou Horizontal (3:1, 1200x400). **Nenhum campo novo de API**; o BFF, o MS e o talk-api **não mudaram**. Os CTs de API são o **contrato da logo** (RN6 do `contexto-pr.md`): landing `GET /portal/{token}` entrega `lTemLogo` e `cLogoUrl` iguais aos do MS, e o detalhe `GET /cliente/os/{id}` entrega `oBranding.cLogoUrl` igual.
- **A API não diz a medida da logo.** A largura/altura por região (RN2–RN5) está provada no Vitest (tabela abaixo) e nos prints do Dev. Nenhum CT tenta provar a medida pela resposta do BFF.
- O recorte no editor do Talk (talk-web, mesma Dev) está fora deste módulo (outro produto e outro repo de testes).

### Inventário do pai (HARNESS_MULTI_DEV_PR)

| Dev | Assunto | Código na branch do Portal | CTs |
|-----|---------|----------------------------|-----|
| TALK-3103 | Cor do texto em cada elemento | sim (commitado, `7f908d2`/`09e2f3f`) | CT-API-01..08 e 12..14 em `modulo-talk-3103-cor-texto-elementos` — **PASSOU** (QA_PRE_CR concluído) |
| TALK-3104 | Componente próprio de input de cor (em paralelo) | não | CT-API-11 `pendente-irma:TALK-3104` em `modulo-talk-3103-cor-texto-elementos`. Não muda aqui |
| **TALK-3105** | Logo quadrada ou horizontal sem limitar a altura | sim (working tree) | **CT-API-09, 10, 15, 16** deste arquivo. Contam para o PASSOU da TALK-3105. CT-MAN-06/07/08 na § 5 |

> **IDs:** CT-API-09 e CT-API-10 mantêm o número que receberam no módulo da TALK-3103 (rastreabilidade). Os CTs novos do detalhe usam **CT-API-15 e CT-API-16** para não colidir com 01..14 do pai. Próxima Dev do pai (TALK-3104) começa em CT-API-17.

### Vitest do produto (passo 0) — regras de CSS já cobertas por unitário, sem CT novo

| Ref | Arquivo (`portalcliente-web`) | O que prova | Regras |
|-----|-------------------------------|-------------|--------|
| JEST-T3105-01 | `src/styles/__tests__/logoOficinaProporcaoCss.test.ts` (novo, 4) | menu do topo: `width: auto`, `height: 40px`, `max-width: min(160px, 40vw)`, `contain`, sem `width: 40px`; esqueleto com `width: 40px`; rodapé: `width: auto`, `height: 48px`, `max-width: 160px`, `contain`, `flex-shrink: 0`, sem `width: 48px`; login mantém `contain` e altura 130px | RN2, RN3, RN4, RN5 |
| JEST-T3105-02 | `MenuTopoPortal.test.tsx` (3), `RodapeOficinaPortal.test.tsx` (10), `CabecalhoMarcaAcesso.test.tsx` (2) | regressão dos componentes que desenham a logo (sem mudança de código); rodapé com `cLogoUrl` preenchido e vazio | regressão |

**Status:** **[EXISTE]** PASSOU (alvo 7 arquivos / 40 testes; suíte completa 54 / 422; `tsc --noEmit` OK). Limite: o jsdom não faz layout nem carrega imagem; o Vitest prova as regras de CSS, não a medida pintada. Medidas reais nos prints do Dev: `/Users/eduardoceron/Dev2/talk-teste-automatizado/evidencias-pr/TALK-3100/dev-TALK-3105/design/index.md` (menu 120x40 com logo horizontal, 40x40 com quadrada; login 288x130 nos dois).

### Massa e ambiente (para o automatizador)

- Base: `E2E_API_BASE_URL` (BFF direto). BFF local com `API_MICROSERVICOS_BASE_URL=http://127.0.0.1:8087` e `node scripts/qa/stub-ms-portal-landing.mjs` rodando. Telefone autorizado: `QA_STUB_TELEFONE_AUTORIZADO` (padrão `5511999999999`), só nos CTs de detalhe.
- Helpers: `tests/api/modulo-in-946-login-telefone/loginD1Api.ts` (`respostaApiLer`, `cookieHeaderDe`), `tests/e2e/helpers/portalAcessoApiHelpers.ts` (`obterCookiePortalSessao`), `tests/e2e/helpers/env` (`E2E_API_BASE_URL`). Modelo: `tests/api/modulo-talk-3103-cor-texto-elementos/` (`landingLer`/`detalheLer` no spec + constantes em `corTextoElementosApi.ts`).
- Spec: `tests/api/modulo-talk-3105-logo-formato/CT-API-logo-formato.spec.ts` (novo). Constantes de token e URL num helper junto do spec (ex.: `logoFormatoApi.ts`).
- **Comparação:** `cLogoUrl` igual **byte a byte** (`toBe`) à string que o stub manda — domínio, caminho e query string. Nada de `toContain` nem normalização.

### Mudança no stub pedida por CT-API-09, 10, 15 e 16 (o automatizador faz no passo 4)

Arquivo: `scripts/qa/stub-ms-portal-landing.mjs` (repo de testes, não é código de produto). **Acrescentar** 2 tokens; não mexer nos existentes nem em `O_BASE` / `oDetalheOs`. Cada token entra em `M_POR_TOKEN` (landing; entra sozinho em `M_TOKENS_COM_OS`, o que libera login por telefone e detalhe) **e** em `M_TEMA_DETALHE_POR_TOKEN` (detalhe). O `oDetalheOs` já espalha o objeto do token sobre a base, então basta pôr `oBranding` na entrada — a função não muda.

| Token (≤ 64) | Landing (`M_POR_TOKEN`) | Detalhe (`M_TEMA_DETALHE_POR_TOKEN`) | Usado em |
|--------------|-------------------------|--------------------------------------|----------|
| `tokLogoHorizontalT3105` (obrigatório) | `cNomeFantasia: "Oficina Logo Horizontal"`, `cCorPrimaria: "#1a5276"`, `cTemaModo: "claro"`, `lTemLogo: true`, `cLogoUrl: "https://cdn.sistema.certtus.com.br/tenantteste/0001/portal-cliente/logo-horizontal.png?v=20261112"` (sobrescreve o `O_BASE`) | `cCorPrimaria: "#1a5276"`, `cTemaModo: "claro"`, `oBranding: { cLogoUrl: <mesma URL>, cNomeFantasia: "Oficina Logo Horizontal" }` | CT-API-09, CT-API-15 |
| `tokSemLogoOficinaT3105` | `cNomeFantasia: "Oficina Sem Logo"`, `cCorPrimaria: "#1a5276"`, `cTemaModo: "claro"` (herda `lTemLogo: false`, `cLogoUrl: ""` do `O_BASE`) | `cCorPrimaria: "#1a5276"`, `cTemaModo: "claro"`, `oBranding: { cLogoUrl: "", cNomeFantasia: "Oficina Sem Logo" }` (igual ao MS real sem logo) | CT-API-10, CT-API-16 |

A URL usa o domínio do CDN aceito no `next.config.ts` (`cdn.sistema.certtus.com.br`) e uma query string de versão, para o CT provar que o BFF não reescreve nem corta a URL. A imagem não precisa existir: o BFF não busca o arquivo.

---

## 1. API

### CT-API-09 — Landing entrega a logo horizontal da oficina como foi enviada

**Descrição:**
Validar que a landing de um portal com logo horizontal devolve `lTemLogo: true` e `cLogoUrl` idêntico ao do MS, sem o BFF reescrever, redimensionar ou cortar a URL. É a URL que o login usa para mostrar a logo inteira na caixa de 130px.

**Tag:** [HERDADO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokLogoHorizontalT3105`)
**Cobre:** tela `/{token}` (logo do login, `CabecalhoMarcaAcesso`) → `GET /portal/{token}` · TALK-3105 (RN6, RN7)

**Cenário de teste:**

```gherkin
Cenário: Logo horizontal da oficina chega intacta na landing
  Dado ter um link público de portal de oficina com logo horizontal cadastrada
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.lTemLogo igual a true
  E retornar oDados.cLogoUrl igual à URL da logo cadastrada, com o mesmo domínio, caminho e query string
  Mas não retornar em oDados nenhum campo de formato ou medida da logo
```

---

### CT-API-10 — Landing de portal sem logo não inventa imagem

**Descrição:**
Validar que a landing de um portal sem logo devolve `lTemLogo: false` e `cLogoUrl` vazio, para o portal mostrar a imagem padrão no lugar.

**Tag:** [HERDADO] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokSemLogoOficinaT3105`; sem ele, roda com `xK9mP2nQ4rS6tU8vW0yZ12`, que já herda `O_BASE` sem logo)
**Cobre:** tela `/{token}` → `GET /portal/{token}` · TALK-3105 (RN6)

**Cenário de teste:**

```gherkin
Cenário: Portal sem logo não recebe URL de imagem
  Dado ter um link público de portal de oficina sem logo cadastrada
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.lTemLogo igual a false
  E retornar oDados.cLogoUrl igual a ""
```

---

### CT-API-15 — Detalhe da O.S. entrega a mesma logo da landing

**Descrição:**
Validar que o detalhe da O.S. entrega em `oBranding.cLogoUrl` a mesma URL de logo que a landing, sem reescrever. É a URL que o menu do topo (altura 40px) e o rodapé (altura 48px) usam com a nova largura automática.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokLogoHorizontalT3105`)
**Cobre:** tela `/os/{cOsPublicId}` (menu do topo `.portal-nav-top__logo` e rodapé `.portal-rodape-oficina__logo`) → `GET /cliente/os/{id}` · TALK-3105 (RN6)

**Cenário de teste:**

```gherkin
Cenário: Logo horizontal chega intacta no detalhe da O.S.
  Dado ter uma sessão do portal aberta para uma O.S. de oficina com logo horizontal cadastrada
  E ter lido a URL da logo na landing desse mesmo link
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.oBranding.cLogoUrl igual à URL da logo lida na landing
  E retornar oDados.oOrdemServico.oBranding.cNomeFantasia igual a "Oficina Logo Horizontal"
```

---

### CT-API-16 — Detalhe da O.S. de oficina sem logo entrega URL vazia

**Descrição:**
Validar que o detalhe da O.S. de uma oficina sem logo entrega `oBranding.cLogoUrl` vazio (como o MS real manda), sem erro e sem URL inventada. O menu e o rodapé mostram a imagem padrão.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokSemLogoOficinaT3105`)
**Cobre:** tela `/os/{cOsPublicId}` → `GET /cliente/os/{id}` · TALK-3105 (RN6)

**Cenário de teste:**

```gherkin
Cenário: Detalhe da O.S. sem logo não recebe URL de imagem
  Dado ter uma sessão do portal aberta para uma O.S. de oficina sem logo cadastrada
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.oBranding.cLogoUrl igual a ""
  E retornar oDados.oOrdemServico.oBranding.cNomeFantasia igual a "Oficina Sem Logo"
```

---

## 2. Smoke automatizado

N/A neste hop (WU Teste). `qa-pre-cr`: proibido gerar ou rodar `CT-SMK-*`.

---

## 3. E2E — Caminho feliz

N/A neste hop (WU Teste). Proibido gerar `CT-E2E-*` e percorrer login/O.S. por MCP (rule `qa-pre-cr-sem-e2e`).

---

## 4. E2E — Caminho negativo

N/A neste hop (WU Teste).

---

## 5. Manual (somente UI)

Importados da subtarefa Cenários **TALK-3102** (MeloQA, pasta "Cores e logo"). O título é o da TALK-3102; o Gherkin abaixo é o recorte do **Portal** escrito neste hop (o Gherkin completo, incluindo o editor do Talk, está no MeloQA). Modalidade `manual`: dependem de escolher e subir um arquivo no editor do Talk e de olhar a tela. Executados na **WU Teste**; não contam para o PASSOU deste hop.

### CT-MAN-06 — Logo vertical alta sem limitação indevida de altura

**Descrição:**
Validar que uma logo alta (mais alta que larga), recortada no Talk como Quadrada, aparece inteira no portal: sem corte, sem distorção e sem ser espremida numa faixa baixa. O título vem da TALK-3102, escrito antes da decisão Quadrada/Horizontal.

**Tag:** [IMPORTADO] · **Prioridade:** P1 · **Modalidade:** `manual`
**Cobre:** editor do Talk (recorte) + telas `/{token}` e `/os/{id}` · TALK-3105

**Cenário de teste:**

```gherkin
Cenário: Logo alta aparece inteira no portal
  Dado estar no editor de aparência do Portal do Cliente no Talk com perfil de administrador
  Quando escolher uma imagem de logo mais alta que larga
  E confirmar o recorte no formato Quadrada
  E salvar a personalização
  E abrir o link público do portal
  Então exibir no login a logo inteira, sem corte e sem distorção
  E exibir no menu do topo da O.S. a logo inteira em 40 x 40, com a sobra transparente
  E exibir no rodapé da O.S. a logo inteira com 48 de altura
```

---

### CT-MAN-07 — Logo no preview Talk e no portal público após salvar

**Descrição:**
Validar que a logo horizontal escolhida no Talk aparece igual no preview do editor e no portal público depois de salvar: no menu do topo larga (cerca de 120 x 40), e não mais espremida num quadrado de 40 x 40.

**Tag:** [IMPORTADO] · **Prioridade:** P1 · **Modalidade:** `manual`
**Cobre:** preview do editor do Talk + telas `/{token}` e `/os/{id}` (menu do topo e rodapé) · TALK-3105

**Cenário de teste:**

```gherkin
Cenário: Logo horizontal igual no preview e no portal público
  Dado estar no editor de aparência do Portal do Cliente no Talk com perfil de administrador
  Quando escolher uma imagem de logo larga
  E confirmar o recorte no formato Horizontal
  E conferir a logo no preview do editor
  E salvar a personalização
  E abrir o link público do portal e entrar na O.S.
  Então exibir no login a logo horizontal inteira, centralizada na caixa da marca
  E exibir no menu do topo a logo com 40 de altura e largura proporcional, sem passar de 160
  E exibir no rodapé a logo com 48 de altura e largura proporcional, sem passar de 160
  Mas não exibir a logo horizontal espremida num quadrado de 40 x 40
```

---

### CT-MAN-08 — Persistência de cores e logo após recarregar

**Descrição:**
Validar que, depois de salvar, as cores e a logo continuam as mesmas ao recarregar o editor e o portal. Compartilhado com a TALK-3103 (cores); aqui vale o recorte da logo.

**Tag:** [IMPORTADO] · **Prioridade:** P2 · **Modalidade:** `manual`
**Cobre:** editor do Talk + telas `/{token}` e `/os/{id}` · TALK-3103 / TALK-3105

**Cenário de teste:**

```gherkin
Cenário: Logo e cores continuam iguais depois de recarregar
  Dado ter salvo no Talk uma logo no formato Horizontal e cores personalizadas
  Quando recarregar a página do editor
  E recarregar o login e a O.S. do portal público
  Então exibir no editor a mesma logo no formato Horizontal e as mesmas cores
  E exibir no portal a mesma logo, com a mesma proporção no login, no menu do topo e no rodapé
  E exibir no portal as mesmas cores salvas
```

---

## 6. Sugestões para a WU Teste (não são CTs deste hop)

1. **Medida por região** em `/preview?logo=<url>` (login e O.S.) com logo horizontal 1200x400 e quadrada 1024x1024: `getBoundingClientRect()` da logo no menu (120x40 / 40x40), no rodapé (144x48 / 48x48) e no login (caixa 90% x 130px com a imagem inteira). Prints de referência do Dev em `/Users/eduardoceron/Dev2/talk-teste-automatizado/evidencias-pr/TALK-3100/dev-TALK-3105/design/`.
2. **Celular 390px:** menu (teto 40vw = 156px) e rodapé com logo horizontal e nome de oficina longo, sem rolagem horizontal. O rodapé no celular não tem print.
3. **Logos salvas antes do recorte:** muito larga (> 4:1) bate no teto e fica com altura menor; vertical alta fica ~13x40 no menu (igual a antes).
4. **Esqueleto do menu** (carregando a marca): placeholder 40x40, sem colapsar.
5. **Com BFF real + stub novo:** login e O.S. de `tokLogoHorizontalT3105` com a logo larga; `tokSemLogoOficinaT3105` com a imagem padrão.

---

## Observações para o revisor / CR (não são bugs da TALK-3105)

1. **CT-MAN-06 (título "vertical alta")** foi escrito antes da decisão Quadrada/Horizontal. No Talk novo a logo alta vira Quadrada com sobra transparente; o Gherkin de portal acima segue essa decisão. Conferir com o MeloQA na WU Teste.
2. **Salto de layout pequeno:** o `next/image` reserva 40x40 / 48x48 antes de a imagem carregar e depois alarga. Só visual.
3. O recorte no editor (talk-web, mesma Dev) precisa de cobertura no pré-CR do Talk; não está neste módulo. Os 3 prints do editor (janela "Ajustar logo" em Quadrada e Horizontal, miniatura larga) estão pendentes no `index.md` do Dev.

## Pendências

- **TALK-3102 (subtarefa Cenários):** não sincronizada com estes CTs. Nenhuma mutação no Jira neste passo.
- **Stub:** 2 tokens novos (`tokLogoHorizontalT3105`, `tokSemLogoOficinaT3105`) entram no passo 4, junto com o spec, depois do gate.
- **Módulo da TALK-3103:** CT-API-09/10 lá continuam marcados `pendente-irma:TALK-3105`; a execução real passa a ser deste módulo (atualizar a nota lá no passo 4, se o automatizador mexer no arquivo — este passo não edita o módulo da irmã).

---

## Resumo

| Categoria | Qtde | Exige stub | Plataforma |
|-----------|------|------------|------------|
| API TALK-3105 — landing `GET /portal/{token}` (CT-API-09, 10) | 2 (P0 feliz, P1 negativo) | sim | BFF `portalcliente-api` |
| API TALK-3105 — detalhe `GET /cliente/os/{id}` (CT-API-15, 16) | 2 (P0 feliz, P1 negativo) | sim | BFF `portalcliente-api` |
| Vitest | referência (alvo 40 testes, suíte 422 PASSOU, sem CT novo) | — | `portalcliente-web` |
| Manual importado TALK-3102 (CT-MAN-06, 07, 08) | 3 (WU Teste) | — | Talk + portal |
| Smoke / E2E | 0 — N/A neste hop | — | — |
| **Total CT-API** | 4 (todos contam para o PASSOU da TALK-3105) | — | — |

Par feliz + negativo por endpoint: `GET /portal/{token}` → CT-API-09 / CT-API-10. `GET /cliente/os/{id}` → CT-API-15 / CT-API-16 (401/403 do detalhe já cobertos em `modulo-in-948-cards-os`; 400/404 da landing em `modulo-in-949-tema-rodape`).

> **Aguardando aprovação humana** no gate `aprovar_cenarios_pre_cr` antes de seguir para a automação (`qa-automatizador`, passo 4). Os CTs novos ficam com execução `pendente` até lá.
