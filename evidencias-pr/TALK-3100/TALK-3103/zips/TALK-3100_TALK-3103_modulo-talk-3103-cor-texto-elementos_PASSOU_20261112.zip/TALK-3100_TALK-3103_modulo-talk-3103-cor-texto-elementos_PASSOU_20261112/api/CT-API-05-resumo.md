# CT-API-05

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/cliente/os/tokTextoPersonalizadoT3103
- **Prova:** resposta da API conforme cenário.
