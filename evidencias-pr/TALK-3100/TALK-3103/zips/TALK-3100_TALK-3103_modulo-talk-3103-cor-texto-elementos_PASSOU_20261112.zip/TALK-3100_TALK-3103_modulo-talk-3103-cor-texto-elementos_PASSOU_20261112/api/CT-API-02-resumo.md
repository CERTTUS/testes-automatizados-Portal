# CT-API-02

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/portal/tokTextoAutomaticoT3103
- **Prova:** resposta da API conforme cenário.
