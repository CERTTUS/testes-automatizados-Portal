# CT-API-13

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/cliente/os/tokCardsSeparadosT3103
- **Prova:** resposta da API conforme cenário.
