# CT-API-14

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/portal/tokCardsSeparadosT3103
- **Prova:** resposta da API conforme cenário.
