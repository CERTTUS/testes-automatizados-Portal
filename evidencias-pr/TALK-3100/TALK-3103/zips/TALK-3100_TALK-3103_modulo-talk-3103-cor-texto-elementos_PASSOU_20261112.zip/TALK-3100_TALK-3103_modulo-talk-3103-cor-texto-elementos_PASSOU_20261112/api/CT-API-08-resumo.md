# CT-API-08

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/cliente/os/tokTextoInvalidoT3103
- **Prova:** resposta da API conforme cenário.
