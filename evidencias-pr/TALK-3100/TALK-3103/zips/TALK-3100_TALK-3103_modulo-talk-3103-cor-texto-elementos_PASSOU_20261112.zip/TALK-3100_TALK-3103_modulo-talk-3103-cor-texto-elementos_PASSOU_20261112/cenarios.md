# Cenários de teste — `modulo-talk-3103-cor-texto-elementos`

> Produto: **Portal do Cliente** (`portal`) · repo de testes `testes-automatizados-Portal`
> História (parentKey): **TALK-3100** · Dev do hop: **TALK-3103** · subtarefa Cenários: **TALK-3102** (Concluído - Aprovado, achada por JQL no passo 1; ninguém mexeu no Jira, ver Pendências)
> Base: `contexto-pr.md` (passo 1) e `jest-validacao.md` (passo 0)
> Pipeline: **QA_PRE_CR** (hop Dev) · modo `api-smoke` · `proibidoE2e: true`
> `cenariosOrigem: gerado-na-dev` (sem CTs importados de subtarefa HU nem MeloQA; o placeholder do bootstrap foi substituído)
> Stack deste hop: **Vitest (produto) + API (Playwright projeto `api`)**. Smoke e E2E ficam para a WU Teste.
> Formato: **Título → Descrição → Cenário (BDD)** · passos no **infinitivo**
> Data: 2026-11-12

## Legenda

| Tag | Significado |
|-----|-------------|
| **[EXISTE]** | Já automatizado (spec existente) |
| **[NOVO]** | Cenário novo — candidato a automação (passo 4, depois do gate) |
| **[PENDENTE-IRMA]** | CT de Dev irmã sem código na branch; escrito agora, executa quando a irmã entrar (`pendente-irma:<key>`, não bloqueia o PASSOU deste hop) |

**Modalidades:** `manual` · `automacao-api` · `automacao-playwright` · `jest`
**Prioridade:** P0 · P1 · P2
**Exige stub:** `sim` = o automatizador acrescenta massa em `scripts/qa/stub-ms-portal-landing.mjs` (repo de testes) antes do spec; `não` = roda com o stub de hoje.

**Classificação humano x runner** (rule `qa-automacao-sem-humano`): todos os CT-API abaixo vão até PASS sem ninguém interagir. É HTTP direto no BFF, com massa do stub MS (8087) e, nos CTs de detalhe, sessão aberta por `obterCookiePortalSessao` (login por telefone com o número autorizado do stub). Nenhum depende de OTP, câmera ou diálogo.

---

## 0. Escopo e inventário do pai

### Entrega deste hop (TALK-3103)

- Diff do produto (`portalcliente-web`, branch `feat/TALK-3100-cores-logo-portal`, working tree não commitado): **só front**. O tema avançado ganha cor de texto por elemento (`loginBotaoTexto`, `authCabecalhoTexto`, `authFundoTexto`, `authCardTexto`, `authRodapeTexto`, `acaoDestaqueTexto`; `loginTexto` só no login). O portal gera um token de texto por região e o CSS de cada região redefine `--text-*`. Regra: informado → `loginTexto` antigo se legível (≥ 4,5:1) → automático (`#171717`/`#fafafa`).
- O BFF (`portalcliente-api`), o MS e o talk-api **não mudaram**: repassam o objeto. Os CTs de API são o **contrato de tema com as chaves novas** (RN9 do `contexto-pr.md`): landing `GET /portal/{token}` e detalhe `GET /cliente/os/{id}` entregam `oTemaAvancado` com as chaves novas (e `null`) intactas + `cTemaModo`; tema antigo sem as chaves continua igual.
- **A API não diz que cor de texto aparece.** A resolução por região (RN2–RN8) está provada no Vitest (tabela abaixo). Nenhum CT tenta provar a cor pela resposta do BFF.
- O editor do Talk (talk-web, mesma Dev) está fora deste módulo (outro produto e outro repo de testes).

### Inventário do pai (HARNESS_MULTI_DEV_PR)

| Dev | Assunto | Código na branch do Portal | CTs |
|-----|---------|----------------------------|-----|
| **TALK-3103** | Cor do texto em cada elemento | sim (working tree) | **CT-API-01..08** deste arquivo. Contam para o PASSOU da TALK-3103 |
| TALK-3104 | Componente próprio de input de cor (A Fazer) | não | **CT-API-11** `pendente-irma:TALK-3104` (cor gravada fora de `#RRGGBB`). A tela do input é do Talk (talk-web), sem superfície no Portal além do valor gravado |
| TALK-3105 | Input da logo sem limitar a altura (A Fazer) | não | **CT-API-09, CT-API-10** `pendente-irma:TALK-3105` (contrato da logo na landing). Revisar quando a TALK-3105 for planejada |

> PT **TALK-3101** está A Fazer: `tasks[]` não conferido. As irmãs não têm description técnica; os CTs delas são o contrato mínimo do Portal e podem ser ajustados no hop delas (o arquivo é aditivo).

### Vitest do produto (passo 0; delta: 53 arquivos / 418 testes PASS — herança das 6 superfícies, tom sutil, CSS por superfície sem auto-referência, cenário cards-separados) — regras do front já cobertas por unitário, sem CT novo

| Ref | Arquivo (`portalcliente-web`) | O que prova | Regras |
|-----|-------------------------------|-------------|--------|
| JEST-T3103-01 | `src/services/__tests__/temaTextoElemento.test.ts` (novo, 6) | automático pelo maior contraste; informado respeitado mesmo ilegível; legado legível mantido; legado ilegível → automático; `null`/inválido = ausente; sentinelas `#171717`/`#fafafa` | RN2, RN3, RN8 |
| JEST-T3103-02 | `src/services/__tests__/temaProducaoDerivar.test.ts` (+8) | modo simples igual (claro e escuro); login de fundo escuro com `loginTexto #171717` → `#fafafa`; informado por região vira o token; `null` = automático; botão e destaque informados; sem eles, regra antiga; legado `#E0E0E0` com card branco → card `#171717`, login `#e0e0e0`; só chave de texto ativa o avançado | RN1–RN7 |
| JEST-T3103-03 | `src/services/__tests__/marcaCerttusVariante.test.ts` (+4) | com token de texto da região, nenhuma cor inline (rodapé e login), respeita escolha ilegível, token da outra superfície não vale | RN2 (rodapé/assinatura) |
| JEST-T3103-04 | `src/components/organisms/__tests__/RodapeOficinaPortal.test.tsx` (+1) | com o texto da região resolvido, nome da oficina sem `style` inline | RN2 |
| JEST-T3103-05 | `src/services/__tests__/previewCenariosOs.test.ts` (+1, +3 `it.each`) | cenários `texto-automatico-escuro`, `texto-personalizado`, `texto-legado` | apoio à WU Teste |

**Status:** **[EXISTE]** PASSOU (51 arquivos, 399 testes, 0 falhas; `tsc --noEmit` OK). Limite: o jsdom não calcula variáveis CSS; o Vitest prova os tokens, não a cor pintada (WU Teste, seção 6). CSS por região, `Botao`, `TimelineItem` e `AbasDetalheOs` não têm unitário (lacuna L1/L2 do `cobertura-diff.md`).

### Massa e ambiente (para o automatizador)

- Base: `E2E_API_BASE_URL` (BFF direto). BFF local com `API_MICROSERVICOS_BASE_URL=http://127.0.0.1:8087` e `node scripts/qa/stub-ms-portal-landing.mjs` rodando, **sem** `QA_STUB_TEMA_CRU=1`. Telefone autorizado: `QA_STUB_TELEFONE_AUTORIZADO` (padrão `5511999999999`), só nos CTs de detalhe.
- Helpers: `tests/api/modulo-in-946-login-telefone/loginD1Api.ts` (`respostaApiLer`, `cookieHeaderDe`), `tests/e2e/helpers/portalAcessoApiHelpers.ts` (`obterCookiePortalSessao`), `tests/e2e/helpers/env` (`E2E_API_BASE_URL`). Modelo: `tests/api/modulo-in-949-tema-rodape/` (spec + `temaRodapeApi.ts`).
- Spec: `tests/api/modulo-talk-3103-cor-texto-elementos/CT-API-cor-texto-elementos.spec.ts` (novo). Constantes de token num helper junto do spec.
- **Comparação:** `oTemaAvancado` da resposta deve ser **igual em profundidade** (`toEqual`) ao objeto que o stub manda — mesmas chaves, mesmos valores, mesma caixa (o BFF não normaliza `#FFD166` para minúsculas), `null` como `null`.

### Mudança no stub pedida por CT-API-01..08 (o automatizador faz no passo 4)

Arquivo: `scripts/qa/stub-ms-portal-landing.mjs` (repo de testes, não é código de produto). Acrescentar 4 tokens em `M_POR_TOKEN` (landing; entra sozinho em `M_TOKENS_COM_OS`) **e** em `M_TEMA_DETALHE_POR_TOKEN` (detalhe). Não mexer nos tokens existentes. Todos com `cCorPrimaria: "#1a5276"` e `cTemaModo: "claro"`.

| Token (≤ 64) | `oTemaAvancado` (landing **e** detalhe) | Extra no detalhe | Usado em |
|--------------|------------------------------------------|------------------|----------|
| `tokTextoPersonalizadoT3103` | igual ao cenário de preview `texto-personalizado`: `editor: "avancado"`, `loginFundo "#FFF7E6"`, `loginTexto "#7A2E00"`, `loginBotao "#7A2E00"`, `loginBotaoTexto "#FFE8CC"`, `authCabecalho "#0F3D73"`, `authCabecalhoTexto "#FFD166"`, `authFundo "#F4F4F4"`, `authFundoTexto "#1B4332"`, `authCard "#FFFFFF"`, `authCardTexto "#5A189A"`, `authRodape "#1B4332"`, `authRodapeTexto "#D8F3DC"`, `acaoDestaque "#C1121F"`, `acaoDestaqueTexto "#FFF1F2"` | `oTokensDerivados: {"--portal-os-card-texto": "#000000", "--text-primary": "#000000"}` (o BFF deve descartar) | CT-API-01, CT-API-05 |
| `tokTextoAutomaticoT3103` | `editor: "avancado"`, `loginFundo "#0F3D73"`, `authCabecalho "#1C1C1C"`, `authFundo "#262626"`, `authCard "#0F3D73"`, `authRodape "#1C1C1C"`, `loginTexto "#171717"` (sentinela) e as 6 chaves novas = `null` | — | CT-API-02, CT-API-06 |
| `tokTextoLegadoT3103` | tema salvo antes da mudança (cenário `texto-legado`): `editor: "avancado"`, `loginTexto "#E0E0E0"`, `loginFundo "#171717"`, `authCabecalho "#1C1C1C"`, `authFundo "#262626"`, `authCard "#FFFFFF"`, `authRodape "#1C1C1C"`; **nenhuma** chave `*Texto` nova | — | CT-API-03, CT-API-07 |
| `tokTextoInvalidoT3103` | `editor: "avancado"`, `authCard "#FFFFFF"`, `authCardTexto "roxo"`, `authRodapeTexto "#12345"`, `acaoDestaqueTexto "rgb(255, 0, 0)"` | — | CT-API-04, CT-API-08 |

`cNomeFantasia` livre por token (ex.: "Oficina Texto Personalizado"). Os CTs pendentes das irmãs (09..11) pedem massa própria, que fica para o hop delas.

---

## 1. API

**Funcionalidade:** Tema do portal com cor de texto por elemento — contrato do BFF (landing e detalhe da O.S.) para a TALK-3103

### CT-API-01 — Landing entrega as cores de texto de cada elemento como foram salvas

**Descrição:**
Validar que a landing de um portal com cor de texto definida em todos os elementos do avançado devolve `oTemaAvancado` idêntico ao do MS: as 6 chaves novas, o `loginTexto` e as cores de fundo, sem trocar caixa nem formato, e `cTemaModo` como veio. É a entrada do login (texto, botão Acessar e campo).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoPersonalizadoT3103`)
**Cobre:** tela `/{token}` (`landingPortalCarregar` → `temaProducaoDerivar` → `--portal-login-texto`, `--portal-login-botao-texto`, `--portal-os-card-texto` no campo) → `GET /portal/{token}` (schema `.passthrough()`, `oTemaAvancado` record) · TALK-3103 (RN1, RN9)
**Por que importa:** se o BFF perder ou alterar uma chave `*Texto`, o portal cai no automático e ignora a cor escolhida pela oficina.

**Cenário de teste:**

```gherkin
Cenário: Cores de texto de cada elemento chegam inteiras na landing
  Dado ter um link público de portal em tema claro com cor de texto definida no login, no botão Acessar, no cabeçalho, no fundo, no card, no rodapé e no destaque
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.cTemaModo igual a "claro"
  E retornar oDados.oTemaAvancado igual ao tema avançado gravado, com loginBotaoTexto "#FFE8CC", authCabecalhoTexto "#FFD166", authFundoTexto "#1B4332", authCardTexto "#5A189A", authRodapeTexto "#D8F3DC", acaoDestaqueTexto "#FFF1F2" e loginTexto "#7A2E00"
```

---

### CT-API-02 — Landing com textos em automático entrega as chaves com valor nulo

**Descrição:**
Validar que, quando a oficina deixa o texto de cada elemento em automático (o Talk grava `null`), a landing devolve as 6 chaves novas presentes e iguais a `null` — não somem, não viram `""` nem `"null"` — e o `loginTexto` padrão (`#171717`) como veio. O portal trata `null` como automático e o `#171717` como não informado (corrige o login de fundo escuro).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoAutomaticoT3103`)
**Cobre:** tela `/{token}` (texto automático claro sobre `loginFundo #0F3D73`) → `GET /portal/{token}` (record aceita `null`) · TALK-3103 (RN1, RN3, RN9)
**Por que importa:** um `null` convertido em string vazia ou em `"null"` vira valor inválido; perdido, o comportamento é o mesmo, mas a troca de tipo pode quebrar o schema do front.

**Cenário de teste:**

```gherkin
Cenário: Textos automáticos chegam como nulos na landing
  Dado ter um link público de portal em tema claro com fundos escuros no avançado e todas as cores de texto em automático
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oTemaAvancado com loginBotaoTexto, authCabecalhoTexto, authFundoTexto, authCardTexto, authRodapeTexto e acaoDestaqueTexto presentes e iguais a null
  E retornar oDados.oTemaAvancado.loginTexto igual a "#171717"
  E retornar oDados.oTemaAvancado igual ao tema avançado gravado
```

---

### CT-API-03 — Landing de tema salvo antes da mudança continua igual

**Descrição:**
Validar que um tema avançado salvo antes da TALK-3103 (só `loginTexto`, sem as chaves novas) é entregue pela landing exatamente como estava, sem o BFF inventar chave `*Texto` nem preencher valor padrão. É o "manter as cores já salvas funcionando" da Dev.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoLegadoT3103`)
**Cobre:** tela `/{token}` (legado `#E0E0E0` legível sobre `#171717` mantido no login) → `GET /portal/{token}` · TALK-3103 (RN6, RN9)
**Por que importa:** se aparecer uma chave nova com valor padrão, o portal passa a tratar o tema antigo como "cor informada" e a regra do legado deixa de valer.

**Cenário de teste:**

```gherkin
Cenário: Tema antigo sem cor de texto por elemento chega igual na landing
  Dado ter um link público de portal com tema avançado salvo antes da cor de texto por elemento, só com a cor de texto do login "#E0E0E0"
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oTemaAvancado igual ao tema avançado gravado
  E retornar oDados.oTemaAvancado.loginTexto igual a "#E0E0E0"
  Mas não retornar em oDados.oTemaAvancado nenhuma das chaves loginBotaoTexto, authCabecalhoTexto, authFundoTexto, authCardTexto, authRodapeTexto e acaoDestaqueTexto
```

---

### CT-API-04 — Landing com cor de texto inválida é entregue sem quebrar a página

**Descrição:**
Validar que uma cor de texto fora de `#RRGGBB` (`"roxo"`, `"#12345"`, `"rgb(255, 0, 0)"`) não derruba a landing: o BFF responde 200 e repassa os valores como vieram. Quem ignora o valor é o portal, que cai no legado/automático (RN8, provado no Vitest).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoInvalidoT3103`)
**Cobre:** tela `/{token}` (texto inválido = automático) → `GET /portal/{token}` · TALK-3103 (RN8, RN9)
**Por que importa:** um valor mal gravado em um campo de texto não pode tirar o login do ar.

**Cenário de teste:**

```gherkin
Cenário: Cor de texto inválida não derruba a landing
  Dado ter um link público de portal com cor de texto do card "roxo", do rodapé "#12345" e do destaque "rgb(255, 0, 0)" no avançado
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oTemaAvancado.authCardTexto igual a "roxo"
  E retornar oDados.oTemaAvancado.authRodapeTexto igual a "#12345"
  E retornar oDados.oTemaAvancado.acaoDestaqueTexto igual a "rgb(255, 0, 0)"
```

---

### CT-API-05 — Detalhe da O.S. entrega as cores de texto e descarta tokens do MS

**Descrição:**
Validar que o detalhe da O.S. de um portal com cor de texto em todos os elementos devolve `cTemaModo` e `oTemaAvancado` idênticos ao MS, e **não** devolve `oTokensDerivados` mesmo quando o MS manda tokens de texto (`--portal-os-card-texto`, `--text-primary`). O cabeçalho, o fundo, os cards, as abas, o rodapé e o destaque da O.S. derivam o texto só dessas chaves.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoPersonalizadoT3103`, com tema e `oTokensDerivados` no detalhe)
**Cobre:** tela `/os/{cOsPublicId}` (`ConteudoDetalheOsAutenticado` → `temaProducaoDerivar` → tokens de região) → `GET /cliente/os/{id}` (`portalOsDetalheDadosMsSchema`, sem passthrough) · TALK-3103 (RN1, RN9)
**Por que importa:** se um token de texto do MS passasse, sobrescreveria a cor escolhida para o card.

**Cenário de teste:**

```gherkin
Cenário: Detalhe da O.S. entrega as cores de texto de cada elemento
  Dado ter uma sessão do portal aberta para uma O.S. de oficina em tema claro com cor de texto definida em cada elemento do avançado
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.cTemaModo igual a "claro"
  E retornar oDados.oOrdemServico.oTemaAvancado igual ao tema avançado gravado, com authCabecalhoTexto "#FFD166", authFundoTexto "#1B4332", authCardTexto "#5A189A", authRodapeTexto "#D8F3DC" e acaoDestaqueTexto "#FFF1F2"
  Mas não retornar oDados.oOrdemServico.oTokensDerivados
```

---

### CT-API-06 — Detalhe da O.S. com textos em automático entrega as chaves com valor nulo

**Descrição:**
Validar que o detalhe da O.S. devolve as 6 chaves novas presentes e iguais a `null` quando a oficina deixou o texto em automático. O schema do detalhe é fechado (sem passthrough), então este CT prova que o `null` passa pelo record.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoAutomaticoT3103`)
**Cobre:** tela `/os/{cOsPublicId}` (cabeçalho, fundo, cards e rodapé escuros com texto claro automático) → `GET /cliente/os/{id}` · TALK-3103 (RN1, RN9)

**Cenário de teste:**

```gherkin
Cenário: Textos automáticos chegam como nulos no detalhe da O.S.
  Dado ter uma sessão do portal aberta para uma O.S. de oficina com superfícies escuras no avançado e todas as cores de texto em automático
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.oTemaAvancado com loginBotaoTexto, authCabecalhoTexto, authFundoTexto, authCardTexto, authRodapeTexto e acaoDestaqueTexto presentes e iguais a null
  E retornar oDados.oOrdemServico.oTemaAvancado igual ao tema avançado gravado
```

---

### CT-API-07 — Detalhe da O.S. de tema salvo antes da mudança continua igual

**Descrição:**
Validar que o detalhe da O.S. entrega o tema antigo (só `loginTexto`) como estava, sem chaves novas. É dessa entrada que o portal decide manter o texto claro antigo onde é legível e trocar para escuro no card branco.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoLegadoT3103`)
**Cobre:** tela `/os/{cOsPublicId}` (legado no card branco → `#171717`) → `GET /cliente/os/{id}` · TALK-3103 (RN6, RN9)

**Cenário de teste:**

```gherkin
Cenário: Tema antigo chega igual no detalhe da O.S.
  Dado ter uma sessão do portal aberta para uma O.S. de oficina com tema avançado salvo antes da cor de texto por elemento
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.cTemaModo igual a "claro"
  E retornar oDados.oOrdemServico.oTemaAvancado igual ao tema avançado gravado
  Mas não retornar em oDados.oOrdemServico.oTemaAvancado nenhuma das chaves loginBotaoTexto, authCabecalhoTexto, authFundoTexto, authCardTexto, authRodapeTexto e acaoDestaqueTexto
```

---

### CT-API-08 — Detalhe da O.S. com cor de texto inválida é entregue sem quebrar

**Descrição:**
Validar que cores de texto fora de `#RRGGBB` não derrubam o detalhe da O.S.: 200 com os valores repassados como vieram. O portal ignora e usa o automático.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTextoInvalidoT3103`)
**Cobre:** tela `/os/{cOsPublicId}` → `GET /cliente/os/{id}` · TALK-3103 (RN8, RN9)

**Cenário de teste:**

```gherkin
Cenário: Cor de texto inválida não derruba o detalhe da O.S.
  Dado ter uma sessão do portal aberta para uma O.S. de oficina com cor de texto do card "roxo", do rodapé "#12345" e do destaque "rgb(255, 0, 0)" no avançado
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.oTemaAvancado.authCardTexto igual a "roxo"
  E retornar oDados.oOrdemServico.oTemaAvancado.authRodapeTexto igual a "#12345"
  E retornar oDados.oOrdemServico.oTemaAvancado.acaoDestaqueTexto igual a "rgb(255, 0, 0)"
```

---

### CT-API-09 — Landing entrega a logo da oficina como foi enviada — PENDENTE-IRMA TALK-3105

**Descrição:**
Validar que a landing de um portal com logo devolve `lTemLogo: true` e `cLogoUrl` igual ao do MS, sem o BFF redimensionar nem reescrever a URL. A TALK-3105 tira a limitação de altura da imagem no input; o portal só precisa da URL intacta.

**Tag:** [PENDENTE-IRMA] · **Prioridade:** P2 · **Modalidade:** `automacao-api` · **Exige stub:** sim (token com `lTemLogo: true` e `cLogoUrl`; definir no hop da TALK-3105)
**Cobre:** tela `/{token}` (logo do login) → `GET /portal/{token}` · `pendente-irma:TALK-3105`
**Execução:** `pendente-irma:TALK-3105` — não bloqueia o PASSOU da TALK-3103. Revisar quando a TALK-3105 for planejada (se ela não tocar o Portal, vira regressão opcional).

**Cenário de teste:**

```gherkin
Cenário: Logo da oficina chega intacta na landing
  Dado ter um link público de portal de oficina com logo cadastrada
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar oDados.lTemLogo igual a true
  E retornar oDados.cLogoUrl igual à URL da logo cadastrada
```

---

### CT-API-10 — Landing de portal sem logo não inventa imagem — PENDENTE-IRMA TALK-3105

**Descrição:**
Validar que a landing de um portal sem logo devolve `lTemLogo: false` e `cLogoUrl` vazio, para o portal mostrar o nome da oficina no lugar.

**Tag:** [PENDENTE-IRMA] · **Prioridade:** P2 · **Modalidade:** `automacao-api` · **Exige stub:** não (`O_BASE` do stub já é sem logo)
**Cobre:** tela `/{token}` → `GET /portal/{token}` · `pendente-irma:TALK-3105`
**Execução:** `pendente-irma:TALK-3105`.

**Cenário de teste:**

```gherkin
Cenário: Portal sem logo não recebe URL de imagem
  Dado ter um link público de portal de oficina sem logo cadastrada
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar oDados.lTemLogo igual a false
  E retornar oDados.cLogoUrl vazio
```

---

### CT-API-11 — Cor gravada em formato RGB chega como foi salva — PENDENTE-IRMA TALK-3104

**Descrição:**
Validar que uma cor de fundo/texto gravada pelo novo input em formato RGB (`"rgb(15, 61, 115)"`) é repassada pela landing e pelo detalhe como veio. **Só vale se a TALK-3104 gravar fora de `#RRGGBB`**: hoje o portal só lê hex e trataria esse valor como automático. Se a TALK-3104 converter para hex ao salvar, este CT vira N/A. Par negativo: CT-API-04/08 (valor inválido não derruba).

**Tag:** [PENDENTE-IRMA] · **Prioridade:** P2 · **Modalidade:** `automacao-api` · **Exige stub:** sim (definir no hop da TALK-3104)
**Cobre:** `GET /portal/{token}` e `GET /cliente/os/{id}` · `pendente-irma:TALK-3104`
**Execução:** `pendente-irma:TALK-3104`.

**Cenário de teste:**

```gherkin
Cenário: Cor em RGB gravada pelo novo input chega intacta
  Dado ter um link público de portal com a cor do card gravada como "rgb(15, 61, 115)" no avançado
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar oDados.oTemaAvancado.authCard igual a "rgb(15, 61, 115)"
```

---

## 1b. API — DELTA "cards separados" (alteração do gate aprovar_cenarios_pre_cr, 2026-11-12)

Pedido do humano: "separe entre os Cards, cada um deles deve ter o proprio fundo e texto". Chaves novas em `oTemaAvancado` (#RRGGBB; ausente/`null` = herda `authCard`/`authCardTexto`), tokens `--portal-card-<id>-bg|-texto|-sutil`:

| Superfície | Fundo / Texto | id do token | Seletor |
|---|---|---|---|
| Campo do telefone (login) | `loginCampo` / `loginCampoTexto` | `login-campo` | `.ds-cf-box` |
| Card Relatório de Serviço | `authCardRelatorio` / `authCardRelatorioTexto` | `relatorio` | `.autenticado-d4__card--relatorio` |
| Card Evolução da OS | `authCardEvolucao` / `authCardEvolucaoTexto` | `evolucao` | `.autenticado-d4__card--evolucao` |
| Card das abas | `authCardAbas` / `authCardAbasTexto` | `abas` | `.autenticado-d4__superficie-card--abas` |
| Cards do Histórico | `authCardHistorico` / `authCardHistoricoTexto` | `historico` | `.portal-historico__item` |
| Janela Meus dados | `authJanelaDados` / `authJanelaDadosTexto` | `meus-dados` | `.portal-meus-dados` |

**Ampliação de CTs existentes:** **CT-API-01/05** passam a ter também as 12 chaves de card no tema do stub e na asserção de igualdade; **CT-API-02/06** incluem as 12 chaves como `null`; **CT-API-03/07** (tema antigo) confirmam que nenhuma das 12 aparece.

### CT-API-12 — Landing entrega fundo e texto próprios do campo do telefone

**Descrição:** o campo do telefone do login deixou de usar a cor do Card; a landing precisa entregar `loginCampo`/`loginCampoTexto` como foram salvos.
**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokCardsSeparadosT3103`)
**Cobre:** tela `/{token}` → `--portal-card-login-campo-bg|texto` em `.ds-cf-box` → `GET /portal/{token}` · TALK-3103 (delta)

```gherkin
Cenário: Campo do telefone com cor própria chega inteiro na landing
  Dado ter um link público de portal com cor própria no campo do telefone e no card padrão
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar oDados.oTemaAvancado.loginCampo igual a "#FFF1C2" e loginCampoTexto igual a "#5C3B00"
  E retornar oDados.oTemaAvancado.authCard igual ao gravado
```

---

### CT-API-13 — Detalhe da O.S. entrega fundo e texto próprios de cada card

**Descrição:** relatório, evolução, abas, histórico e Meus dados com cores próprias chegam iguais no detalhe da O.S.
**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokCardsSeparadosT3103`)
**Cobre:** tela da O.S. → tokens `--portal-card-*` → detalhe da O.S. no BFF (schema `oTemaAvancado` record) · TALK-3103 (delta)

```gherkin
Cenário: Cards com cores próprias chegam inteiros no detalhe da O.S.
  Dado ter uma O.S. de portal com fundo e texto próprios nos cards de relatório, evolução, abas, histórico e Meus dados
  Quando consultar o detalhe da O.S. pelo BFF
  Então retornar HTTP 200
  E retornar oTemaAvancado com as 10 chaves desses cards iguais às gravadas
  E retornar authCard e authCardTexto iguais aos gravados
```

---

### CT-API-14 — Card só com fundo próprio chega sem texto inventado

**Descrição:** quando a oficina muda só o fundo de um card (ex.: abas), o BFF entrega `authCardAbasTexto` ausente ou `null` — nunca um texto calculado — para o portal decidir o automático.
**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokCardsSeparadosT3103`)

```gherkin
Cenário: Card só com fundo próprio
  Dado ter um link público de portal com fundo próprio no card das abas e sem texto próprio
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar oDados.oTemaAvancado.authCardAbas igual a "#FDECEC"
  E retornar oDados.oTemaAvancado.authCardAbasTexto ausente ou igual a null
```

**Stub (passo 4):** novo token `tokCardsSeparadosT3103` com o tema do cenário de preview `cards-separados` (`src/services/previewCenariosOs.ts`).

---

## 2. Smoke automatizado

N/A neste hop (WU Teste). `qa-pre-cr`: proibido gerar ou rodar `CT-SMK-*`.

---

## 3. E2E — Caminho feliz

N/A neste hop (WU Teste). Proibido gerar `CT-E2E-*` e percorrer login/O.S. por MCP (rule `qa-pre-cr-sem-e2e`).

---

## 4. E2E — Caminho negativo

N/A neste hop (WU Teste).

---

## 5. Manual (somente UI)

N/A neste hop. Nenhum CT depende de humano: tema e cores são simuláveis com o stub e o `/preview?cenario=texto-*`. As checagens visuais ficam como sugestão na seção 6.

---

## 6. Sugestões para a WU Teste (não são CTs deste hop)

1. **Cor por região** em `/preview/login` e `/preview/os` com `texto-personalizado`: `getComputedStyle(...).color` do cabeçalho (`#ffd166`), fundo da página (`#1b4332`), cards e abas (`#5a189a`), rodapé (`#d8f3dc`), login (`#7a2e00`), botão Acessar (`#ffe8cc`), destaque/selo/botão primário (`#fff1f2`). Prints de referência em `evidencias-pr/TALK-3100/dev-TALK-3103/design/`.
2. **Automático** com `texto-automatico-escuro`: login de fundo `#0F3D73` com texto claro; cabeçalho, fundo e cards escuros com texto claro.
3. **Tema antigo** com `texto-legado`: texto claro mantido no login e no cabeçalho escuro; card branco com texto escuro.
4. **Modo simples** (`rodape-claro`, `rodape-escuro`): igual ao de antes (regressão).
5. **Herança da raiz:** telas e componentes fora das regiões (modal, toast, página de erro/indisponível) com o texto do Card — conferir que continuam legíveis.
6. **Com BFF real + stub novo:** login e O.S. de `tokTextoPersonalizadoT3103` com as cores escolhidas; `tokTextoInvalidoT3103` com texto automático.

---

## Observações para o revisor / CR (não são bugs da TALK-3103)

1. **Tokens do BFF ganham dos derivados na landing.** Se o MS/BFF passar a mandar `--portal-login-texto` ou `--text-*` em `oTokensDerivados`, sobrescreve a resolução nova no login. Hoje ninguém manda (stub e referência TALK-2641).
2. **`--text-*` na raiz = texto do Card** (antes `loginTexto`): o que estiver fora das regiões com classe herda o texto do Card (sugestão 5).
3. **TALK-3104 e RGB:** a HU fala em definir cores "em RGB e hexadecimal". O portal só lê `#RRGGBB`; se o novo input gravar `rgb(...)`, o portal ignora fundo e texto (CT-API-11).
4. A parte do editor no talk-web (mesma Dev) precisa de cobertura no pré-CR do Talk; não está neste módulo.

## Pendências

- **TALK-3102 (subtarefa Cenários):** não sincronizada com estes CTs. Nenhuma mutação no Jira neste passo.
- **Stub:** 4 tokens novos (CT-API-01..08) entram no passo 4, junto com o spec, depois do gate.
- **Irmãs:** CT-API-09..11 ficam `pendente-irma`; revisar texto e massa no hop da TALK-3104/3105.

---

## Resumo

| Categoria | Qtde | Exige stub | Plataforma |
|-----------|------|------------|------------|
| API TALK-3103 — landing `GET /portal/{token}` (CT-API-01..04) | 4 (3 P0 feliz/regressão, 1 P1 negativo) | sim | BFF `portalcliente-api` |
| API TALK-3103 — detalhe `GET /cliente/os/{id}` (CT-API-05..08) | 4 (3 P0 feliz/regressão, 1 P1 negativo) | sim | BFF `portalcliente-api` |
| API pendente-irma TALK-3105 (CT-API-09, 10) | 2 (P2, feliz + negativo) | 09 sim, 10 não | BFF |
| API pendente-irma TALK-3104 (CT-API-11) | 1 (P2, condicional) | sim | BFF |
| Vitest | referência (399 testes PASSOU, sem CT novo) | — | `portalcliente-web` |
| Smoke / E2E / Manual | 0 — N/A neste hop | — | — |
| **Total CT-API** | 11 (8 contam para o PASSOU da TALK-3103; 3 `pendente-irma`) | — | — |

Par feliz + negativo por endpoint: `GET /portal/{token}` → CT-API-01, 02, 03 / CT-API-04. `GET /cliente/os/{id}` → CT-API-05, 06, 07 / CT-API-08 (401/403 do detalhe já cobertos em `modulo-in-948-cards-os`; 400/404 da landing em `modulo-in-949-tema-rodape`).

> **Aguardando aprovação humana** no gate `aprovar_cenarios_pre_cr` antes de seguir para a automação (`qa-automatizador`, passo 4). Os CTs novos ficam com execução `pendente` até lá.
