# CT-API-05

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/portal/tokTemaAvancadoIN949X
- **Prova:** resposta da API conforme cenário.
