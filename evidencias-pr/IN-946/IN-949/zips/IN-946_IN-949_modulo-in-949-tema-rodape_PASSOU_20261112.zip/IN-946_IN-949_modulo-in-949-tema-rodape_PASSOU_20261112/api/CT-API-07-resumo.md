# CT-API-07

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/cliente/os/tokTemaCorInvalidaIN949
- **Prova:** resposta da API conforme cenário.
