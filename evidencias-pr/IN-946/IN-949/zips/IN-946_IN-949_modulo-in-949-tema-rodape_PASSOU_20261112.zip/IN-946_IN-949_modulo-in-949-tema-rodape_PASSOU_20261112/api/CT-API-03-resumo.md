# CT-API-03

- **HTTP:** 404
- **URL:** http://127.0.0.1:3333/portal/tokNaoExisteIN949XXXX
- **Prova:** resposta da API conforme cenário.
