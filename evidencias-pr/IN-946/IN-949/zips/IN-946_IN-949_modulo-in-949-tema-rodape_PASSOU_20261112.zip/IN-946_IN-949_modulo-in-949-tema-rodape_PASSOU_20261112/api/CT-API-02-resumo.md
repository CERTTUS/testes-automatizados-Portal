# CT-API-02

- **HTTP:** 400
- **URL:** http://127.0.0.1:3333/portal/xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
- **Prova:** resposta da API conforme cenário.
