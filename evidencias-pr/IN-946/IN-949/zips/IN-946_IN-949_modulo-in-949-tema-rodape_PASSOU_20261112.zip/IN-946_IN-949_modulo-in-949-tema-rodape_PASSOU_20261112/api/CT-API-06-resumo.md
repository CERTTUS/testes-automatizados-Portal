# CT-API-06

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/cliente/os/tokTemaAvancadoIN949X
- **Prova:** resposta da API conforme cenário.
