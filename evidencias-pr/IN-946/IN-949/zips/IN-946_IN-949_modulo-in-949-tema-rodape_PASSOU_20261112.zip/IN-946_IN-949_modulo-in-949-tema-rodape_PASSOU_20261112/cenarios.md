# Cenários de teste — `modulo-in-949-tema-rodape`

> Produto: **Portal do Cliente** (`portal`) · repo de testes `testes-automatizados-Portal`
> História (parentKey): **IN-946** · Dev do hop: **IN-949** · subtarefa Cenários: **IN-951** (Concluído - Aprovado, achado por JQL no passo 1; ninguém mexeu no Jira, ver Pendências)
> Base: `contexto-pr.md` (passo 1) e `jest-validacao.md` (passo 0)
> Pipeline: **QA_PRE_CR** (hop Dev) · modo `api-smoke` · `proibidoE2e: true`
> `cenariosOrigem: gerado-na-dev` (sem CTs importados de subtarefa HU nem MeloQA). CT-API-01..03 vieram de `modulo-in-946-login-telefone`, onde eram CT-API-12..14 (`pendente-irma:IN-949`)
> Stack deste hop: **Vitest (produto) + API (Playwright projeto `api`)**. Smoke e E2E ficam para a WU Teste.
> Formato: **Título → Descrição → Cenário (BDD)** · passos no **infinitivo**
> Data: 2026-11-12

## Legenda

| Tag | Significado |
|-----|-------------|
| **[EXISTE]** | Já automatizado (spec existente) |
| **[NOVO]** | Cenário novo — candidato a automação (passo 4, depois do gate) |
| **[GAP]** | Ainda não automatizado |

**Modalidades:** `manual` · `automacao-api` · `automacao-playwright` · `jest`
**Prioridade:** P0 · P1 · P2
**Exige stub:** `sim` = o automatizador precisa acrescentar massa em `scripts/qa/stub-ms-portal-landing.mjs` (repo de testes) antes do spec; `não` = roda com o stub de hoje.

**Classificação humano x runner** (rule `qa-automacao-sem-humano`): os 8 CTs de API abaixo (CT-API-01..08) vão até PASS sem ninguém interagir. É HTTP direto no BFF, com massa do stub MS (8087) e, nos CTs de detalhe, sessão aberta por `obterCookiePortalSessao`. Nenhum depende de OTP, câmera ou diálogo de navegador.

---

## 0. Escopo e inventário do pai

### Entrega deste hop (IN-949)

- Diff do produto (`portalcliente-web`, branch `historia/IN-946-ajustes-visuais-portal`, working tree ainda não commitado): **só front**. A logo da Certtus no rodapé da O.S. e na assinatura do login troca entre azul (`#1B315F`) e branca (`#FFFFFF`) pela maior razão de contraste WCAG contra a cor real do fundo (empate → azul). O fundo vem da cadeia token da superfície (`--portal-os-footer-bg` no rodapé, `--portal-login-fundo` no login) → `--surface-default` → `#ffffff`. Vale também para o tema avançado (`authRodape`/`loginFundo`), não só para claro/escuro.
- O BFF (`portalcliente-api`) **não mudou**. Os CTs de API são a **regressão do contrato de tema** que o front usa para decidir a logo (RN9 do `contexto-pr.md`): a landing `GET /portal/{token}` repassa `cTemaModo`, `cCorPrimaria`/`cCorSecundaria`, `oTemaAvancado` e `oTokensDerivados` como o MS mandou; o detalhe `GET /cliente/os/{id}` repassa `cCorPrimaria`/`cCorSecundaria`, `cTemaModo` e `oTemaAvancado` e descarta `oTokensDerivados`.
- **A API não diz qual logo aparece.** A escolha da variante, a cadeia do fundo, os limiares e o ajuste dos textos (RN1–RN8) estão provados no Vitest (tabela abaixo). Nenhum CT deste arquivo tenta provar a variante pela resposta do BFF.

### Inventário do pai (HARNESS_MULTI_DEV_PR)

| Dev | Assunto | Código na branch | CTs |
|-----|---------|------------------|-----|
| IN-947 | Fundo amarelo nos campos de login | sim (Concluído - Aprovado) | `modulo-in-946-login-telefone` CT-API-01..06. O CT-API-06 de lá (landing escuro → `cTemaModo: "escuro"`) é a regressão da IN-947; o CT-API-04 daqui cobre a mesma entrada para a IN-949 e confere também os tokens |
| IN-948 | Cards da O.S. (altura padrão + fallback sem dados) | sim (Concluído - Aprovado) | `modulo-in-948-cards-os` CT-API-01..08 |
| **IN-949** | Contraste da logo Certtus no rodapé e no login | sim (working tree) | **este arquivo**, CT-API-01..08. Contam para o PASSOU da IN-949 |

> As irmãs já têm feliz + negativo escritos nos módulos delas. Este arquivo não os duplica. `tasks[]` da PT (IN-950, Arquivada) não foi conferido no Jira neste passo, a mesma ressalva dos módulos irmãos.

### Vitest do produto (passo 0) — referência da decisão visual, sem CT novo

| Ref | Arquivo (`portalcliente-web`) | O que prova | Regras |
|-----|-------------------------------|-------------|--------|
| JEST-IN-949-01 | `src/utils/__tests__/contrasteCor.test.ts` (novo, 20) | `corHexLer` aceita `#rgb`, `#rrggbb`, `rgb()`, `rgba(…,1)` e recusa alfa < 1, `transparent`, `var()`, `color-mix()`, nome de cor, `#rrggbbaa`, canal > 255; luminância e razão de contraste WCAG | RN2, RN3 |
| JEST-IN-949-02 | `src/services/__tests__/marcaCerttusVariante.test.ts` (novo, 17) | 14 casos de fundo/variante/texto: sem tokens → azul; claro → azul; escuro → branca; avançado `#0F3D73` → branca + texto `#fafafa`; avançado `#FACC15` no escuro → azul + texto `#171717`; `#808080` → branca; `#8A8A8A` → azul; cor inválida → `#ffffff` e azul; `rgb(23, 23, 23)` → branca; `color-mix` cai para `--surface-default`; `#abc` → `#aabbcc` | RN2–RN7 |
| JEST-IN-949-03 | `src/services/__tests__/previewCenariosOs.test.ts` (+11) | os 7 cenários `?cenario=rodape-*` do `/preview` | apoio à WU Teste |
| JEST-IN-949-04 | `src/components/molecules/__tests__/AssinaturaCerttus.test.tsx` (+3) | sem props → azul sem estilo inline; `cVariante="branca"` troca o arquivo para `certtus-logotipo-branco.svg`; `cCorTexto` vira `color`, `cCorFundo` vai para `data-cor-fundo` | RN1, RN7 |
| JEST-IN-949-05 | `src/components/organisms/__tests__/RodapeOficinaPortal.test.tsx` (+2) | sem tokens → azul e textos sem estilo; `authRodape #0F3D73` → branca, `data-cor-fundo="#0f3d73"`, nome e CNPJ em `#fafafa` | RN4, RN5, RN7 |
| JEST-IN-949-06 | `src/components/templates/__tests__/PreviewPortalAoVivo.test.tsx` (+4) | O.S. `rodape-escuro` → branca; login `rodape-personalizado-escuro` → branca; O.S. `rodape-claro` → azul; `?cenario=vazio` no login sem assinatura | RN4, RN8 |

**Status:** **[EXISTE]** PASSOU (47 arquivos, 362 testes, 0 falhas; `tsc --noEmit` OK). Limite: o jsdom não pinta a tela, então o Vitest prova a variante escolhida, o fundo resolvido e o estilo inline, não o contraste que aparece de fato no navegador (fica para a WU Teste, seção 6).

### Massa e ambiente (para o automatizador)

- Base: `E2E_API_BASE_URL` (BFF direto). O BFF local precisa de `API_MICROSERVICOS_BASE_URL=http://127.0.0.1:8087` com `node scripts/qa/stub-ms-portal-landing.mjs` rodando, **sem** `QA_STUB_TEMA_CRU=1` (o CT-API-01 e o CT-API-04 exigem `oTokensDerivados`). Telefone autorizado: `QA_STUB_TELEFONE_AUTORIZADO` (padrão `5511999999999`), usado só nos CTs de detalhe (CT-API-06 e 07).
- Helpers: `tests/api/modulo-in-946-login-telefone/loginD1Api.ts` (`C_TOKEN_INEXISTENTE`, `respostaApiLer`, `cookieHeaderDe`), `tests/e2e/helpers/portalFixtures.ts` (`C_TOKEN_OK`), `tests/e2e/helpers/portalAcessoApiHelpers.ts` (`obterCookiePortalSessao`), `tests/e2e/helpers/env` (`E2E_API_BASE_URL`).
- Spec: `tests/api/modulo-in-949-tema-rodape/CT-API-tema-rodape.spec.ts` (CT-API-01..03 já existem). CT-API-04..08 entram no mesmo arquivo. As constantes dos tokens novos ficam junto do spec (ou no `loginD1Api.ts`, como os da IN-948; decisão do automatizador).
- Massa do stub hoje: `xK9mP2nQ4rS6tU8vW0yZ12` (`C_TOKEN_OK`, claro, `oTokensDerivados` azuis), `tokTemaCustomXXXXXXXX` (`cTemaModo: "escuro"`, `oTokensDerivados` roxos). Nenhum token manda `cCorPrimaria` no topo, `editor`, `authRodape` ou `loginFundo`, e o detalhe da O.S. do stub não manda tema nenhum.

### Mudança no stub pedida por CT-API-05..08 (o automatizador faz no passo 4)

Arquivo: `scripts/qa/stub-ms-portal-landing.mjs` (repo de testes, não é código de produto). Acrescentar 3 tokens em `M_POR_TOKEN`, o que já os coloca em `M_TOKENS_COM_OS` e libera o login por telefone e o detalhe. Não mexer nos tokens existentes.

| Token (≤ 64 caracteres) | Landing (`oDados` do MS) | Detalhe (`oDetalheOs`) | Usado em |
|-------------------------|--------------------------|------------------------|----------|
| `tokTemaAvancadoIN949X` | `cNomeFantasia: "Oficina Tema Avançado"`, `cCorPrimaria: "#1a5276"`, `cCorSecundaria: "#2874a6"`, `cTemaModo: "claro"`, `oTemaAvancado: {editor: "avancado", authRodape: "#0F3D73", loginFundo: "#0F3D73"}`, sem `oTokensDerivados` | base + os mesmos `cCorPrimaria`, `cCorSecundaria`, `cTemaModo`, `oTemaAvancado` **e** `oTokensDerivados: {"--portal-os-footer-bg": "#ffffff"}` (para provar que o BFF descarta) | CT-API-05, CT-API-06 |
| `tokTemaCorInvalidaIN949` | `cNomeFantasia: "Oficina Cor Inválida"`, `cCorPrimaria: "#1a5276"`, `cTemaModo: "claro"`, `oTemaAvancado: {editor: "avancado", authRodape: "azul", loginFundo: "azul"}` | base + os mesmos `cCorPrimaria`, `cTemaModo`, `oTemaAvancado` | CT-API-07 |
| ~~`tokTemaModoInvalidoIN949`~~ (FORA — CT-API-08 descartado no gate) | `cNomeFantasia: "Oficina Modo Inválido"`, `cTemaModo: "auto"` (fora do enum `claro|escuro`) | não usado | CT-API-08 |

> `oDetalheOs(cToken)` hoje só diferencia `tokOsComItensIN948XXX`. Acrescentar um ramo que espalha o tema por token, mantendo `mChecklist`/`mServicos`/`mPecas` vazios (o formato da base já passa no schema do BFF).

---

> **Gate `aprovar_cenarios_pre_cr` (2026-11-12): aprovados CT-API-01..07; CT-API-08 FORA.** Textos do login sobre fundo escuro personalizado ficam fora da IN-949 (outra issue).

## 1. API

**Funcionalidade:** Tema do portal que o front usa para decidir a versão da logo da Certtus (rodapé da O.S. e assinatura do login), regressão do contrato do BFF para a IN-949

### CT-API-01 — Landing de portal com tema claro entrega o tema do rodapé

**Descrição:**
Validar que a landing de um portal em tema claro devolve sucesso, sem `cTemaModo: "escuro"` e com os tokens de cor (`--*`) que o front aplica por cima da derivação local. É a entrada do caminho padrão: fundo branco, logo azul.

**Tag:** [EXISTE] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** não
**Cobre:** tela `/{token}` (assinatura do login, `assinaturaCerttusPropsMontar(…, "login")`) → `GET /portal/{token}` (`portalController.landing`) · IN-949 (RN5, RN9)
**Massa:** `C_TOKEN_OK` (`xK9mP2nQ4rS6tU8vW0yZ12`)
**Por que importa para a logo:** sem tema escuro nem fundo do avançado, o front resolve `#ffffff` e mantém a logo azul.
**Execução:** spec existente; o resultado deste módulo sai na execução do passo 5.

**Cenário de teste:**

```gherkin
Cenário: Portal em tema claro entrega os tokens de cor na landing
  Dado ter um link público de portal configurado com tema claro
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.cTemaModo ausente ou igual a "claro"
  E retornar oDados.oTokensDerivados com pelo menos 1 chave
  E validar que todas as chaves de oDados.oTokensDerivados começam com "--"
```

---

### CT-API-02 — Landing com token acima de 64 caracteres é rejeitada sem tema

**Descrição:**
Validar que um token com mais de 64 caracteres recebe 400 "Token inválido." sem nenhum dado de tema. O login cai no estado de erro, que mantém a assinatura padrão (azul).

**Tag:** [EXISTE] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** não
**Cobre:** tela `/{token}` (estado `erro`, assinatura padrão) → `GET /portal/{token}` → 400 · IN-949 (RN5)
**Massa:** token com 65 caracteres; não chega ao MS
**Por que importa para a logo:** sem tema, a tela não pode inventar fundo escuro; a logo fica azul sobre branco.
**Execução:** spec existente; o resultado deste módulo sai na execução do passo 5.

**Cenário de teste:**

```gherkin
Cenário: Token longo demais é recusado na landing
  Dado ter um token de link público com 65 caracteres
  Quando enviar GET /portal/{token} com esse token
  Então retornar HTTP 400
  E retornar lSucesso igual a false
  E retornar cMensagem "Token inválido."
  Mas não retornar oDados
```

---

### CT-API-03 — Landing com token sem link cadastrado não entrega tema

**Descrição:**
Validar que um token sem link cadastrado recebe 404 e nenhum dado de tema (`oTokensDerivados`, `cTemaModo`). O login cai no estado indisponível, que mantém a assinatura padrão.

**Tag:** [EXISTE] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** não
**Cobre:** tela `/{token}` (estado `indisponivel`, assinatura padrão) → `GET /portal/{token}` → 404 · IN-949 (RN5)
**Massa:** `C_TOKEN_INEXISTENTE` (`tokNaoExisteIN949XXXX`); o stub responde 404
**Por que importa para a logo:** link inexistente não pode carregar tema de outro portal nem trocar a logo.
**Execução:** spec existente; o resultado deste módulo sai na execução do passo 5.

**Cenário de teste:**

```gherkin
Cenário: Token sem link cadastrado não entrega tema
  Dado ter um token de link público que não existe
  Quando enviar GET /portal/{token} com esse token
  Então retornar HTTP 404
  E retornar lSucesso igual a false
  Mas não retornar oDados.oTokensDerivados
  E não retornar oDados.cTemaModo
```

---

### CT-API-04 — Landing de portal com tema escuro entrega o modo e os tokens

**Descrição:**
Validar que a landing de um portal em tema escuro devolve `cTemaModo: "escuro"` e os tokens de cor `--*` repassados como o MS mandou. Fecha o par claro/escuro do contrato que alimenta a assinatura do login. Complementa o CT-API-06 de `modulo-in-946-login-telefone` (regressão da IN-947, que só olha o modo) conferindo também os tokens.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** não
**Cobre:** tela `/{token}` (`landingPortalCarregar` → `temaProducaoDerivar` → assinatura do login) → `GET /portal/{token}` · IN-949 (RN4, RN9)
**Massa:** `tokTemaCustomXXXXXXXX` (stub devolve `cTemaModo: "escuro"` e 5 tokens roxos)
**Por que importa para a logo:** é o modo escuro que leva o fundo do painel para escuro e a logo para a versão branca.
**Execução:** `pendente` (o automatizador cria no passo 4, após o gate).

**Cenário de teste:**

```gherkin
Cenário: Portal em tema escuro informa o modo e os tokens na landing
  Dado ter um link público de portal configurado com tema escuro
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.cTemaModo igual a "escuro"
  E retornar oDados.oTokensDerivados com pelo menos 1 chave
  E validar que todas as chaves de oDados.oTokensDerivados começam com "--"
```

---

### CT-API-05 — Landing com tema avançado e fundo escuro repassa o tema sem alterar

**Descrição:**
Validar que a landing de um portal em tema **claro** com fundo do login e do rodapé escuros no avançado (`editor: "avancado"`, `loginFundo` e `authRodape` `#0F3D73`) devolve `cCorPrimaria`, `cTemaModo` e `oTemaAvancado` exatamente como o MS mandou. É o pedido do humano: a logo segue a cor escolhida no avançado, não só o modo.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTemaAvancadoIN949X`)
**Cobre:** tela `/{token}` (`temaProducaoDerivar` gera `--portal-login-fundo` a partir de `loginFundo` → assinatura do login) → `GET /portal/{token}` (schema `.passthrough()`) · IN-949 (RN4, RN8, RN9)
**Massa:** `tokTemaAvancadoIN949X` (ver "Mudança no stub")
**Por que importa para a logo:** se o BFF perder ou mudar `loginFundo`, o login fica com fundo escuro e logo azul, ilegível.
**Execução:** `pendente` (o automatizador cria no passo 4, após o gate).

**Cenário de teste:**

```gherkin
Cenário: Tema claro com fundo escuro no avançado chega inteiro na landing
  Dado ter um link público de portal em tema claro com fundo do login e do rodapé "#0F3D73" no editor avançado
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.cCorPrimaria igual a "#1a5276"
  E retornar oDados.cTemaModo igual a "claro"
  E retornar oDados.oTemaAvancado igual a editor "avancado", authRodape "#0F3D73" e loginFundo "#0F3D73"
```

---

### CT-API-06 — Detalhe da O.S. com tema avançado e fundo escuro repassa o tema e descarta tokens do MS

**Descrição:**
Validar que o detalhe da O.S. de um portal com fundo do rodapé escuro no avançado devolve `cCorPrimaria`, `cCorSecundaria`, `cTemaModo` e `oTemaAvancado` idênticos ao MS, e **não** devolve `oTokensDerivados` mesmo quando o MS manda. É dessa entrada que o rodapé da O.S. deriva `--portal-os-footer-bg` e escolhe a logo.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTemaAvancadoIN949X`, com tema no `oDetalheOs`)
**Cobre:** tela `/os/{cOsPublicId}` (`ConteudoDetalheOsAutenticado` → `oTokensDerivados` locais → `RodapeOficinaPortal`) → `GET /cliente/os/{id}` (`portalOsDetalheDadosMsSchema`, sem passthrough) · IN-949 (RN4, RN9)
**Massa:** sessão aberta com `tokTemaAvancadoIN949X` + telefone autorizado; detalhe da mesma O.S. O stub manda `oTokensDerivados: {"--portal-os-footer-bg": "#ffffff"}`, que o BFF deve descartar
**Por que importa para a logo:** o rodapé só tem a derivação local; se o tema não chegar, ou chegar um token branco do MS que contradiz `authRodape`, a logo sai na versão errada.
**Execução:** `pendente` (o automatizador cria no passo 4, após o gate).

**Cenário de teste:**

```gherkin
Cenário: Detalhe da O.S. entrega o tema avançado com fundo escuro do rodapé
  Dado ter uma sessão do portal aberta para uma O.S. de oficina em tema claro com fundo do rodapé "#0F3D73" no editor avançado
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.cCorPrimaria igual a "#1a5276"
  E retornar oDados.oOrdemServico.cCorSecundaria igual a "#2874a6"
  E retornar oDados.oOrdemServico.cTemaModo igual a "claro"
  E retornar oDados.oOrdemServico.oTemaAvancado igual a editor "avancado", authRodape "#0F3D73" e loginFundo "#0F3D73"
  Mas não retornar oDados.oOrdemServico.oTokensDerivados
```

---

### CT-API-07 — Detalhe da O.S. com cor inválida no avançado é repassado sem quebrar

**Descrição:**
Validar que um tema avançado com cor que não é `#rrggbb` (`authRodape: "azul"`) não derruba o detalhe da O.S.: o BFF devolve 200 com `oTemaAvancado` como veio, sem validar nem trocar a cor. Quem ignora o valor é o front (RN6), que cai no fundo padrão do modo.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTemaCorInvalidaIN949`)
**Cobre:** tela `/os/{cOsPublicId}` (rodapé com cor do avançado inválida → fundo `#ffffff` → logo azul) → `GET /cliente/os/{id}` · IN-949 (RN6, RN9)
**Massa:** sessão aberta com `tokTemaCorInvalidaIN949` + telefone autorizado; detalhe da mesma O.S.
**Por que importa para a logo:** uma cor mal digitada no avançado não pode tirar a O.S. do ar; a tela abre e a logo volta para a azul sobre branco.
**Execução:** `pendente` (o automatizador cria no passo 4, após o gate).

**Cenário de teste:**

```gherkin
Cenário: Cor inválida no avançado não derruba o detalhe da O.S.
  Dado ter uma sessão do portal aberta para uma O.S. de oficina com fundo do rodapé "azul" no editor avançado
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.cTemaModo igual a "claro"
  E retornar oDados.oOrdemServico.oTemaAvancado.authRodape igual a "azul"
  E retornar oDados.oOrdemServico.oTemaAvancado.loginFundo igual a "azul"
```

---

### CT-API-08 — Landing com modo de tema fora do padrão é recusada sem tema — FORA (decisão do gate)

**Descrição:**
Validar que um portal gravado com `cTemaModo` fora de `claro|escuro` (ex.: `"auto"`) recebe 502 `MS_RESPOSTA_INVALIDA` sem nenhum dado, em vez de entregar um modo que o front não conhece. É um comportamento que já existia (BFF fora do diff); fica aqui como o negativo de payload malformado do contrato de tema.

**Tag:** [NOVO] · **Prioridade:** P2 · **Modalidade:** `automacao-api` · **Exige stub:** sim (`tokTemaModoInvalidoIN949`)
**Cobre:** tela `/{token}` (estado `erro`, assinatura padrão) → `GET /portal/{token}` → `mapearPortalLinkLanding` lança → `apiMicroservicosClient` → 502 · IN-949 (RN5, RN9)
**Massa:** `tokTemaModoInvalidoIN949` (ver "Mudança no stub")
**Por que importa para a logo:** modo desconhecido não pode chegar ao front e gerar fundo indefinido; a tela cai no erro com a logo padrão.
**Execução:** `fora` — gate `aprovar_cenarios_pre_cr` (2026-11-12): o humano aprovou CT-API-01..07 e deixou o CT-API-08 FORA desta entrega. Não automatizar.

**Cenário de teste:**

```gherkin
Cenário: Modo de tema desconhecido é recusado na landing
  Dado ter um link público de portal gravado com modo de tema "auto"
  Quando enviar GET /portal/{token} desse link
  Então retornar HTTP 502
  E retornar lSucesso igual a false
  E retornar cMensagem "Resposta inválida do api-microservicos."
  E retornar cCodigo "MS_RESPOSTA_INVALIDA"
  Mas não retornar oDados
```

---

## 2. Smoke automatizado

N/A neste hop (WU Teste). `qa-pre-cr`: proibido gerar ou rodar `CT-SMK-*`.

---

## 3. E2E — Caminho feliz

N/A neste hop (WU Teste). Proibido gerar `CT-E2E-*` e percorrer login/O.S. por MCP (rule `qa-pre-cr-sem-e2e`).

---

## 4. E2E — Caminho negativo

N/A neste hop (WU Teste).

---

## 5. Manual (somente UI)

N/A neste hop. Nenhum CT depende de humano: tema, cor de fundo e variante da logo são simuláveis com o stub, o `/preview?cenario=rodape-*` ou `page.route`. As checagens visuais ficam como sugestão na seção 6, para a WU Teste classificar.

---

## 6. Sugestões para a WU Teste (não são CTs deste hop)

1. **Variante por cenário (RN2–RN6):** em `/preview/os?cenario=…` e `/preview/login?cenario=…` (sem backend), conferir `[data-testid="acesso-assinatura-certtus"]` com `data-variante` e `img[alt="CERTTUS"]` `src`: `rodape-claro` → azul; `rodape-escuro` → branca; `rodape-personalizado-escuro` (#0F3D73) → branca; `rodape-personalizado-claro` (#FACC15) → azul; `rodape-intermediario-escuro` (#808080) → branca; `rodape-intermediario-claro` (#8A8A8A) → azul; `rodape-cor-invalida` → azul. Esperados e prints em `evidencias-pr/IN-946/dev-IN-949/design/index.md`.
2. **Fundo resolvido x pintado:** comparar `data-cor-fundo` com `getComputedStyle(...).backgroundColor` do rodapé (`.portal-rodape-oficina`) e do painel do login (`.acesso-painel-form`). Diferença indica token que o CSS pinta e o `corHexLer` não lê (risco 1 das observações).
3. **Textos (RN7):** no fundo `#0F3D73`, "Criado por" e nome/CNPJ/endereço/telefone da oficina em `#fafafa`; no tema padrão, sem `style` inline.
4. **Com BFF real + stub novo:** login e O.S. de `tokTemaAvancadoIN949X` → logo branca nas duas superfícies; `tokTemaCorInvalidaIN949` → logo azul sobre branco.
5. **Login sem tema:** `?cenario=vazio` no `/preview/login` segue sem assinatura; estados `indisponivel`/`erro` do `/{token}` com a logo azul.

---

## Observações para o revisor / CR (não são bugs da IN-949)

1. **Tokens do MS ganham dos derivados na landing.** Se o MS real mandar `--portal-login-fundo`/`--surface-default` em formato que `corHexLer` não lê (`color-mix`, `var()`), o CSS pinta esse valor e a decisão usa o próximo da cadeia. O Vitest registra como intencional ("color-mix cai para surface").
2. **`tokTemaCustomXXXXXXXX` não manda `cCorPrimaria` no topo**, só `oTemaSimples`. Com esse stub, `temaProducaoDerivar` devolve `undefined` e a assinatura do login fica azul mesmo com `cTemaModo: "escuro"`. O CT-API-04 prova o contrato (o modo chega), não a troca da logo. O stub novo (`tokTemaAvancadoIN949X`) já manda `cCorPrimaria`, que é o que faz a derivação rodar. Não alteramos o `tokTemaCustom` para não mexer na massa da IN-947.
3. **CT-API-08 é P2 e opcional no gate:** prova um comportamento antigo do BFF (payload fora do schema → 502). Não há par equivalente no detalhe porque o contexto da IN-948 registrou 400 "Identificador da OS inválido." para payload malformado no detalhe e a leitura do código indica 502; esse caso fica fora até alguém confirmar qual status sai.
4. **`ConteudoDetalheOsAutenticado.tsx` e `src/app/[token]/page.tsx`** mudaram sem teste próprio. O comportamento está provado em `RodapeOficinaPortal`, `marcaCerttusVariante` e `PreviewPortalAoVivo`; a ligação real (detalhe → rodapé) é a sugestão 4 da seção 6.

## Pendências

- **IN-951 (subtarefa Cenários):** não foi sincronizada com estes CTs. Por instrução do orquestrador, nenhuma mutação no Jira neste passo. Fica para quem tiver autorização de mutação depois do gate.
- **Stub:** os 3 tokens novos (CT-API-05..08) entram no passo 4, junto com o spec, depois do gate.

---

## Resumo

| Categoria | Qtde | Exige stub | Plataforma |
|-----------|------|------------|------------|
| API existentes (`CT-API-01..03`, renumerados de CT-API-12..14 do módulo da IN-947) | 3 (1 P0, 2 P1) · 1 feliz, 2 negativo | não | web / BFF `portalcliente-api` |
| API novo sem stub (`CT-API-04`, landing escuro) | 1 (P0) · feliz | não | BFF `portalcliente-api` |
| API novo com stub (`CT-API-05`, `CT-API-06`, tema avançado com fundo escuro na landing e no detalhe) | 2 (P0) · feliz | sim | BFF `portalcliente-api` |
| API novo com stub (`CT-API-07`, cor inválida no detalhe; `CT-API-08`, modo inválido na landing) | 2 (P1, P2) · negativo/fallback | sim | BFF `portalcliente-api` |
| Vitest | referência (362 testes PASSOU, sem CT novo) | — | `portalcliente-web` |
| Smoke / E2E | 0 — N/A neste hop (WU Teste) | — | — |
| Manual | 0 — sugestões na seção 6 | — | — |
| **Total CT-API** | 8. Todos contam para o PASSOU da IN-949 | 4 exigem stub | — |

Par feliz + negativo por endpoint: `GET /portal/{token}` → CT-API-01, 04, 05 / CT-API-02, 03, 08. `GET /cliente/os/{id}` (tema) → CT-API-06 / CT-API-07 (401/403 do detalhe já cobertos em `modulo-in-948-cards-os`).

> **Aguardando aprovação humana** no gate `aprovar_cenarios_pre_cr` antes de seguir para a automação (`qa-automatizador`, passo 4). Os CTs novos ficam com execução `pendente` até lá.
