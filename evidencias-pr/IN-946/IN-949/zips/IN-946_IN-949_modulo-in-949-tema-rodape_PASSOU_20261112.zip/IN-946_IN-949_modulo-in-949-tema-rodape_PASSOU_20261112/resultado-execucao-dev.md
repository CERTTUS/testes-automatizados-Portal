# resultado-execucao-dev

> Dev: `IN-949` | HU: `IN-946` | Módulo: `modulo-in-949-tema-rodape`
> Data: 2026-11-12T17:03:36.995Z

Veredito: **PASSOU**

Comando: `npm run test:pre-cr -- --modulo modulo-in-949-tema-rodape --dev-key IN-949 --parent-key IN-946 --camadas api`
Ambiente: `local` (BFF portalcliente-api em 127.0.0.1:3333 com `API_MICROSERVICOS_BASE_URL=http://127.0.0.1:8087`; stub `scripts/qa/stub-ms-portal-landing.mjs` em 8087)

---

## O que foi testado (linguagem de tela)

- Portal claro: o servidor entrega o tema e as cores do rodapé, e a logo da Certtus fica azul sobre o fundo branco (CT-API-01).
- Link com token longo demais ou inexistente: nenhuma cor de tema é entregue; a tela de erro usa a logo azul padrão (CT-API-02, CT-API-03).
- Portal escuro: o servidor informa o modo escuro e as cores, que é o que deixa o fundo escuro e a logo branca (CT-API-04).
- Tema claro com fundo azul-escuro escolhido no avançado: a cor chega igual no login e na O.S., então a logo fica branca e legível nas duas telas (CT-API-05, CT-API-06).
- Na O.S., o servidor não repassa cor pronta do sistema que contradiga o fundo escolhido (CT-API-06).
- Cor mal digitada no avançado ("azul") não derruba a O.S.: a tela abre e o front volta ao fundo padrão com a logo azul (CT-API-07).
- Vitest do produto (50 arquivos, 376 testes): escolha da logo pelo maior contraste, cadeia de fallback do fundo, textos do rodapé/"Criado por" só trocam abaixo de 4,5:1, cenários do preview e páginas reais de login e O.S. (pasta jest/).

E2E e checklist manual: WU Teste (não executados neste hop). CT-API-08 (modo de tema inválido → 502) ficou FORA por decisão do gate `aprovar_cenarios_pre_cr`.

---

## Resumo

| Métrica | Valor |
|---------|-------|
| Jest | 1 com prova (Vitest 50 arquivos / 376 testes, `jest/junit.xml`) |
| API | 7 com prova (CT-API-01..07) |
| Smoke | 0 (proibido neste hop) |
| Fora do escopo | CT-API-08 (gate) |

---

## Evidências por CT (obrigatório no PASS)

| CT | Tipo | Status | Arquivo de prova |
|----|------|--------|------------------|
| JEST-IN-949 | jest | PASSOU | `jest/junit.xml` |
| CT-API-01 | api | PASSOU | `api/CT-API-01-response.json` |
| CT-API-02 | api | PASSOU | `api/CT-API-02-response.json` |
| CT-API-03 | api | PASSOU | `api/CT-API-03-response.json` |
| CT-API-04 | api | PASSOU | `api/CT-API-04-response.json` |
| CT-API-05 | api | PASSOU | `api/CT-API-05-response.json` |
| CT-API-06 | api | PASSOU | `api/CT-API-06-response.json` |
| CT-API-07 | api | PASSOU | `api/CT-API-07-response.json` |
| CT-API-08 | api | FORA (gate) | — |
