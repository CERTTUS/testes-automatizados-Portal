# CT-API-01

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/acesso/telefone
- **Prova:** resposta da API conforme cenário.
