# CT-API-02

- **HTTP:** 403
- **URL:** http://127.0.0.1:3333/acesso/telefone
- **Prova:** resposta da API conforme cenário.
