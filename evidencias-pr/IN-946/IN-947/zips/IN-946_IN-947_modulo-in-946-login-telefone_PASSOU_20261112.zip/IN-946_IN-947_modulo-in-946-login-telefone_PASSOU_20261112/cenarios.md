# Cenários de teste — `modulo-in-946-login-telefone`

> Produto: **Portal do Cliente** (`portal`) · repo de testes `testes-automatizados-Portal`
> História (parentKey): **IN-946** · Dev do hop: **IN-947** · subtarefa Cenários: **IN-951**
> Base: `contexto-pr.md` (passo 1) e `jest-validacao.md` (passo 0)
> Pipeline: **QA_PRE_CR** (hop Dev) · modo `api-smoke` · `proibidoE2e: true`
> `cenariosOrigem: gerado-na-dev` (sem CTs importados de subtarefa HU nem MeloQA)
> Stack deste hop: **Jest/Vitest (produto) + API (Playwright projeto `api`)**. Smoke e E2E ficam para a WU Teste.
> Formato: **Título → Descrição → Cenário (BDD)** · passos no **infinitivo**
> Data: 2026-11-11

## Legenda

| Tag | Significado |
|-----|-------------|
| **[EXISTE]** | Já automatizado |
| **[NOVO]** | Cenário novo — candidato a automação |
| **[GAP]** | Ainda não automatizado |

**Modalidades:** `manual` · `automacao-api` · `automacao-playwright` · `jest`
**Prioridade:** P0 · P1 · P2

**Classificação humano x runner** (rule `qa-automacao-sem-humano`): os 14 CTs de API abaixo (CT-API-01..14) vão até PASS sem ninguém interagir (HTTP direto no BFF, massa de fixture/stub ou `.env`). Nenhum depende de autofill real, OTP, câmera ou diálogo de navegador.

---

## 0. Escopo e inventário do pai

### Entrega deste hop (IN-947)

- Diff do produto (`portalcliente-web`, branch `historia/IN-946-ajustes-visuais-portal`): **só CSS** em `src/styles/acesso-d1.css`. Fundo do campo de telefone do login (`CampoTelefone` → `.ds-cf-*`) em foco, saída do foco com valor, autopreenchimento (`:-webkit-autofill` / `:autofill`), desabilitado + autopreenchimento, e rótulo flutuante na prévia do autopreenchimento.
- Nenhuma rota de API mudou. Os CTs de API deste hop são **regressão do login** que a tela alterada (`/{token}`) usa: `POST /acesso/telefone` (BFF `portalcliente-api`), com o tema vindo de `GET /portal/{token}`.

### Inventário do pai (HARNESS_MULTI_DEV_PR)

| Dev | Assunto | Código na branch | CTs neste arquivo |
|-----|---------|------------------|-------------------|
| **IN-947** | Corrigir fundo amarelo nos campos de login | sim (`acesso-d1.css`) | CT-API-01..06 (regressão do login) + Jest existente |
| IN-948 | Tamanho dos cards de Checklist, Fotos, Serviços e Peças (altura mínima + fallback sem dados) | não (A Fazer) | CT-API-07..11 · `pendente-irma:IN-948` |
| IN-949 | Contraste da logo Certtus no rodapé (logo alterna conforme o fundo claro/escuro) | não (A Fazer) | CT-API-12..14 + CT-API-06 (escuro) · `pendente-irma:IN-949` |

> **Irmãs sem código (IN-948 / IN-949):** pela HARNESS_MULTI_DEV_PR, este primeiro hop já escreve feliz + negativo das duas. As entregas são visuais; os CTs de API são a regressão dos dados que as telas afetadas usam (detalhe e fotos da O.S. para os cards; `GET /portal/{token}` para o tema do rodapé). Na execução, esses CTs saem como `pendente-irma:IN-948` e `pendente-irma:IN-949` e **não bloqueiam** o PASSOU de IN-947. O hop de cada irmã acrescenta CTs se o diff dela trouxer algo novo, sem apagar os existentes. A parte visual (altura mínima, fallback, contraste) está na seção 6.
>
> Descrições no Jira: **IN-948** "Ajustar o dimensionamento dos cards de Checklist, Fotos, Serviços e Peças para ficarem consistentes na web e no mobile. Hoje não tem definido uma altura mínima para quando o card está vazio. Adicionar altura mínima e um fallback para quando não houver dados." · **IN-949** "A logo da Certtus no rodapé tem pouco contraste e fica difícil de ver, principalmente quando o cliente muda as cores do portal. Ajustar para ficar legível em fundos claros e escuros, alternando a imagem da logo conforme a cor de fundo."
>
> `tasks[]` da PT (IN-950, Arquivada) não foi conferido no Jira neste passo; se houver task além das 3 Devs, ela também precisa de CT.

### Jest/Vitest já existente (passo 0) — referência, sem CT novo

| Ref | Arquivo | O que prova | Status |
|-----|---------|-------------|--------|
| JEST-IN-947 | `portalcliente-web/src/styles/__tests__/acessoD1Autofill.test.ts` (10 testes) | `.ds-cf-box` com fundo `--surface-default`; preenchido sem foco só troca a borda; nenhuma regra `.ds-cf-*` usa `--color-gray-50`; `:-webkit-autofill` (+ hover/focus/active) e `:autofill` com inset `--surface-default` e texto `--text-primary`; desabilitado + autofill com inset `--surface-subtle` e texto `--text-tertiary`; rótulo flutua na prévia do autofill | **[EXISTE]** PASSOU (39 arquivos, 203 testes, 0 falhas). Contra o CSS de origin, 9/10 falham |

Limite conhecido: o jsdom não aplica `:autofill` nem `:has()`. O Vitest prova as **regras** do CSS, não a pintura. A pintura fica para a WU Teste (seção 6).

### Massa e ambiente (para o automatizador)

- Base: `E2E_API_BASE_URL` (padrão `http://127.0.0.1:3333`, BFF direto). Helpers a reaproveitar: `tests/e2e/helpers/portalAcessoApiHelpers.ts` (`obterCookiePortalSessao`), `tests/e2e/helpers/portalFixtures.ts` (`C_TOKEN_OK`, `C_TOKEN_REVOGADO`, `C_TOKEN_TEMA_CUSTOM`, `tokenPortalOk()`, `telefoneAutorizado()`), `tests/e2e/helpers/pre-cr/evidenciarApiPreCr.ts`. Padrão de spec: `tests/api/modulo-talk-2638/CT-API-landing.spec.ts`. Spec novo sugerido: `tests/api/modulo-in-946-login-telefone/CT-API-login-telefone.spec.ts`.
- **Stub local do MS.** `scripts/qa/stub-ms-portal-landing.mjs` (8087) não atende `POST /api/v1/servicos/portal/validar-acesso`. `scripts/qa/stub-ms-portal-historico.mjs` (18881) atende, mas decide **só pelo token**: `tokSessaoHist2880Ok` → 200; qualquer outro → 403. Ele **não** confere o telefone e **não** devolve 410 no `validar-acesso`. Para CT-API-02 e CT-API-05 rodarem localmente sem humano, o automatizador precisa de uma destas opções:
  1. estender o stub do **repo de testes** (não o produto): `validar-acesso` devolve 403 quando `cTelefone` difere do autorizado e 410 para o token revogado; ou
  2. rodar contra homolog com `.env.local` (`PORTAL_TOKEN_OK`/`PORTAL_TELEFONE_AUTORIZADO`, `PORTAL_TOKEN_REVOGADO_HOMOLOG`), no padrão de `portalStackHelper.ts`.
  Se nenhuma das duas estiver disponível, o CT fica **BLOQUEADO por massa**, sem `skip` para forçar verde.
- CT-API-03 e CT-API-04 (400) não chegam ao MS: o Zod do BFF rejeita antes. Rodam com qualquer stub.
- **Irmãs.** Spec sugerido: `tests/api/modulo-in-946-login-telefone/CT-API-irmas-in948-in949.spec.ts` (ou um arquivo por irmã). Sessão no padrão `sessaoCriar` de `tests/api/modulo-talk-2866-bff-historico/historicoStub.ts`. CT-API-08, 09, 10 e 11 rodam com o stub 18881 atual; CT-API-07 precisa de uma O.S. com itens (estender o stub ou homolog); CT-API-12 e 14 usam o stub 8087; CT-API-10, 11 e 13 não chegam ao MS. Enquanto IN-948/IN-949 não tiverem código, o resultado deles é `pendente-irma:<key>` (podem rodar como regressão, mas não contam para o PASSOU de IN-947).

---

## 1. API

**Funcionalidade:** Login por telefone do Portal do Cliente (regressão da tela `/{token}` alterada em IN-947)

### CT-API-01 — Login com telefone autorizado abre sessão

**Descrição:**
Validar que o login que a tela de acesso usa continua abrindo sessão quando o link é válido e o telefone é o do cliente da O.S.: HTTP 200, envelope de sucesso com o id público da O.S. e cookie de sessão gravado.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** tela `/{token}` (formulário `acesso-form-login`, botão `acesso-btn-acessar`) → `POST /acesso/telefone` (BFF `acessoController.porTelefone`) · IN-947
**Massa:** token válido (`tokenPortalOk()` em homolog/MS real; `tokSessaoHist2880Ok` + `5511999990000` no stub 18881) e telefone autorizado em E.164 BR (`telefoneAutorizado()`)

**Cenário de teste:**

```gherkin
Cenário: Telefone autorizado recebe sessão do portal
  Dado ter um link público válido do portal
  E ter o telefone do cliente da O.S. em E.164 BR
  Quando enviar POST /acesso/telefone com cToken e cTelefone
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.cOsPublicId não vazio
  E gravar o cookie portal_sessao no Set-Cookie
```

---

### CT-API-02 — Telefone não autorizado é recusado sem sessão

**Descrição:**
Validar que um telefone que não pertence ao cliente da O.S. recebe 403 com envelope de erro e mensagem de acesso negado, que é o que a tela transforma no alerta "Acesso não autorizado". Não pode sair cookie de sessão.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** tela `/{token}` (alerta `role="alert"` de acesso negado) → `POST /acesso/telefone` → 403 · IN-947
**Massa:** token válido + telefone E.164 BR válido porém não autorizado (ex.: `5511888887777`). Local: depende da extensão do stub (ver seção 0); homolog: telefone fora da O.S.

**Cenário de teste:**

```gherkin
Cenário: Telefone fora da O.S. recebe acesso negado
  Dado ter um link público válido do portal
  E ter um telefone em E.164 BR que não pertence ao cliente da O.S.
  Quando enviar POST /acesso/telefone com cToken e esse cTelefone
  Então retornar HTTP 403
  E retornar lSucesso igual a false
  E retornar cMensagem "Acesso não autorizado"
  Mas não gravar o cookie portal_sessao no Set-Cookie
```

---

### CT-API-03 — Body sem telefone é rejeitado como dados inválidos

**Descrição:**
Validar que o BFF rejeita com 400 um pedido de acesso sem `cTelefone` e não consulta o MS nem abre sessão.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `POST /acesso/telefone` → validação `acessoTelefoneBodySchema` (Zod) → 400 · IN-947
**Massa:** token válido (`C_TOKEN_OK`); não depende do stub do MS

**Cenário de teste:**

```gherkin
Cenário: Pedido de acesso sem telefone
  Dado ter um link público válido do portal
  Quando enviar POST /acesso/telefone só com cToken, sem cTelefone
  Então retornar HTTP 400
  E retornar lSucesso igual a false
  E retornar cMensagem "Dados de acesso inválidos."
  Mas não gravar o cookie portal_sessao no Set-Cookie
```

---

### CT-API-04 — Telefone fora do E.164 BR é rejeitado como dados inválidos

**Descrição:**
Validar que um telefone sem o DDI 55 (ou com máscara) é rejeitado com 400. É o formato que a tela precisa normalizar antes de enviar, e o BFF não pode aceitar outro.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `POST /acesso/telefone` → regex `^55\d{10,11}$` do `acessoTelefoneBodySchema` → 400 · IN-947
**Massa:** token válido (`C_TOKEN_OK`) + `cTelefone` = `11999999999` (sem DDI); não depende do stub do MS

**Cenário de teste:**

```gherkin
Cenário: Telefone sem DDI 55
  Dado ter um link público válido do portal
  Quando enviar POST /acesso/telefone com cTelefone sem o DDI 55
  Então retornar HTTP 400
  E retornar lSucesso igual a false
  E retornar cMensagem "Dados de acesso inválidos."
  Mas não gravar o cookie portal_sessao no Set-Cookie
```

---

### CT-API-05 — Link revogado não permite login

**Descrição:**
Validar que o login com um link revogado recebe 410 com envelope de erro, que a tela mostra como "link indisponível". Não pode abrir sessão.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** tela `/{token}` (alerta de link indisponível) → `POST /acesso/telefone` → MS `validar-acesso` 410 propagado por `apiMicroservicosClient.portalValidarAcesso` · IN-947
**Massa:** token revogado (`C_TOKEN_REVOGADO` / `tokLinkHist2880Revogado` no stub estendido, ou `PORTAL_TOKEN_REVOGADO_HOMOLOG`) + `telefoneAutorizado()`. Local: depende da extensão do stub (ver seção 0)

**Cenário de teste:**

```gherkin
Cenário: Login com link revogado
  Dado ter um link público revogado
  E ter um telefone em E.164 BR válido
  Quando enviar POST /acesso/telefone com esse cToken e cTelefone
  Então retornar HTTP 410
  E retornar lSucesso igual a false
  Mas não gravar o cookie portal_sessao no Set-Cookie
```

---

### CT-API-06 — Landing do portal entrega o modo de tema que pinta o campo

**Descrição:**
Validar que `GET /portal/{token}` de um portal com tema escuro devolve `cTemaModo: "escuro"` com sucesso. É desse tema cru que o web deriva `--surface-default` (`#1c1c1c` no escuro), a cor que o campo de telefone passa a usar em todos os estados. Complementa o CT-API-03 de `modulo-talk-2638` (que confere o `--theme-action-primary`) sem duplicá-lo.

**Tag:** [NOVO] · **Prioridade:** P2 (opcional) · **Modalidade:** `automacao-api`
**Cobre:** tela `/{token}` (`landingPortalCarregar` → `TemaPortalAplicar` → `temaProducaoDerivar.ts`) → `GET /portal/{token}` · IN-947 (RN4) · também IN-949 (tema escuro que decide a logo do rodapé; para a IN-949 vale `pendente-irma:IN-949`)
**Massa:** `C_TOKEN_TEMA_CUSTOM` (stub 8087 devolve `cTemaModo: "escuro"`); homolog: portal com tema escuro configurado

**Cenário de teste:**

```gherkin
Cenário: Portal com tema escuro informa o modo na landing
  Dado ter um link público de portal configurado com tema escuro
  Quando enviar GET /portal/{token}
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.cTemaModo igual a "escuro"
```

---

**Funcionalidade:** Dados que montam os cards do detalhe da O.S. (Checklist, Fotos, Serviços, Peças) — **Irmã IN-948**

> IN-948 ainda não tem código na branch. Os CTs abaixo já ficam escritos (HARNESS_MULTI_DEV_PR) e, na execução, saem como `pendente-irma:IN-948`, sem bloquear o PASSOU de IN-947. Quando a entrega da irmã for só visual (altura mínima e fallback de card vazio), estes CTs são a regressão dos dados que a tela usa; a altura e o texto de fallback ficam para a WU Teste (seção 6).

### CT-API-07 — Detalhe da O.S. com sessão devolve as listas dos cards

**Descrição:**
Validar que, com sessão aberta, o detalhe da O.S. devolve sucesso com as listas que alimentam os cards de Checklist, Serviços e Peças, e a ordem das abas. São os dados que os cards dimensionados pela IN-948 renderizam.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Irmã:** IN-948 · **Execução:** `pendente-irma:IN-948`
**Cobre:** tela `/os/{cOsPublicId}` (cards Checklist/Serviços/Peças) → `GET /cliente/os/{cOsPublicId}` (BFF `ordemServicoController.detalhe`) · IN-948
**Massa:** sessão via `POST /acesso/telefone` (padrão `sessaoCriar` de `historicoStub.ts` ou `obterCookiePortalSessao`) de uma O.S. **com** itens de checklist, serviços e peças. O stub 18881 hoje devolve as listas vazias para `tokSessaoHist2880Ok`; para este CT, estender o stub do repo de testes com uma O.S. preenchida ou usar homolog

**Cenário de teste:**

```gherkin
Cenário: Detalhe da O.S. com itens nos cards
  Dado ter sessão aberta no portal para uma O.S. com checklist, serviços e peças
  Quando enviar GET /cliente/os/{cOsPublicId} com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.mChecklist com pelo menos um item
  E retornar oDados.oOrdemServico.mServicos e oDados.oOrdemServico.mPecas com pelo menos uma seção
  E retornar oDados.oOrdemServico.mAbasOrdem com as abas da O.S.
```

---

### CT-API-08 — O.S. sem itens devolve listas vazias (massa do card vazio)

**Descrição:**
Validar que uma O.S. sem checklist, serviços e peças devolve sucesso com as listas **vazias** (`[]`), nunca ausentes ou nulas. É o caso que aciona a altura mínima e o fallback "sem dados" pedidos na IN-948, e a tela não pode quebrar por falta do campo.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Irmã:** IN-948 · **Execução:** `pendente-irma:IN-948`
**Cobre:** tela `/os/{cOsPublicId}` (fallback de card vazio) → `GET /cliente/os/{cOsPublicId}` (contrato `detalheOrdemServicoSchema`: `mChecklist`/`mServicos`/`mPecas` obrigatórios, `mFotos: []`) · IN-948
**Massa:** stub 18881 já atende: sessão com `tokSessaoHist2880Ok` + `5511999990000` devolve `mChecklist`, `mServicos`, `mPecas` e `mTimeline` vazios. Homolog: O.S. recém-aberta sem itens

**Cenário de teste:**

```gherkin
Cenário: Detalhe da O.S. sem itens nos cards
  Dado ter sessão aberta no portal para uma O.S. sem checklist, serviços e peças
  Quando enviar GET /cliente/os/{cOsPublicId} com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.mChecklist, mServicos e mPecas como listas vazias
  E retornar oDados.oOrdemServico.mFotos como lista vazia
  Mas não omitir nenhuma dessas listas nem devolver null
```

---

### CT-API-09 — Fotos da O.S. com sessão devolve as fotos por fase

**Descrição:**
Validar que o endpoint do card de Fotos devolve sucesso com as fotos agrupadas por fase, que é o conteúdo do card de Fotos citado na IN-948.

**Tag:** [NOVO] · **Prioridade:** P2 · **Modalidade:** `automacao-api`
**Irmã:** IN-948 · **Execução:** `pendente-irma:IN-948`
**Cobre:** tela `/os/{cOsPublicId}` (card Fotos) → `GET /cliente/os/{cOsPublicId}/fotos` (BFF `fotosController.listar`) · IN-948
**Massa:** stub 18881 já atende (`tokSessaoHist2880Ok` devolve 1 fase com 1 foto). Homolog: O.S. com foto de recepção

**Cenário de teste:**

```gherkin
Cenário: Fotos da O.S. agrupadas por fase
  Dado ter sessão aberta no portal para uma O.S. com foto registrada
  Quando enviar GET /cliente/os/{cOsPublicId}/fotos com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.mFotosPorFase com pelo menos uma fase contendo foto
```

---

### CT-API-10 — Detalhe da O.S. sem sessão é recusado

**Descrição:**
Validar que o detalhe da O.S. sem cookie de sessão recebe 401 com envelope de erro e não devolve dados dos cards.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Irmã:** IN-948 · **Execução:** `pendente-irma:IN-948`
**Cobre:** `GET /cliente/os/{cOsPublicId}` → `autorizarDetalheOs` (sem sessão → 401) · IN-948
**Massa:** qualquer `cOsPublicId` (ex.: `tokSessaoHist2880Ok`), contexto de request **sem** cookie; não depende do MS

**Cenário de teste:**

```gherkin
Cenário: Detalhe da O.S. sem sessão
  Dado não ter sessão aberta no portal
  Quando enviar GET /cliente/os/{cOsPublicId} sem o cookie portal_sessao
  Então retornar HTTP 401
  E retornar lSucesso igual a false
  E retornar cMensagem "Sessão não autenticada"
  Mas não retornar oDados com as listas dos cards
```

---

### CT-API-11 — Detalhe de O.S. que não é da sessão é recusado

**Descrição:**
Validar que, com sessão aberta, pedir o detalhe de outro `cOsPublicId` recebe 403 e não vaza os cards de outra O.S. Este é o "id inválido" alcançável por HTTP: o `cOsPublicIdParamsSchema` só exige `min(1)`, e um segmento vazio cai na rota de listagem, então o 400 "Identificador da OS inválido." não é exercitável pela URL.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Irmã:** IN-948 · **Execução:** `pendente-irma:IN-948`
**Cobre:** `GET /cliente/os/{cOsPublicId}` → `autorizarDetalheOs` (mismatch sessão ↔ rota → 403) · IN-948
**Massa:** sessão com `tokSessaoHist2880Ok` + pedido de `tokAlvoHist2880Negado` (ou qualquer id diferente do da sessão); não depende do MS

**Cenário de teste:**

```gherkin
Cenário: Detalhe de O.S. de outro cliente
  Dado ter sessão aberta no portal para uma O.S.
  Quando enviar GET /cliente/os/{outroCOsPublicId} com o cookie portal_sessao
  Então retornar HTTP 403
  E retornar lSucesso igual a false
  E retornar cMensagem "Acesso não autorizado"
  Mas não retornar oDados com as listas dos cards
```

---

**Funcionalidade:** Tema do portal que decide a variante da logo Certtus no rodapé — **Irmã IN-949**

> IN-949 ainda não tem código na branch. Os CTs abaixo já ficam escritos e, na execução, saem como `pendente-irma:IN-949`. O rodapé (`RodapeOficinaPortal` / `AssinaturaCerttus`) aparece na tela de acesso `/{token}` e no detalhe da O.S.; a cor de fundo dele vem do tema do portal (`cTemaModo`, `oTemaAvancado`, `oTokensDerivados`) entregue por `GET /portal/{token}`. O caso **escuro** já está escrito no CT-API-06 e passa a valer também para a IN-949 (ver `Cobre:` dele); aqui fica o caso **claro** e os negativos.

### CT-API-12 — Landing de portal com tema claro entrega o tema do rodapé

**Descrição:**
Validar que `GET /portal/{token}` de um portal em tema claro devolve sucesso sem `cTemaModo: "escuro"` e com os tokens de cor derivados. É desse dado que a IN-949 escolhe a logo para fundo claro.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Irmã:** IN-949 · **Execução:** `pendente-irma:IN-949`
**Cobre:** tela `/{token}` (rodapé com `AssinaturaCerttus`) → `GET /portal/{token}` (BFF `portalController.landing`) · IN-949
**Massa:** `C_TOKEN_OK` (stub 8087 sem `cTemaModo`, que o web trata como claro; `oTemaSimples.corPrimaria #1a5276`). Homolog: portal com tema claro

**Cenário de teste:**

```gherkin
Cenário: Portal com tema claro informa o tema na landing
  Dado ter um link público de portal configurado com tema claro
  Quando enviar GET /portal/{token}
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.cTemaModo ausente ou igual a "claro"
  E retornar oDados.oTokensDerivados com as cores do tema
```

---

### CT-API-13 — Landing com token malformado é rejeitada sem tema

**Descrição:**
Validar que um token fora do formato aceito (mais de 64 caracteres) recebe 400 "Token inválido." e nenhum dado de tema, para a tela não montar o rodapé com tema indefinido.

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Irmã:** IN-949 · **Execução:** `pendente-irma:IN-949`
**Cobre:** `GET /portal/{token}` → `portalTokenParamsSchema` (`min(1)`, `max(64)`) → 400 · IN-949
**Massa:** token com 65 caracteres (ex.: `'x'.repeat(65)`); não depende do MS

**Cenário de teste:**

```gherkin
Cenário: Landing com token acima de 64 caracteres
  Dado ter um token de link com mais de 64 caracteres
  Quando enviar GET /portal/{token}
  Então retornar HTTP 400
  E retornar lSucesso igual a false
  E retornar cMensagem "Token inválido."
  Mas não retornar oDados com tema
```

---

### CT-API-14 — Landing com token inexistente não entrega tema

**Descrição:**
Validar que um token bem formado mas sem link cadastrado recebe 404 com envelope de erro e sem tema. Complementa o negativo de link revogado (410) que já existe em `modulo-talk-2638` (CT-API-02), sem duplicá-lo.

**Tag:** [NOVO] · **Prioridade:** P2 · **Modalidade:** `automacao-api`
**Irmã:** IN-949 · **Execução:** `pendente-irma:IN-949`
**Cobre:** `GET /portal/{token}` → MS 404 propagado por `apiMicroservicosClient` · IN-949
**Massa:** token inexistente (ex.: `tokNaoExisteIN949XXXX`); stub 8087 devolve 404 para token desconhecido

**Cenário de teste:**

```gherkin
Cenário: Landing com token sem link cadastrado
  Dado ter um token de link bem formado que não existe
  Quando enviar GET /portal/{token}
  Então retornar HTTP 404
  E retornar lSucesso igual a false
  Mas não retornar oDados com tema
```

---

## 2. Smoke automatizado

N/A neste hop (WU Teste). `qa-pre-cr`: proibido gerar ou rodar `CT-SMK-*`.

---

## 3. E2E — Caminho feliz

N/A neste hop (WU Teste). Proibido gerar `CT-E2E-*` e rodar `tests/e2e/specs/modulo-talk-2667-login-d1/login-d1-portal.spec.ts` (CT-E2E-01..03, já existentes, não renomeados).

---

## 4. E2E — Caminho negativo

N/A neste hop (WU Teste).

---

## 5. Manual (somente UI)

N/A neste hop. Nenhum CT manual foi criado. A sugestão de checagem visual, incluindo o autofill real que exige humano, está na seção 6 para a WU Teste classificar.

---

## 6. Sugestões para a WU Teste (não são CTs deste hop)

Estas checagens validam a **pintura** que o Vitest não alcança. A WU Teste decide se viram Smoke/E2E ou Manual:

1. **Fundo em foco / saída do foco com valor / desabilitado** (automatizável, Playwright): em `/{token}` (ou `/preview`, que dispensa o BFF), `getComputedStyle(.ds-cf-box).backgroundColor` deve ser o `--surface-default` resolvido (branco no tema padrão, `#1c1c1c` ou `authCard` no escuro), nunca `--color-gray-50`. Desabilitado ("Autenticando…") = `--surface-subtle`. Rodar em pelo menos tema padrão, tema custom e modo escuro (`C_TOKEN_TEMA_CUSTOM`).
2. **Bordas sem regressão** (automatizável): hover `--color-gray-400`, foco `--theme-action-primary` + focus ring, erro `--color-feedback-error-100`, preenchido sem foco `--color-gray-500`.
3. **Autopreenchimento real do navegador** (**manual**: o Chromium headless não dispara `:-webkit-autofill` por `fill()` e não há perfil com telefone salvo): escolher a sugestão de telefone salvo e conferir que o amarelo/azul nativo não aparece, que o texto usa a cor do tema e que o rótulo já sobe na prévia. Repetir no escuro e com o campo em erro (rótulo no topo com cor de erro, o que é esperado). Alternativa automatizável a avaliar: `page.evaluate` com `CSS.supports('selector(:autofill)')` mais checagem das regras em `document.styleSheets`, sem fingir que houve autofill.
4. **Firefox/Safari:** `:autofill` e `:-webkit-autofill` estão em blocos separados; conferir que um seletor não suportado não derruba o outro.
5. **Rótulo do autofill no Firefox (IN-947):** a prévia do rótulo só existe como `.ds-cf-input:-webkit-autofill + .ds-cf-label`; não há a versão `:autofill`. Conferir no Firefox se o rótulo sobe na prévia do autopreenchimento ou fica por cima do número (manual, mesmo motivo do item 3).
6. **Cards da O.S. (IN-948, quando houver código):** em `/os/{cOsPublicId}`, medir a altura computada dos cards Checklist, Fotos, Serviços e Peças com e sem itens (massa do CT-API-08), na web e em viewport mobile; card vazio respeita a altura mínima e mostra o texto de fallback, sem colapsar.
7. **Logo do rodapé (IN-949, quando houver código):** na tela de acesso e no detalhe da O.S., conferir que a imagem da logo Certtus troca entre as variantes para fundo claro e escuro (tema padrão, `C_TOKEN_TEMA_CUSTOM` escuro e um tema avançado com cor de fundo customizada) e que o contraste fica legível.

---

## Resumo

| Categoria | Qtde | Plataforma |
|-----------|------|------------|
| API IN-947 (`CT-API-01..06`) | 6 (2 P0, 3 P1, 1 P2 opcional) | web / BFF `portalcliente-api` |
| API IN-948 (`CT-API-07..11`) | 5 (3 feliz, 2 negativo) · `pendente-irma:IN-948` | BFF `portalcliente-api` |
| API IN-949 (`CT-API-12..14` + CT-API-06 escuro) | 3 novos (1 feliz, 2 negativo) · `pendente-irma:IN-949` | BFF `portalcliente-api` |
| Jest/Vitest | referência (10 testes existentes, sem CT novo) | `portalcliente-web` |
| Smoke / E2E | 0 — N/A neste hop (WU Teste) | — |
| Manual | 0 — sugestões na seção 6 | — |
| **Total CT-API** | 14 (só CT-API-01..06 contam para o PASSOU de IN-947) | — |

> **Aguarda aprovação humana** (gate `aprovar_cenarios_pre_cr`) antes de seguir para a automação dos CT-API (`qa-automatizador`, modo `qa-pre-cr`). O timer `cenarios` em `tempos-pipeline.md` segue aberto até a aprovação.
