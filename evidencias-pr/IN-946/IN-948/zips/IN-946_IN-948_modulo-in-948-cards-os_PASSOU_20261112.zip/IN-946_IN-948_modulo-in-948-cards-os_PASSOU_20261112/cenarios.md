# Cenários de teste — `modulo-in-948-cards-os`

> Produto: **Portal do Cliente** (`portal`) · repo de testes `testes-automatizados-Portal`
> História (parentKey): **IN-946** · Dev do hop: **IN-948** · subtarefa Cenários: **IN-951**
> Base: `contexto-pr.md` (passo 1) e `jest-validacao.md` (passo 0)
> Pipeline: **QA_PRE_CR** (hop Dev) · modo `api-smoke` · `proibidoE2e: true`
> `cenariosOrigem: gerado-na-dev` (sem CTs importados de subtarefa HU nem MeloQA). CT-API-01..05 vieram de `modulo-in-946-login-telefone`, onde eram CT-API-07..11 (`pendente-irma:IN-948`)
> Stack deste hop: **Vitest (produto) + API (Playwright projeto `api`)**. Smoke e E2E ficam para a WU Teste.
> Formato: **Título → Descrição → Cenário (BDD)** · passos no **infinitivo**
> Data: 2026-11-12

## Legenda

| Tag | Significado |
|-----|-------------|
| **[EXISTE]** | Já automatizado (spec existente) |
| **[NOVO]** | Cenário novo — candidato a automação |
| **[GAP]** | Ainda não automatizado |

**Modalidades:** `manual` · `automacao-api` · `automacao-playwright` · `jest`
**Prioridade:** P0 · P1 · P2

**Classificação humano x runner** (rule `qa-automacao-sem-humano`): os 8 CTs de API abaixo (CT-API-01..08) vão até PASS sem ninguém interagir. É HTTP direto no BFF, com sessão aberta por `obterCookiePortalSessao` e massa do stub `scripts/qa/stub-ms-portal-landing.mjs` (8087). Nenhum depende de OTP, câmera ou diálogo de navegador.

---

## 0. Escopo e inventário do pai

### Entrega deste hop (IN-948)

- Diff do produto (`portalcliente-web`, branch `historia/IN-946-ajustes-visuais-portal`, working tree ainda não commitado): **só front**.
  1. Altura das abas da O.S.: aba sem conteúdo (e carregando/erro) com altura fixa 315px (>=1024px) / 270px (abaixo) pelo token `--portal-os-abas-altura-vazio`; aba com conteúdo tem altura mínima igual à do vazio e cresce pelo conteúdo, sem rolagem interna (alterações 3 e 4 do humano, substituem 420/360 com rolagem).
  2. Normalização defensiva das listas dos cards e de `mAbasOrdem` (`cardsOsNormalizar.ts` + schemas Zod do front): dado ausente, nulo ou malformado vira lista vazia ou ordem padrão.
  3. Estados de painel padronizados (`EstadoPainelAba`: vazio, carregando, erro), placeholder "Foto indisponível" e manutenção do dado já carregado quando o polling falha.
- O BFF (`portalcliente-api`) **não mudou**. Os CTs de API são a **regressão do contrato** que alimenta os cards: `GET /cliente/os/{id}` (Checklist, Serviços, Peças, ordem das abas) e `GET /cliente/os/{id}/fotos` (Fotos). As regras de tela RN1–RN12 do `contexto-pr.md` são provadas no Vitest do produto (tabela abaixo) e, na WU Teste, em Smoke/E2E (seção 6).

### Inventário do pai (HARNESS_MULTI_DEV_PR)

| Dev | Assunto | Código na branch | CTs |
|-----|---------|------------------|-----|
| IN-947 | Fundo amarelo nos campos de login | sim (Concluído - Aprovado) | `modulo-in-946-login-telefone` CT-API-01..06 |
| **IN-948** | Tamanho dos cards de Checklist, Fotos, Serviços e Peças (altura padrão + fallback sem dados) | sim (working tree) | **este arquivo**, CT-API-01..08. Contam para o PASSOU da IN-948 |
| IN-949 | Contraste da logo Certtus no rodapé | não (A Fazer) | `modulo-in-946-login-telefone` CT-API-12..14 + CT-API-06 (escuro) · `pendente-irma:IN-949` |

> As irmãs já têm feliz + negativo escritos no módulo da IN-947. Este arquivo não os duplica. `tasks[]` da PT (IN-950, Arquivada) não foi conferido no Jira neste passo, a mesma ressalva do módulo da IN-947.

### Vitest do produto (passo 0) — referência, sem CT novo

| Ref | Arquivo (`portalcliente-web`) | O que prova | Regras |
|-----|-------------------------------|-------------|--------|
| JEST-IN-948-01 | `src/styles/__tests__/autenticadoD4AbasAltura.test.ts` (novo, 2) | token `--portal-os-abas-altura-vazio` 270px, 315px em `min-width: 1024px`; painel sem `height`/`overflow-y`; `.autenticado-d4__abas-estado` com altura pelo token | RN1 |
| JEST-IN-948-02 | `src/components/organisms/__tests__/AbasDetalheOs.test.tsx` (+5) | mesmo painel focável nas 4 abas; quantidade nula vira "—"; seção sem itens some; abas duplicadas viram 4; descrições repetidas aparecem todas | RN1, RN3, RN6, RN12 |
| JEST-IN-948-03 | `src/components/organisms/__tests__/PainelFotosOs.test.tsx` (+3) | galeria mantida no erro de polling; erro sem dado com "Tentar novamente"; carregando e vazio dentro do painel | RN2, RN10, RN11 |
| JEST-IN-948-04 | `src/components/organisms/__tests__/PainelDetalheOs.test.tsx` (+1) | conteúdo mantido no erro de atualização | RN11 |
| JEST-IN-948-05 | `src/components/molecules/__tests__/GaleriaFotoPreview.test.tsx` (novo, 2) | imagem que falha vira placeholder | RN9 |
| JEST-IN-948-06 | `src/hooks/__tests__/useFotosOs.test.tsx` (novo, 3) | envelope malformado vira mensagem amigável; `lSucesso: false` mostra `cMensagem`; sucesso normalizado | RN10 |
| JEST-IN-948-07 | `src/hooks/__tests__/useDetalheOrdemServico.test.tsx` (+2) | idem para o detalhe | RN10 |
| JEST-IN-948-08 | `src/services/__tests__/cardsOsNormalizar.test.ts` (novo, 30) | normalização de checklist, serviços, peças, ordem das abas e fotos | RN2–RN8, RN12 |
| JEST-IN-948-09 | `src/schemas/__tests__/ordemServicoSchema.test.ts` (+4) e `fotosOsSchema.test.ts` (+3) | listas nulas/ausentes viram `[]`; itens, seções e fotos malformados filtrados; ordem padrão sem duplicadas | RN2, RN5, RN8, RN12 |

**Status:** **[EXISTE]** PASSOU (44 arquivos, 267 testes, 0 falhas; `tsc --noEmit` OK). Limite: o jsdom não aplica layout, então o Vitest prova as regras do CSS e não a altura renderizada (fica para a WU Teste).

### Massa e ambiente (para o automatizador)

- Base: `E2E_API_BASE_URL` (BFF direto). O BFF local precisa de `API_MICROSERVICOS_BASE_URL=http://127.0.0.1:8087` com `node scripts/qa/stub-ms-portal-landing.mjs` rodando. Telefone autorizado: `QA_STUB_TELEFONE_AUTORIZADO` (padrão `5511999999999`).
- Helpers: `tests/api/modulo-in-946-login-telefone/loginD1Api.ts` (`C_TOKEN_OS_COM_ITENS`, `C_TOKEN_OS_SEM_ITENS`, `C_TOKEN_OS_OUTRA`, `C_MENSAGEM_ACESSO_NEGADO`, `cookieHeaderDe`, `respostaApiLer`) e `tests/e2e/helpers/portalAcessoApiHelpers.ts` (`obterCookiePortalSessao`).
- Spec: `tests/api/modulo-in-948-cards-os/CT-API-cards-os.spec.ts` (CT-API-01..05 já existem). CT-API-06..08 entram no mesmo arquivo.
- Massa do stub:
  - `tokOsComItensIN948XXX`: checklist com 2 itens, seção "Motor" em serviços e em peças, 1 foto na fase `recepcao`.
  - `tokOsSemItensIN948XXX`: todas as listas `[]`, `mFotosPorFase: []`, `mAbasOrdem` com as 4 abas.
  - `tokOsOutraIN948XXXXXX`: não existe no stub. O 403 vem da autorização do BFF (sessão de outra O.S.), antes de chamar o MS.
- **Nenhum CT precisa de mudança no stub.** CT-API-04 e 07 (sem sessão) não chegam ao MS. CT-API-05 e 08 chegam: o BFF trata a O.S. de outra sessão como acesso de histórico, chama o MS com `x-portal-token-origem`, o stub responde 403 (origem ≠ token) e o BFF devolve 403 "Acesso não autorizado".

---

## 1. API

**Funcionalidade:** Dados dos cards da O.S. (Checklist, Fotos, Serviços e Peças), regressão do contrato que alimenta a tela `/os/{cOsPublicId}` alterada na IN-948

### CT-API-01 — Detalhe da O.S. com sessão devolve as listas dos cards

**Descrição:**
Validar que o detalhe da O.S. que a página usa para montar as abas devolve, com sessão válida, as listas de Checklist, Serviços e Peças preenchidas e a ordem das 4 abas. É o caminho em que a tela mostra os cards com conteúdo dentro do painel de altura padrão.

**Tag:** [EXISTE] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (`AbasDetalheOs`: abas Checklist, Serviços e Peças com itens) → `GET /cliente/os/{id}` (`ordemServicoController.detalhe`) · IN-948 (RN1, RN12)
**Massa:** sessão aberta com `tokOsComItensIN948XXX` + telefone autorizado; detalhe da mesma O.S.

**Cenário de teste:**

```gherkin
Cenário: O.S. com itens entrega as listas dos cards
  Dado ter uma sessão do portal aberta para uma O.S. com checklist, serviços e peças
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.mChecklist com pelo menos 1 item
  E retornar oDados.oOrdemServico.mServicos com pelo menos 1 seção
  E retornar oDados.oOrdemServico.mPecas com pelo menos 1 seção
  E retornar oDados.oOrdemServico.mAbasOrdem contendo checklist, fotos, servicos e pecas
```

---

### CT-API-02 — O.S. sem itens devolve listas vazias

**Descrição:**
Validar que uma O.S. sem itens devolve as listas dos cards como arrays vazios, e não ausentes nem nulas. É a entrada que faz a tela mostrar o texto de vazio de cada aba (RN2) sem mudar a altura do painel.

**Tag:** [EXISTE] + asserção nova de `mAbasOrdem` (aprovada no gate) · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (`EstadoPainelAba` variante `vazio` em Checklist, Serviços e Peças, com as 4 abas visíveis) → `GET /cliente/os/{id}` · IN-948 (RN2, RN12)
**Massa:** sessão aberta com `tokOsSemItensIN948XXX`; detalhe da mesma O.S.

**Cenário de teste:**

```gherkin
Cenário: O.S. sem itens entrega listas vazias
  Dado ter uma sessão do portal aberta para uma O.S. sem checklist, serviços, peças nem fotos
  Quando enviar GET /cliente/os/{id} dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.oOrdemServico.mChecklist como lista vazia
  E retornar oDados.oOrdemServico.mServicos como lista vazia
  E retornar oDados.oOrdemServico.mPecas como lista vazia
  E retornar oDados.oOrdemServico.mFotos como lista vazia
  E retornar oDados.oOrdemServico.mAbasOrdem igual a checklist, fotos, servicos e pecas, nessa ordem
```

---

### CT-API-03 — Fotos da O.S. com sessão devolve as fotos por fase

**Descrição:**
Validar que a lista de fotos que a aba Fotos consome devolve, com sessão válida, pelo menos uma fase com foto. É o caminho em que a tela monta a galeria por fase.

**Tag:** [EXISTE] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (`PainelFotosOs` → `FaseFotosCollapse` / `GaleriaFotoPreview`) → `GET /cliente/os/{id}/fotos` (`fotosController.listar`) · IN-948 (RN8)
**Massa:** sessão aberta com `tokOsComItensIN948XXX`; fotos da mesma O.S. (1 foto na fase `recepcao`)

**Cenário de teste:**

```gherkin
Cenário: O.S. com fotos entrega as fotos agrupadas por fase
  Dado ter uma sessão do portal aberta para uma O.S. com foto registrada
  Quando enviar GET /cliente/os/{id}/fotos dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.mFotosPorFase com pelo menos 1 fase contendo foto
```

---

### CT-API-04 — Detalhe da O.S. sem sessão é recusado

**Descrição:**
Validar que o detalhe da O.S. sem cookie de sessão recebe 401 com envelope de erro e nenhum dado da O.S., para os cards nunca serem montados sem login.

**Tag:** [EXISTE] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (acesso sem sessão) → `GET /cliente/os/{id}` → `autorizarDetalheOs` → 401 · IN-948 (RN13)
**Massa:** `tokOsComItensIN948XXX`, sem cookie; não chega ao MS

**Cenário de teste:**

```gherkin
Cenário: Detalhe da O.S. pedido sem sessão
  Dado não ter sessão do portal
  Quando enviar GET /cliente/os/{id} de uma O.S. existente sem o cookie portal_sessao
  Então retornar HTTP 401
  E retornar lSucesso igual a false
  E retornar cMensagem "Sessão não autenticada"
  Mas não retornar oDados.oOrdemServico
```

---

### CT-API-05 — Detalhe de O.S. que não é da sessão é recusado

**Descrição:**
Validar que uma sessão aberta para uma O.S. não consegue ler o detalhe de outra O.S.: 403 com mensagem de acesso negado e sem dados dos cards.

**Tag:** [EXISTE] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (O.S. de outro cliente) → `GET /cliente/os/{id}` → `autorizarDetalheOs` → 403 · IN-948 (RN13)
**Massa:** sessão aberta com `tokOsSemItensIN948XXX`; rota com `tokOsOutraIN948XXXXXX`; chega ao MS como acesso de histórico e o stub recusa com 403 (origem ≠ token)

**Cenário de teste:**

```gherkin
Cenário: Detalhe de O.S. de outra sessão
  Dado ter uma sessão do portal aberta para uma O.S.
  Quando enviar GET /cliente/os/{id} de outra O.S. com esse cookie portal_sessao
  Então retornar HTTP 403
  E retornar lSucesso igual a false
  E retornar cMensagem "Acesso não autorizado"
  Mas não retornar oDados.oOrdemServico
```

---

### CT-API-06 — O.S. sem fotos devolve lista de fases vazia

**Descrição:**
Validar que a lista de fotos de uma O.S. sem fotos devolve sucesso com `mFotosPorFase` como array vazio, e não ausente, nulo nem erro. É a entrada que faz a aba Fotos mostrar "Ainda não há fotos disponíveis para esta ordem de serviço." (RN2) em vez do estado de erro.

**Tag:** [NOVO] (aprovado no escopo) · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (`PainelFotosOs` → `EstadoPainelAba` variante `vazio` na aba Fotos) → `GET /cliente/os/{id}/fotos` (`fotosController.listar`) · IN-948 (RN2)
**Massa:** sessão aberta com `tokOsSemItensIN948XXX`; fotos da mesma O.S. (stub devolve `mFotosPorFase: []`)

**Cenário de teste:**

```gherkin
Cenário: O.S. sem fotos entrega lista de fases vazia
  Dado ter uma sessão do portal aberta para uma O.S. sem fotos registradas
  Quando enviar GET /cliente/os/{id}/fotos dessa O.S. com o cookie portal_sessao
  Então retornar HTTP 200
  E retornar lSucesso igual a true
  E retornar oDados.mFotosPorFase como lista vazia
```

---

### CT-API-07 — Fotos da O.S. sem sessão são recusadas

**Descrição:**
Validar que a lista de fotos sem cookie de sessão recebe 401 com envelope de erro e nenhuma foto. Hoje só o detalhe tem esse negativo; a aba Fotos faz uma chamada própria (com polling de 30 s), e o diff mexeu no tratamento de erro dessa chamada (`useFotosOs`).

**Tag:** [NOVO] (aprovado no gate) · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (aba Fotos sem sessão → estado de erro do painel) → `GET /cliente/os/{id}/fotos` → `autorizarDetalheOs` → 401 · IN-948 (RN10, RN13)
**Massa:** `tokOsComItensIN948XXX`, sem cookie; não chega ao MS

**Cenário de teste:**

```gherkin
Cenário: Fotos da O.S. pedidas sem sessão
  Dado não ter sessão do portal
  Quando enviar GET /cliente/os/{id}/fotos de uma O.S. com fotos sem o cookie portal_sessao
  Então retornar HTTP 401
  E retornar lSucesso igual a false
  E retornar cMensagem "Sessão não autenticada"
  Mas não retornar oDados.mFotosPorFase
```

---

### CT-API-08 — Fotos de O.S. que não é da sessão são recusadas

**Descrição:**
Validar que uma sessão aberta para uma O.S. não consegue ler as fotos de outra O.S.: 403 com mensagem de acesso negado e sem fotos. Fecha o par feliz + negativo do endpoint de fotos.

**Tag:** [NOVO] (aprovado no gate) · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** tela `/os/{cOsPublicId}` (aba Fotos de O.S. de outro cliente → "Acesso não autorizado") → `GET /cliente/os/{id}/fotos` → `autorizarDetalheOs` → 403 · IN-948 (RN13)
**Massa:** sessão aberta com `tokOsSemItensIN948XXX`; rota com `tokOsOutraIN948XXXXXX`; chega ao MS como acesso de histórico e o stub recusa com 403 (origem ≠ token)

**Cenário de teste:**

```gherkin
Cenário: Fotos de O.S. de outra sessão
  Dado ter uma sessão do portal aberta para uma O.S.
  Quando enviar GET /cliente/os/{id}/fotos de outra O.S. com esse cookie portal_sessao
  Então retornar HTTP 403
  E retornar lSucesso igual a false
  E retornar cMensagem "Acesso não autorizado"
  Mas não retornar oDados.mFotosPorFase
```

---

## 2. Smoke automatizado

N/A neste hop (WU Teste). `qa-pre-cr`: proibido gerar ou rodar `CT-SMK-*`.

---

## 3. E2E — Caminho feliz

N/A neste hop (WU Teste). Proibido gerar `CT-E2E-*` e percorrer a tela da O.S. por MCP (rule `qa-pre-cr-sem-e2e`).

---

## 4. E2E — Caminho negativo

N/A neste hop (WU Teste).

---

## 5. Manual (somente UI)

N/A neste hop. Nenhum CT depende de humano: altura, vazio, placeholder de imagem e erro são simuláveis com o stub ou com `page.route`. As checagens visuais ficam como sugestão na seção 6, para a WU Teste classificar.

---

## 6. Sugestões para a WU Teste (não são CTs deste hop)

Estas checagens validam no navegador o que o Vitest prova só em regra. A WU Teste decide se viram Smoke/E2E (Playwright, automatizável) ou Manual:

1. **Altura padrão entre as abas (RN1):** em `/os/{id}` (ou `/preview`, sem BFF), aba vazia, carregando ou erro: `[role=tabpanel]` com 315px em 1280×800 e 270px em 390×844 e 1023×768 (inclui o padding); aba com conteúdo: no mínimo 315/270 e cresce pelo conteúdo, sem barra de rolagem interna (`scrollHeight == clientHeight`). Fotos vazia: sem a ilustração `/fallback/fotos-vazio.webp` aparece só a frase, sem ícone quebrado.
2. **Rolagem interna e teclado (RN1):** com a O.S. com itens, o conteúdo maior que o painel rola dentro dele, sem empurrar o rodapé. Tab chega ao painel (`tabIndex=0`) e as setas Esquerda/Direita trocam de aba.
3. **Estados vazios (RN2):** com `tokOsSemItensIN948XXX`, cada aba mostra o texto próprio dentro do painel (`data-testid="estado-painel-aba"`, `data-variante="vazio"`): "Nenhum item de checklist registrado para esta O.S.", "Ainda não há fotos disponíveis para esta ordem de serviço.", "Nenhum serviço registrado para esta O.S.", "Nenhuma peça registrada para esta O.S.". A altura é a mesma da O.S. com itens.
4. **Foto indisponível (RN9):** com `tokOsComItensIN948XXX`, a foto aponta para `https://cdn.example.com/...`, que não carrega: a miniatura e o lightbox mostram "Foto indisponível". Para o caso "imagem carrega", servir uma imagem por `page.route` ou usar `/preview`.
5. **Mensagens amigáveis (RN10):** interceptar `/api/bff/cliente/os/{id}/fotos` e `/api/bff/cliente/os/{id}` com `page.route` devolvendo 200 + envelope que o front não consegue validar (ex.: `oDados` ausente). A tela mostra "Não foi possível carregar as fotos agora." com "Tentar novamente" (que refaz a chamada) e "Não foi possível carregar o detalhe desta ordem de serviço.", sem texto técnico. Com `lSucesso: false` e `cMensagem` preenchida, aparece essa mensagem. O stub MS não serve aqui, porque o BFF recusa payload malformado antes (ver observação 1).
6. **Dado mantido no polling (RN11):** carregar a O.S., fazer a segunda chamada falhar via `page.route` e disparar o revalidar por foco (em vez de esperar 30 s). O detalhe, o rodapé da oficina e a galeria continuam na tela. Com `mFotosPorFase` vazio e erro no polling, aparece o estado de erro no lugar do vazio (comportamento esperado).
7. **Quantidade e seções (RN3–RN6):** via `page.route` com quantidade nula, seção sem nome e seção sem itens: a tela mostra "—", "Outros serviços"/"Outras peças" e esconde a seção vazia.
8. **Abas desligadas (RN12):** `mAbasOrdem: []` esconde a seção de abas inteira; abas duplicadas aparecem uma vez só.

---

## Observações para o revisor / CR (não são bugs da IN-948)

1. **BFF devolve 400 "Identificador da OS inválido." para payload malformado do MS** (comportamento que já existia, BFF fora do diff). A mensagem engana, porque o problema é o payload e não o id, e a tela mostra a mensagem genérica de HTTP 400 em vez dos textos da RN10. Por isso os fallbacks de dado malformado não são provados por API, e sim pelo Vitest e por `page.route` na WU Teste.
2. ~~`pUrlFotoValida` aceita `/\host`~~ — corrigido: recusa `//host` e `/\host` (caso Vitest `f7`).
3. **`ConteudoDetalheOsAutenticado.tsx`** mudou 2 linhas sem teste próprio. O comportamento está provado em `PainelDetalheOs` e `PainelFotosOs`; a checagem visual de "erro + rodapé" está no item 6 da seção 6.
4. **Decidido no gate:** o CT-API-02 ganhou a asserção `mAbasOrdem` com as 4 abas na ordem padrão.

---

## Resumo

| Categoria | Qtde | Plataforma |
|-----------|------|------------|
| API existentes (`CT-API-01..05`, renumerados de CT-API-07..11 do módulo da IN-947) | 5 (2 P0, 3 P1) · 3 feliz, 2 negativo | web / BFF `portalcliente-api` |
| API novo aprovado (`CT-API-06`, O.S. sem fotos) | 1 (P0) · feliz (entrada do vazio das Fotos) | BFF `portalcliente-api` |
| API novo aprovado no gate (`CT-API-07`, `CT-API-08`, 401/403 em `/fotos`) | 2 (P1) · negativo | BFF `portalcliente-api` |
| Vitest | referência (267 testes PASSOU, sem CT novo) | `portalcliente-web` |
| Smoke / E2E | 0 — N/A neste hop (WU Teste) | — |
| Manual | 0 — sugestões na seção 6 | — |
| **Total CT-API** | 8. Todos contam para o PASSOU da IN-948 | — |

Par feliz + negativo por endpoint: `GET /cliente/os/{id}` → CT-API-01, 02 / CT-API-04, 05. `GET /cliente/os/{id}/fotos` → CT-API-03, 06 / CT-API-07, 08 (sem eles, o endpoint de fotos fica só com casos felizes).

> **Aprovado** no gate `aprovar_cenarios_pre_cr` (2026-11-12): cenários aprovados, CT-API-07/08 incluídos, CT-API-02 com `mAbasOrdem`. Próximo: `qa-automatizador` (API).
