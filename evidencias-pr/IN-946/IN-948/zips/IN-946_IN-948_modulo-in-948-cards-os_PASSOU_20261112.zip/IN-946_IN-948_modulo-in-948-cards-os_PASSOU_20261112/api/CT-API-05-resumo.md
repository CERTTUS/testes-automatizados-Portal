# CT-API-05

- **HTTP:** 403
- **URL:** http://127.0.0.1:3333/cliente/os/tokOsOutraIN948XXXXXX
- **Prova:** resposta da API conforme cenário.
