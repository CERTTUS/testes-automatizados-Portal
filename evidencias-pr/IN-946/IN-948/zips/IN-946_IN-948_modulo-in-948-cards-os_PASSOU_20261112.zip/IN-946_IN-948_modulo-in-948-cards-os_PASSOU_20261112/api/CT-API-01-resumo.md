# CT-API-01

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/cliente/os/tokOsComItensIN948XXX
- **Prova:** resposta da API conforme cenário.
