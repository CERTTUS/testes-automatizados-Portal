# CT-API-06

- **HTTP:** 200
- **URL:** http://127.0.0.1:3333/cliente/os/tokOsSemItensIN948XXX/fotos
- **Prova:** resposta da API conforme cenário.
