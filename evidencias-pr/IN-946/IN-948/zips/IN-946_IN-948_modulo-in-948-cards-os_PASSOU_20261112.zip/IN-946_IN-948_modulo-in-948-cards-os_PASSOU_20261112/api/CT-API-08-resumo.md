# CT-API-08

- **HTTP:** 403
- **URL:** http://127.0.0.1:3333/cliente/os/tokOsOutraIN948XXXXXX/fotos
- **Prova:** resposta da API conforme cenário.
