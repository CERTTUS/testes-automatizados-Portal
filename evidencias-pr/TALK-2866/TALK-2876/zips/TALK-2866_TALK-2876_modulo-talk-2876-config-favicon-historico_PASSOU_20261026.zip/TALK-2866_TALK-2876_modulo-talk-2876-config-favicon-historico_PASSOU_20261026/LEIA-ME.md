# LEIA-ME — Evidências QA_PRE_CR

Percorra os PNG na ordem numérica (`01-`, `02-`, …, `99-tela-final`).

| CT | Pasta | Sequência | O que cada imagem mostra |
|----|-------|-----------|--------------------------|
| CT-API-01 | `api/` | CT-API-01-response.json, CT-API-01-resumo.md | resposta da API + resumo do CT |
| CT-API-02 | `api/` | CT-API-02-response.json, CT-API-02-resumo.md | resposta da API + resumo do CT |
| CT-API-03 | `api/` | CT-API-03-response.json, CT-API-03-resumo.md | resposta da API + resumo do CT |
| CT-API-04 | `api/` | CT-API-04-response.json, CT-API-04-resumo.md | resposta da API + resumo do CT |
| CT-API-05 | `api/` | CT-API-05-response.json, CT-API-05-resumo.md | resposta da API + resumo do CT |
| CT-API-06 | `api/` | CT-API-06-response.json, CT-API-06-resumo.md | resposta da API + resumo do CT |
| CT-API-07 | `api/` | CT-API-07-response.json, CT-API-07-resumo.md | resposta da API + resumo do CT |

## API

- **CT-API-01:** `api/CT-API-01-response.json` + `api/CT-API-01-resumo.md`
- **CT-API-02:** `api/CT-API-02-response.json` + `api/CT-API-02-resumo.md`
- **CT-API-03:** `api/CT-API-03-response.json` + `api/CT-API-03-resumo.md`
- **CT-API-04:** `api/CT-API-04-response.json` + `api/CT-API-04-resumo.md`
- **CT-API-05:** `api/CT-API-05-response.json` + `api/CT-API-05-resumo.md`
- **CT-API-06:** `api/CT-API-06-response.json` + `api/CT-API-06-resumo.md`
- **CT-API-07:** `api/CT-API-07-response.json` + `api/CT-API-07-resumo.md`
