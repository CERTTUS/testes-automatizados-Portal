# CT-API-02

- **HTTP:** 200
- **URL:** postgresql://localhost/portalcliente-teste-talk-2876 (contrato SQL)
- **Prova:** resposta da API conforme cenário.
