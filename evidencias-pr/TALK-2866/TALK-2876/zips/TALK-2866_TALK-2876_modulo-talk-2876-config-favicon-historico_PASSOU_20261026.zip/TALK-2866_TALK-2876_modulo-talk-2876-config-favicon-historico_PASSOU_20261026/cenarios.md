# Cenários — Supabase portal_cliente_config — favicon e histórico (TALK-2876)

> HU TALK-2866 · Dev TALK-2876 · entrega só-DDL (migration Supabase versionada no `portalcliente-api`).
> Sem API HTTP própria: a camada API deste hop é um **contrato SQL** rodado num database PostgreSQL local
> descartável (decisão humana no gate `qa_pre_cr_ddl_sem_api`, opção A). Supabase remoto não é tocado.

**Em linguagem de tela:** a config do portal ganha favicon e histórico com padrão desligado / 180 dias / 10 fases;
configs inválidas (fase C, período fora de 30/90/180/365, campos faltando) são recusadas; a fase Produção
(espaço) nunca se perde.

## 1. API

### CT-API-01 — Migration aplicada duas vezes sem erro (idempotência)
- Pré: database vazio; migration base `supabase_portal_cliente_config.sql` aplicada; uma linha já existente.
- Passos: aplicar `supabase_portal_cliente_config_favicon_historico.sql` duas vezes.
- → Esperado: as duas aplicações terminam sem erro; existe exatamente um CHECK `portal_cliente_config_historico_config_chk`.

### CT-API-02 — Colunas novas com tipo e default corretos
- → Esperado: `favicon_url` text, aceita nulo; `historico_config` jsonb, NOT NULL, default
  `{"lExibir":false,"mFases":["D","P","O"," ","E","T","R","B","U","F"],"nPeriodoDias":180}`.

### CT-API-03 — Config já existente recebe o padrão
- → Esperado: a linha criada antes da migration fica com `favicon_url` nulo e `historico_config` igual ao default.

### CT-API-04 — Config nova sem os campos novos recebe o padrão
- Passos: inserir config informando só `database` e `empresa`.
- → Esperado: `historico_config` igual ao default; `favicon_url` nulo.

### CT-API-05 — Configs de histórico inválidas são recusadas
- Passos: gravar cada valor abaixo em `historico_config`.
- → Esperado: todas recusadas com SQLSTATE 23514 (CHECK), exceto `NULL` → 23502 (NOT NULL):
  fase `C`; período 60; período `"180"` (texto); `lExibir` `"sim"`; `[]`; sem `mFases`; sem `lExibir`;
  sem `nPeriodoDias`; `NULL`.

### CT-API-06 — Configs válidas são aceitas e a fase Produção (espaço) é preservada
- Passos: gravar `{"lExibir":true,"mFases":["A"," "],"nPeriodoDias":365}`; depois `mFases` vazio com período 30;
  depois `favicon_url` com URL de CDN.
- → Esperado: as três gravações aceitas; o segundo item de `mFases` volta exatamente como `" "` (sem trim).

### CT-API-07 — Segurança da tabela preservada
- → Esperado: RLS continua ligado (`relrowsecurity = true`) na `portal_cliente_config`.

## 2. Smoke automatizado

N/A neste hop (QA_PRE_CR: só API).

## 3. E2E — Caminho feliz

N/A — entrega só-DDL; a tela consome via T2/T3/T4/T6.

## 4. E2E — Caminho negativo

N/A.

## 5. Manual (somente UI)

N/A nesta subtarefa. Aplicação no Supabase de staging/produção é passo manual de infra, antes do deploy do TALK-2877.
