# CT-API-20

- **HTTP:** 200
- **URL:** http://127.0.0.1:18883/portal/tokLinkHist2880SemFavicon
- **Prova:** resposta da API conforme cenário.
