# CT-API-14

- **HTTP:** 200
- **URL:** http://127.0.0.1:18881/api/bff/cliente/os/tokAlvoHist2880Ok
- **Prova:** resposta da API conforme cenário.
