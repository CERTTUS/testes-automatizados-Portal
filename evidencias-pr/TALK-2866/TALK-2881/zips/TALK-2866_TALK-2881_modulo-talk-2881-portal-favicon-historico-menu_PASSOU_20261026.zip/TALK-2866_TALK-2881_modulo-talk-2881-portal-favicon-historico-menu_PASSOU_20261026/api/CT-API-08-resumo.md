# CT-API-08

- **HTTP:** 200
- **URL:** http://127.0.0.1:18881/tokLinkHist2880Revogado
- **Prova:** resposta da API conforme cenário.
