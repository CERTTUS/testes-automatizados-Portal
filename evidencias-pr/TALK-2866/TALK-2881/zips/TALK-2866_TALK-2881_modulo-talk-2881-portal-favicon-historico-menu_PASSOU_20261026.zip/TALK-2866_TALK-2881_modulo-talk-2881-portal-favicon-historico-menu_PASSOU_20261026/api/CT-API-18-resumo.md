# CT-API-18

- **HTTP:** 401
- **URL:** http://127.0.0.1:18881/api/bff/cliente/os/tokAlvoHist2880Ok
- **Prova:** resposta da API conforme cenário.
