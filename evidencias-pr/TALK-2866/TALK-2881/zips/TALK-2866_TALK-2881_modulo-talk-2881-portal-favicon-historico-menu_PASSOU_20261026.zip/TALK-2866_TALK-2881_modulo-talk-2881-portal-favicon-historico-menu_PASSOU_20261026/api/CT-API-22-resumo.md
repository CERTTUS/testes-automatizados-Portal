# CT-API-22

- **HTTP:** 422
- **URL:** http://127.0.0.1:18883/cliente/historico
- **Prova:** resposta da API conforme cenário.
