# CT-API-15

- **HTTP:** 403
- **URL:** http://127.0.0.1:18881/api/bff/cliente/os/tokAlvoHist2880Negado
- **Prova:** resposta da API conforme cenário.
