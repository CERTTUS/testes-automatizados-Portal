# CT-API-26

- **HTTP:** 403
- **URL:** http://127.0.0.1:18883/cliente/os/tokAlvoHist2880Negado
- **Prova:** resposta da API conforme cenário.
