# CT-API-23

- **HTTP:** 200
- **URL:** http://127.0.0.1:18883/cliente/dados
- **Prova:** resposta da API conforme cenário.
