# CT-API-06

- **HTTP:** 404
- **URL:** http://127.0.0.1:18881/tokLinkHist2880NaoExiste
- **Prova:** resposta da API conforme cenário.
