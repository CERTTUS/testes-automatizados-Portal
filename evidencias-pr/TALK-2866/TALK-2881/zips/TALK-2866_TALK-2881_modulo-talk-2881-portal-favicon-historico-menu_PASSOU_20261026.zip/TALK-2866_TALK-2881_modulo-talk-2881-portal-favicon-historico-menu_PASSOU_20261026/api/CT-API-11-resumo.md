# CT-API-11

- **HTTP:** 401
- **URL:** http://127.0.0.1:18881/api/bff/cliente/historico
- **Prova:** resposta da API conforme cenário.
