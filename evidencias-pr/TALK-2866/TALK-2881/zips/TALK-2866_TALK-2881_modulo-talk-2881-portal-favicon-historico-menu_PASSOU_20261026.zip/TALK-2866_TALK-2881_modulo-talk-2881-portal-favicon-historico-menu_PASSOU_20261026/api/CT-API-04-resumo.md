# CT-API-04

- **HTTP:** 200
- **URL:** http://127.0.0.1:18881/tokLinkHist2880SemCampo
- **Prova:** resposta da API conforme cenário.
