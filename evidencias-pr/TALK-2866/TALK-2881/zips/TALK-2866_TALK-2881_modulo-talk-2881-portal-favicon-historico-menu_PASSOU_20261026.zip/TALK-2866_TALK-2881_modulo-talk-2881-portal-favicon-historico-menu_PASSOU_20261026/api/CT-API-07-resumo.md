# CT-API-07

- **HTTP:** 404
- **URL:** http://127.0.0.1:18881/abc
- **Prova:** resposta da API conforme cenário.
