# CT-API-13

- **HTTP:** 401
- **URL:** http://127.0.0.1:18881/api/bff/cliente/dados
- **Prova:** resposta da API conforme cenário.
