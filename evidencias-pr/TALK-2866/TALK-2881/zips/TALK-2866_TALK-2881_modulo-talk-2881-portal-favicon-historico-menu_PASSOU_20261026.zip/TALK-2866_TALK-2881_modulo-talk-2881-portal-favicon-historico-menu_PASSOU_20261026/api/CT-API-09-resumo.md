# CT-API-09

- **HTTP:** 404
- **URL:** http://127.0.0.1:18881/favicon.ico
- **Prova:** resposta da API conforme cenário.
