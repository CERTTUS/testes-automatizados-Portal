# CT-API-03

- **HTTP:** 200
- **URL:** http://127.0.0.1:18881/tokLinkHist2880SemFavicon
- **Prova:** resposta da API conforme cenário.
