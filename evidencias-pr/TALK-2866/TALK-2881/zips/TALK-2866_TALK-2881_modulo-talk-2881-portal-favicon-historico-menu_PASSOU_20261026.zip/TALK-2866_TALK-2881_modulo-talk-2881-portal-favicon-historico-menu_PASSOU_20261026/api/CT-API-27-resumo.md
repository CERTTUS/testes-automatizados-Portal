# CT-API-27

- **HTTP:** 200
- **URL:** http://127.0.0.1:18881/tokLinkHist2880LogoOnly
- **Prova:** resposta da API conforme cenário.
