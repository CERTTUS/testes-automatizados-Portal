# Cenários de teste — `modulo-talk-2881-portal-favicon-historico-menu`

> Produto: **Portal do Cliente** (`portal` · projeto Jira `TALK`) — repo `CERTTUS/portalcliente-web`
> História: **TALK-2866** (Ajustes gerais no Portal) · Dev do hop: **TALK-2881** (T6) · cenariosKey: TALK-2868
> Base: `contexto-pr.md` (RN-01..RN-12, D-01, R-01..R-06) · techspec `Jira-docs/TALK-2468/TALK-2866/techspec.md`
> Modo: `qa-pre-cr` · `api-smoke` · `proibidoE2e: true` → **só cenários de API (CT numerados CT-API-NN)** neste hop (rule `qa-pre-cr-sem-e2e`)
> Formato: **Título → Descrição → Cenário (BDD)** · passos no **infinitivo** · `cenariosOrigem: gerado-na-dev`
> Spec previsto: pasta `tests/api/modulo-talk-2881-portal-favicon-historico-menu/` (arquivo `portal-favicon-historico-menu.spec.ts`, prefixo de API)

## Legenda

| Tag | Significado |
|-----|-------------|
| **[NOVO]** | Cenário novo — candidato a automação |
| **[EXISTE]** | Já automatizado (outro módulo) |

**Modalidades:** `automacao-api` (HTTP via `request` do Playwright, sem navegador) · `manual`
**Prioridade:** P0 · P1 · P2

**Automação sem humano:** todos os CTs da seção 1 rodam sozinhos (massa vem do stub MS + BFF real + login por telefone). Nenhum CT depende de operador → seção 5 sem CTs.

## Massa e ambiente

Stack de execução (o harness sobe; os CTs não mockam o BFF):

| Camada | Papel | URL típica |
|--------|--------|------------|
| Portal web (Next) | HTML servidor de `/<token>` e proxy `/api/bff/*` | `E2E_BASE_URL` (ex.: `http://127.0.0.1:18881`) |
| BFF real `portalcliente-api` | Contratos `/portal/:token`, `/cliente/*` | `E2E_API_BASE_URL` (ex.: `http://127.0.0.1:18883`) |
| Stub do MS | `scripts/qa/stub-ms-portal-historico.mjs` | `QA_STUB_MS_URL` (ex.: `http://127.0.0.1:18884`) |
| Banco | isolado por TEMPLATE | — |

Robô de preview: header `User-Agent: WhatsApp/2.23.20.0 A` nas chamadas `GET /<token>`; o CT lê o **HTML cru** (sem executar JS) e extrai `<title>`, `<meta property="og:*">`, `<meta name="twitter:*">`, `<meta name="robots">` e `<link rel="icon">`/`<link rel="apple-touch-icon">`.

Sessão web: `POST /api/bff/acesso/telefone` com `{ cTelefone: "5511999990000", cToken: "tokSessaoHist2880Ok" }` → 200 + cookie `portal_sessao`.
Sessão BFF direto: `POST /acesso/telefone` em `E2E_API_BASE_URL` (helper `sessaoCriar` da T5).

Mapa token-do-cenário (gherkin / mock do produto) → token do stub usado no spec:

| Token do cenário | Token do stub (spec) |
|------------------|----------------------|
| `tokFaviconXXXXXXXXXXXX` | `tokLinkHist2880Favicon` (`C_TOKEN_LINK_FAVICON`) |
| `xK9mP2nQ4rS6tU8vW0yZ12` (`C_TOKEN_OK`) | `tokLinkHist2880SemFavicon` (`C_TOKEN_LINK_SEM_FAVICON`) |
| `tokTemaCustomXXXXXXXX` | `tokLinkHist2880SemCampo` (`C_TOKEN_LINK_SEM_CAMPO`) |
| `tokInexistenteXXXXXXXXX` | `tokLinkHist2880NaoExiste` (`C_TOKEN_INEXISTENTE`) |
| `tokRevogadoXXXXXXXXXXXX` | `tokLinkHist2880Revogado` (`C_TOKEN_LINK_REVOGADO`) |
| `abc` | `abc` (formato inválido) |
| `tokOsD4v2XXXXXXXXXXXXXX` | `tokSessaoHist2880Ok` (`C_TOKEN_SESSAO`) |
| `tokHistAXXXXXXXXXXXXXXX` | `tokAlvoHist2880Ok` (`C_TOKEN_ALVO_OK`) |
| `tokHist403XXXXXXXXXXXXX` | `tokAlvoHist2880Negado` (`C_TOKEN_ALVO_NEGADO`) |
| (CT-API-22 histórico desligado) | `tokSessaoHist2880Off` (`C_TOKEN_SESSAO_422`) |
| (CT-API-27 logo sem favicon) | `tokLinkHist2880LogoOnly` (`C_TOKEN_LINK_LOGO`) |

Os gherkins abaixo mantêm os tokens do mock do produto; o spec troca pela coluna da direita.

## Inventário do pai (TALK-2866) — HARNESS_MULTI_DEV_PR

| Task | devKey | Repo produto | Onde estão os CTs | Situação neste hop |
|------|--------|--------------|-------------------|--------------------|
| T1 — migration Supabase `favicon_url` + `historico_config` | TALK-2876 | `CERTTUS/portalcliente-api` | **[EXISTE]** módulo irmão `docs/tests/TALK-2866/modulo-talk-2876-config-favicon-historico` · spec na pasta `tests/api/modulo-talk-2876-config-favicon-historico/` (CT-API-01..07 daquele módulo; PASSOU em 2026-10-26) | Referência — **não reescrito aqui** |
| T2 — MS favicon/histórico/cliente + autorização embutida | a confirmar no Jira | `CERTTUS/api-microservicos` | Fora deste repo de testes (produto MS/Talk) | Não coberto aqui — ver nota ao final |
| T3 — Hub Talk PATCH/upload favicon | a confirmar no Jira | `CERTTUS/talk-api` | Fora deste repo de testes (produto Talk) | Não coberto aqui — ver nota ao final |
| T4 — Tela Talk (card Favicon, grupo Histórico, preview) | a confirmar no Jira | `CERTTUS/talk-web` | Fora deste repo de testes (produto Talk) | Não coberto aqui — ver nota ao final |
| T5 — BFF `/cliente/historico`, `/cliente/dados`, OS do histórico, `cFaviconUrl` | TALK-2880 | `CERTTUS/portalcliente-api` | Este arquivo, **seção 1.4** (CT-API-19..CT-API-26) | Escritos · executáveis neste hop (BFF real + stub MS; T5 concluída) |
| T6 — Portal favicon/OG, Boleto fora, Histórico, menu, preview | **TALK-2881** | `CERTTUS/portalcliente-web` | Este arquivo, **seções 1.1–1.3** (CT-API-01..CT-API-18) | Executáveis neste hop (contra o mock) |

---

## 1. API

### 1.1 HTML servidor de `/<token>` — favicon e Open Graph por oficina (T6 · TALK-2881)

**Funcionalidade:** o link mandado pelo WhatsApp gera um preview com nome, descrição e imagem da oficina; a aba do navegador usa o ícone da oficina.

### CT-API-01 — Preview do link mostra nome, descrição e imagem da oficina

**Descrição:**
Validar que o HTML servidor de um link válido traz título e Open Graph da oficina, com a imagem do favicon em URL absoluta (RN-01, RN-02).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/metadataPortalMontar.ts`, `src/app/[token]/page.tsx`, `src/app/layout.tsx` · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Link de oficina com favicon gera Open Graph completo
  Dado ter o servidor do portal no ar apontando para o BFF mock
  E usar o token "tokFaviconXXXXXXXXXXXX" da oficina "Oficina Favicon"
  Quando chamar GET /tokFaviconXXXXXXXXXXXX com User-Agent do WhatsApp
  Então retornar HTTP 200 com HTML
  E exibir <title> "Oficina Favicon | Portal do Cliente"
  E conter og:title "Oficina Favicon | Portal do Cliente"
  E conter og:description "Acompanhe sua ordem de serviço em Oficina Favicon"
  E conter og:image igual a "https://cdn.sistema.certtus.com.br/portal/fixtures/favicon-e2e.png"
  E conter og:url igual a "<PORTAL_URL_PUBLICA>/tokFaviconXXXXXXXXXXXX"
  E conter og:site_name "Oficina Favicon", og:type "website" e og:locale "pt_BR"
  E conter twitter:card "summary"
```

---

### CT-API-02 — Aba do navegador usa o ícone da oficina e nunca o favicon.ico padrão

**Descrição:**
Validar que o `<head>` do link válido aponta `icon` e `apple-touch-icon` para o favicon da oficina e que nenhuma referência a `/favicon.ico` aparece (RN-02, RN-05).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/metadataPortalMontar.ts`, `src/app/favicon.ico` (removido) · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Ícone do tenant no head sem favicon.ico
  Dado usar o token "tokFaviconXXXXXXXXXXXX" da oficina "Oficina Favicon"
  Quando chamar GET /tokFaviconXXXXXXXXXXXX com User-Agent do WhatsApp
  Então conter <link rel="icon"> com href "https://cdn.sistema.certtus.com.br/portal/fixtures/favicon-e2e.png"
  E conter <link rel="apple-touch-icon"> com o mesmo href
  Mas não conter nenhuma ocorrência de "/favicon.ico" no HTML
```

---

### CT-API-03 — Oficina sem favicon e sem logo usa a marca CERTTUS em URL absoluta

**Descrição:**
Validar o último degrau do fallback: sem favicon e sem logo, imagem e ícone viram a marca CERTTUS com URL absoluta, mantendo o nome da oficina no título (RN-02, RN-06 com `null`).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/metadataPortalMontar.ts` (`urlAbsolutaPortal`, `portalUrlPublicaObter`) · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Fallback para a marca CERTTUS
  Dado usar o token "xK9mP2nQ4rS6tU8vW0yZ12" da oficina "Oficina E2E" com cFaviconUrl nulo e sem logo
  Quando chamar GET /xK9mP2nQ4rS6tU8vW0yZ12 com User-Agent do WhatsApp
  Então exibir <title> "Oficina E2E | Portal do Cliente"
  E conter og:image igual a "<PORTAL_URL_PUBLICA>/marca/certtus-marca.png"
  E conter <link rel="icon"> com href "<PORTAL_URL_PUBLICA>/marca/certtus-marca.png"
  E validar que og:image começa com "http" (nunca caminho relativo)
  Mas não conter "/favicon.ico" no HTML
```

---

### CT-API-04 — Oficina sem o campo de favicon na resposta cai na marca CERTTUS

**Descrição:**
Validar que a ausência do campo `cFaviconUrl` (BFF antigo) é tratada como “sem favicon”, sem quebrar a página (RN-06 com campo ausente).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/landingPortalCarregar.ts`, `src/services/metadataPortalMontar.ts` · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Landing sem cFaviconUrl
  Dado usar o token "tokTemaCustomXXXXXXXX" cuja landing não traz o campo cFaviconUrl
  Quando chamar GET /tokTemaCustomXXXXXXXX com User-Agent do WhatsApp
  Então retornar HTTP 200 com HTML
  E exibir <title> "Oficina Tema Custom | Portal do Cliente"
  E conter og:image e <link rel="icon"> iguais a "<PORTAL_URL_PUBLICA>/marca/certtus-marca.png"
```

---

### CT-API-05 — Link válido não é indexado por buscadores

**Descrição:**
Validar que o HTML do link válido traz `robots` `noindex, nofollow` (RN-04).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/metadataPortalMontar.ts` (`O_ROBOTS_NOINDEX`) · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: robots noindex no link válido
  Dado usar o token "tokFaviconXXXXXXXXXXXX"
  Quando chamar GET /tokFaviconXXXXXXXXXXXX com User-Agent do WhatsApp
  Então conter <meta name="robots"> com "noindex" e "nofollow"
```

---

### CT-API-06 — Link inexistente mostra preview neutro sem nome de oficina

**Descrição:**
Validar que token com formato válido mas inexistente (BFF 404) gera metadata neutra CERTTUS, sem nenhum nome de oficina (RN-03, RN-04).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/metadataPortalMontar.ts` (`metadataPortalNeutra`), `src/app/[token]/page.tsx` · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Token inexistente → metadata neutra
  Dado usar o token "tokInexistenteXXXXXXXXX" que o BFF responde 404
  Quando chamar GET /tokInexistenteXXXXXXXXX com User-Agent do WhatsApp
  Então exibir <title> "Portal do Cliente"
  E conter og:title "Portal do Cliente" e og:description "Acompanhe sua ordem de serviço"
  E conter og:image igual a "<PORTAL_URL_PUBLICA>/marca/certtus-marca.png"
  E conter <meta name="robots"> com "noindex" e "nofollow"
  Mas não conter "Oficina" em nenhum ponto do HTML
  E não conter og:url com o token
```

---

### CT-API-07 — Link com formato inválido mostra preview neutro sem nome de oficina

**Descrição:**
Validar que token fora do formato esperado não expõe nome de oficina e recebe metadata neutra (RN-03).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `src/app/[token]/page.tsx` (`tokenPortalFormatoValidar`), `src/services/metadataPortalMontar.ts` · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Token com formato inválido → metadata neutra
  Dado usar o token "abc" (fora do formato de 20 a 28 caracteres)
  Quando chamar GET /abc com User-Agent do WhatsApp
  Então exibir <title> "Portal do Cliente"
  E conter og:image igual a "<PORTAL_URL_PUBLICA>/marca/certtus-marca.png"
  E conter <meta name="robots"> com "noindex"
  Mas não conter "Oficina" em nenhum ponto do HTML
  E não conter "/favicon.ico" no HTML
```

---

### CT-API-08 — Link revogado mostra «Link indisponível» sem nome de oficina

**Descrição:**
Validar que link revogado (BFF 410) gera o título «Link indisponível | Portal do Cliente» com Open Graph neutro (RN-03).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/metadataPortalMontar.ts` (ramo `indisponivel`), `src/services/landingPortalCarregar.ts` · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Token revogado → Link indisponível
  Dado usar o token "tokRevogadoXXXXXXXXXXXX" que o BFF responde 410
  Quando chamar GET /tokRevogadoXXXXXXXXXXXX com User-Agent do WhatsApp
  Então exibir <title> "Link indisponível | Portal do Cliente"
  E conter og:title "Portal do Cliente" e og:image da marca CERTTUS em URL absoluta
  E conter <meta name="robots"> com "noindex"
  Mas não conter "Oficina" em nenhum ponto do HTML
```

---

### CT-API-09 — Portal não serve mais o favicon.ico padrão

**Descrição:**
Validar que o arquivo `favicon.ico` padrão do Next foi removido e não é servido como ícone, para não sobrepor o ícone da oficina (RN-05).

**Tag:** [NOVO] · **Prioridade:** P2 · **Modalidade:** `automacao-api`
**Cobre:** `src/app/favicon.ico` (removido) · `GET /favicon.ico` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: favicon.ico removido
  Dado ter o servidor do portal no ar
  Quando chamar GET /favicon.ico
  Então não retornar content-type "image/x-icon" nem "image/vnd.microsoft.icon"
```

---

### CT-API-27 — Oficina sem favicon e com logo usa o logo no preview

**Descrição:**
Validar o degrau intermediário do fallback: sem favicon e com logo, o `og:image` usa o logo; o ícone da aba cai na marca CERTTUS (RN-02).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/metadataPortalMontar.ts` · `GET /<token>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Fallback para o logo da oficina
  Dado usar o token "tokLinkHist2880LogoOnly" da oficina "Oficina Histórico" com cFaviconUrl nulo e logo preenchido
  Quando chamar GET /tokLinkHist2880LogoOnly com User-Agent do WhatsApp
  Então retornar HTTP 200 com HTML
  E conter og:image igual a "https://cdn.example.com/oficina/logo.png"
  E conter <link rel="icon"> com href terminando em "/marca/certtus-marca.png"
```

---

### 1.2 Proxy `/api/bff/cliente/historico` e `/api/bff/cliente/dados` (T6 · TALK-2881, contra o mock)

**Funcionalidade:** aba «Histórico» e diálogo «Meus dados» leem pelo proxy same-site, só com sessão.

### CT-API-10 — Histórico com sessão devolve a lista de OS do cliente

**Descrição:**
Validar que, com sessão, o proxy repassa o histórico com o envelope esperado pelo front e sem a OS da sessão (RN-08).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `src/app/api/bff/[...path]/route.ts`, `src/services/portalClienteApi.ts` (`listarHistorico`), `src/schemas/ordemServicoSchema.ts` (`historicoOsSchema`) · `GET /api/bff/cliente/historico` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Histórico autenticado
  Dado entrar pelo POST /api/bff/acesso/telefone com o telefone fixture e o token "tokOsD4v2XXXXXXXXXXXXXX"
  E guardar o cookie portal_sessao devolvido
  Quando chamar GET /api/bff/cliente/historico com o cookie
  Então retornar HTTP 200
  E conter lSucesso true e cMensagem preenchida
  E conter oDados.nPeriodoDias numérico e oDados.mFases como lista
  E conter oDados.mOrdens com cOsPublicId, cNumeroOs, cSerie, cStatus, cStatusDescricao e dRecepcao em cada item
  E incluir "tokHistAXXXXXXXXXXXXXXX" na lista
  Mas não incluir a OS da sessão "tokOsD4v2XXXXXXXXXXXXXX" na lista
```

---

### CT-API-11 — Histórico sem sessão é recusado

**Descrição:**
Validar que sem o cookie de sessão o histórico responde 401 e não vaza nenhuma OS (RN-08).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `src/app/api/bff/[...path]/route.ts` · `GET /api/bff/cliente/historico` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Histórico sem cookie de sessão
  Dado não ter cookie portal_sessao
  Quando chamar GET /api/bff/cliente/historico
  Então retornar HTTP 401
  E conter lSucesso false e cMensagem "Sessão não autenticada"
  Mas não conter mOrdens no corpo
```

---

### CT-API-12 — Meus dados com sessão devolve o cliente com documento mascarado

**Descrição:**
Validar que, com sessão, os dados do cliente chegam em `oDados.oCliente` (R-01 resolvido: o plano da T5 confirma o embrulho) e o documento vem sempre mascarado (RN-10).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `src/services/portalClienteApi.ts` (`obterDadosCliente`), `src/schemas/clienteDadosSchema.ts`, proxy · `GET /api/bff/cliente/dados` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Meus dados autenticado
  Dado ter o cookie portal_sessao obtido pelo login com o telefone fixture
  Quando chamar GET /api/bff/cliente/dados com o cookie
  Então retornar HTTP 200 com lSucesso true
  E conter oDados.oCliente.cNome "Carlos Pereira"
  E conter oDados.oCliente.cDocumentoTipo "CPF"
  E conter oDados.oCliente.cDocumentoMascarado com "*"
  Mas não conter sequência de 11 dígitos de CPF sem máscara em nenhum ponto do corpo
```

---

### CT-API-13 — Meus dados sem sessão é recusado

**Descrição:**
Validar que sem sessão os dados pessoais não saem (401) (RN-10).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** proxy · `GET /api/bff/cliente/dados` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Meus dados sem cookie de sessão
  Dado não ter cookie portal_sessao
  Quando chamar GET /api/bff/cliente/dados
  Então retornar HTTP 401 com lSucesso false
  Mas não conter oCliente, cNome nem cDocumentoMascarado no corpo
```

---

### 1.3 Proxy `/api/bff/cliente/os/<id>` — abrir OS do histórico (T6 · TALK-2881, contra o mock)

**Funcionalidade:** clicar numa OS do histórico abre o detalhe sem novo login, só se a OS for do mesmo cliente.

### CT-API-14 — OS do histórico autorizada abre com a sessão atual

**Descrição:**
Validar que a OS listada no histórico e autorizada abre (200) usando o cookie da OS de origem, sem novo login (RN-09).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** proxy, `src/components/templates/ConteudoDetalheOsAutenticado.tsx` (consumidor), `src/schemas/ordemServicoSchema.ts` · `GET /api/bff/cliente/os/<id>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: OS autorizada do histórico
  Dado ter o cookie portal_sessao da OS "tokOsD4v2XXXXXXXXXXXXXX"
  Quando chamar GET /api/bff/cliente/os/tokHistAXXXXXXXXXXXXXXX com o cookie
  Então retornar HTTP 200 com lSucesso true
  E conter oDados.oOrdemServico.cOsPublicId "tokHistAXXXXXXXXXXXXXXX"
  E conter oDados.oOrdemServico.oFlagsPainel.historico como booleano
```

---

### CT-API-15 — OS do histórico não autorizada responde «Acesso negado.»

**Descrição:**
Validar que a OS não autorizada responde 403 com mensagem uniforme e sem nenhum dado da OS (anti-enumeração, RN-09).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** proxy · `GET /api/bff/cliente/os/<id>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: OS não autorizada
  Dado ter o cookie portal_sessao da OS "tokOsD4v2XXXXXXXXXXXXXX"
  Quando chamar GET /api/bff/cliente/os/tokHist403XXXXXXXXXXXXX com o cookie
  Então retornar HTTP 403
  E conter lSucesso false e cMensagem "Acesso negado."
  Mas não conter oOrdemServico, placa nem número da OS no corpo
```

---

### CT-API-16 — Fotos da OS não autorizada também respondem «Acesso negado.»

**Descrição:**
Validar que as fotos da OS não autorizada seguem o mesmo 403 uniforme do detalhe (RN-09).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** proxy · `GET /api/bff/cliente/os/<id>/fotos` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Fotos de OS não autorizada
  Dado ter o cookie portal_sessao da OS "tokOsD4v2XXXXXXXXXXXXXX"
  Quando chamar GET /api/bff/cliente/os/tokHist403XXXXXXXXXXXXX/fotos com o cookie
  Então retornar HTTP 403 com cMensagem "Acesso negado."
  Mas não conter mFotosPorFase no corpo
```

---

### CT-API-17 — Fotos da OS autorizada do histórico abrem com a sessão atual

**Descrição:**
Validar o caminho feliz das fotos da OS alvo autorizada (RN-09).

**Tag:** [NOVO] · **Prioridade:** P2 · **Modalidade:** `automacao-api`
**Cobre:** proxy · `GET /api/bff/cliente/os/<id>/fotos` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: Fotos de OS autorizada
  Dado ter o cookie portal_sessao da OS "tokOsD4v2XXXXXXXXXXXXXX"
  Quando chamar GET /api/bff/cliente/os/tokHistAXXXXXXXXXXXXXXX/fotos com o cookie
  Então retornar HTTP 200 com lSucesso true
  E conter oDados.mFotosPorFase como lista
```

---

### CT-API-18 — OS do histórico sem sessão é recusada

**Descrição:**
Validar que abrir a OS do histórico sem cookie de sessão responde 401, mesmo para OS autorizada (RN-09).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** proxy · `GET /api/bff/cliente/os/<id>` · TALK-2881 (T6)

**Cenário de teste:**

```gherkin
Cenário: OS do histórico sem cookie de sessão
  Dado não ter cookie portal_sessao
  Quando chamar GET /api/bff/cliente/os/tokHistAXXXXXXXXXXXXXXX
  Então retornar HTTP 401 com lSucesso false
  Mas não conter oOrdemServico no corpo
```

---

### 1.4 BFF real `portalcliente-api` (T5 · TALK-2880)

> T5 concluída. Alvo: BFF real `portalcliente-api` no ar com o MS substituído pelo stub (`scripts/qa/stub-ms-portal-historico.mjs`), conforme techspec § portalcliente-api — BFF (T5). Os mesmos contratos já são exercitados via proxy do Next nas seções 1.1–1.3; aqui confirmam o produtor real (D-01).

### CT-API-19 — BFF repassa o favicon da oficina na landing

**Descrição:**
Validar que `GET /portal/:cToken` do BFF devolve `cFaviconUrl` vindo do MS (D9).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` schema da landing · `GET /portal/:cToken` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: Landing do BFF com favicon
  Dado ter o MS mockado devolvendo cFaviconUrl preenchido para o token do link
  Quando chamar GET /portal/<token> no BFF
  Então retornar HTTP 200
  E conter oDados.cFaviconUrl igual à URL devolvida pelo MS
```

---

### CT-API-20 — BFF devolve favicon nulo quando a oficina não tem favicon nem logo

**Descrição:**
Validar que a ausência de favicon no MS chega ao front como `cFaviconUrl: null`, sem erro de schema.

**Tag:** [NOVO] · **Prioridade:** P2 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` schema da landing · `GET /portal/:cToken` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: Landing do BFF sem favicon
  Dado ter o MS mockado devolvendo cFaviconUrl nulo
  Quando chamar GET /portal/<token> no BFF
  Então retornar HTTP 200
  E conter oDados.cFaviconUrl nulo
```

---

### CT-API-21 — BFF lista o histórico sempre da OS da sessão

**Descrição:**
Validar que `/cliente/historico` usa a OS da sessão (ignora qualquer id enviado pelo cliente) e devolve o envelope `{nPeriodoDias, mFases, mOrdens[]}`.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` rota `/cliente/historico` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: Histórico pelo BFF real
  Dado ter sessão válida de uma OS com histórico ligado
  E ter o MS mockado devolvendo duas OS do mesmo cliente
  Quando chamar GET /cliente/historico?cOsPublicId=<outra OS> com o cookie da sessão
  Então retornar HTTP 200 com oDados.mOrdens de duas OS
  E validar que o MS foi chamado com a OS da sessão, não com a OS da query
```

---

### CT-API-22 — BFF repassa 422 quando o histórico está desligado

**Descrição:**
Validar que histórico desligado na oficina chega como 422 (cobre R-03, que o mock do front não simula).

**Tag:** [NOVO] · **Prioridade:** P1 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` rota `/cliente/historico` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: Histórico desligado
  Dado ter sessão válida
  E ter o MS mockado respondendo 422 no histórico
  Quando chamar GET /cliente/historico com o cookie da sessão
  Então retornar HTTP 422 com lSucesso false
  Mas não conter mOrdens no corpo
```

---

### CT-API-23 — BFF devolve Meus dados só com os campos do contrato

**Descrição:**
Validar que `/cliente/dados` embrulha o cliente em `oDados.oCliente`, com documento mascarado, e descarta campo extra vindo do MS (schema estrito no BFF — não vaza PII).

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` rota `/cliente/dados` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: Meus dados pelo BFF real
  Dado ter sessão válida
  E ter o MS mockado devolvendo o cliente com um campo extra "cRg"
  Quando chamar GET /cliente/dados com o cookie da sessão
  Então retornar HTTP 200 com oDados.oCliente.cNome preenchido
  E conter oDados.oCliente.cDocumentoMascarado com "*"
  Mas não conter "cRg" no corpo
```

---

### CT-API-24 — BFF recusa Meus dados sem sessão sem consultar o MS

**Descrição:**
Validar 401 na rota nova de dados sem cookie de sessão, sem chamar o MS.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` rota `/cliente/dados` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: Meus dados sem sessão no BFF real
  Dado não ter cookie de sessão
  Quando chamar GET /cliente/dados no BFF
  Então retornar HTTP 401
  E validar que o MS não foi chamado
```

---

### CT-API-25 — BFF abre OS do histórico autorizada com o token de origem

**Descrição:**
Validar que, quando a OS pedida ≠ OS da sessão, o BFF chama o MS com `x-portal-token-origem` = OS da sessão e devolve 200 se autorizado.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` rota `/cliente/os/:cOsPublicId` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: OS alvo autorizada no BFF real
  Dado ter sessão válida da OS de origem
  E ter o MS mockado autorizando a OS alvo
  Quando chamar GET /cliente/os/<OS alvo> com o cookie da sessão
  Então retornar HTTP 200 com o detalhe da OS alvo
  E validar que o MS recebeu o header x-portal-token-origem com a OS da sessão
```

---

### CT-API-26 — BFF responde 403 uniforme quando a OS alvo não existe para o cliente

**Descrição:**
Validar que 403, 404 ou 410 do MS na autorização da OS alvo viram sempre **403 «Acesso negado.»** no BFF (anti-enumeração); este caso usa o 404 do MS.

**Tag:** [NOVO] · **Prioridade:** P0 · **Modalidade:** `automacao-api`
**Cobre:** `portalcliente-api` rotas `/cliente/os/:cOsPublicId` e `/fotos` · TALK-2880 (T5)

**Cenário de teste:**

```gherkin
Cenário: OS alvo negada no BFF real
  Dado ter sessão válida da OS de origem
  E ter o MS mockado respondendo 404 para a OS alvo
  Quando chamar GET /cliente/os/<OS alvo> com o cookie da sessão
  Então retornar HTTP 403 com cMensagem "Acesso negado."
  Mas não conter o motivo da recusa nem dados da OS no corpo
```

---

## 2. Smoke automatizado

N/A neste hop (WU Teste). `qa-pre-cr` proíbe os CTs de smoke.

## 3. E2E — Caminho feliz

N/A neste hop (WU Teste). `qa-pre-cr` proíbe os CTs E2E. Os specs E2E do produto (`e2e/metadata-og.spec.ts`, `e2e/historico-os.spec.ts`, `e2e/os-d4v2.spec.ts`, `e2e/a11y-portal.spec.ts`) **não** rodam neste hop.

## 4. E2E — Caminho negativo

N/A neste hop (WU Teste).

## 5. Manual (somente UI)

Nenhum CT manual: todos os comportamentos são simuláveis (mock BFF, fixtures, login por telefone fixture).

### Fora da camada API neste hop (cobertos por Vitest do diff e/ou pela WU Teste)

| Comportamento | RN | Onde está coberto agora | Fica para |
|---------------|----|-------------------------|-----------|
| Boleto some do menu do portal e do preview | RN-07 | `MenuTopoPortal.test.tsx`, `LayoutPortalCliente.test.tsx`, `PreviewPortalAoVivo.test.tsx` | WU Teste (E2E) |
| Aba/item «Histórico» só com `oFlagsPainel.historico`; estados carregando/vazio/erro; selo «Atual» com `aria-current` | RN-08 | `SecaoHistoricoOs.test.tsx`, `ordemServicoSchema.test.ts` | WU Teste (E2E) |
| Clique numa OS do histórico navega sem novo login; tela «Acesso não autorizado» no 403 | RN-09 (UI) | E2E do produto `historico-os.spec.ts` (não roda aqui) | WU Teste (E2E) |
| Menu da conta: gatilho 44×44, `role="menu"`, setas/Home/End/Esc, clique fora fecha | — | `MenuContaPortal.test.tsx` | WU Teste (E2E + a11y) |
| Diálogo «Meus dados»: somente leitura, campos ausentes omitidos, carregado só ao abrir, sem polling; campo extra aceito e descartado (R-02 resolvido — `.strict()` removido do schema do front) | RN-10 | `PainelMeusDados.test.tsx`, `clienteDadosSchema.test.ts` | WU Teste (E2E) |
| «Sair» limpa `portal-cliente-marca-ultima` do `sessionStorage` e volta à landing | RN-11 | Vitest do menu/layout | WU Teste (E2E) |
| Preview `/preview/os` mostra/oculta «Histórico» por `historicoConfig.lExibir` (postMessage), sem rede | RN-12 | `PreviewPortalAoVivo.test.tsx` | WU Teste (E2E) |
| Fallback favicon → **logo** → marca (oficina com logo e sem favicon) — o mock do produto não tem token com esse recorte | RN-02 | `metadataPortalMontar.test.ts` | WU Teste / integração |
| Proxy 502 «Serviço temporariamente indisponível» com BFF fora do ar (exige derrubar o upstream durante a suíte) | — | proxy não alterado no diff | WU Teste |

### Nota — T2, T3 e T4 (outros repositórios)

T2 (`api-microservicos`), T3 (`talk-api`) e T4 (`talk-web`) são de outros produtos e não são testáveis por este repo de testes do Portal; os CTs delas pertencem ao repo de testes do respectivo produto, no módulo do pai TALK-2866. A orquestração do Dev deve confirmar se esses CTs já existem lá antes do gate (pendência de inventário, não bloqueia a execução da T6).

---

> **Aguarda aprovação humana** (gate `aprovar_cenarios_pre_cr`) antes de seguir para o `qa-automatizador` (api). Timer `cenarios` iniciado em `tempos-pipeline.md` (2026-10-26T14:27-03:00); fecha na aprovação.
