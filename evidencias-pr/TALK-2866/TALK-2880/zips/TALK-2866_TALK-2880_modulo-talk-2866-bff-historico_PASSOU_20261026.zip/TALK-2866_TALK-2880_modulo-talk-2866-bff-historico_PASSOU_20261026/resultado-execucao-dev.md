# resultado-execucao-dev

> Dev: `TALK-2880` | HU: `TALK-2866` | Módulo: `modulo-talk-2866-bff-historico`
> Data: 2026-10-26T17:25:28.742Z

Veredito: **PASSOU**

Comando: `npm run test:pre-cr (specs) -- --modulo modulo-talk-2866-bff-historico --dev-key TALK-2880 --parent-key TALK-2866`
Ambiente: `local`

---

## O que foi testado (linguagem de tela)

- CT-API-01 — Landing repassar cFaviconUrl em string
- CT-API-02 — Landing repassar cFaviconUrl nulo
- CT-API-03 — Bloquear histórico sem cookie de sessão
- CT-API-04 — Bloquear dados do cliente sem cookie de sessão
- CT-API-05 — Devolver histórico com envelope e no-store
- CT-API-06 — Ignorar token informado na query do histórico
- CT-API-07 — Repassar 422 do MS quando histórico está desligado
- CT-API-08 — Devolver dados do cliente sem campo extra

E2E e checklist manual: WU Teste (não executados neste hop).

---

## Resumo

| Métrica | Valor |
|---------|-------|
| Jest | 0 com prova |
| API | 17 com prova |
| Smoke | 0 com prova |
| Duração | — |

---

## Evidências por CT (obrigatório no PASS)

| CT | Tipo | Status | Arquivo de prova |
|----|------|--------|------------------|
| CT-API-NN | api | SEM_PROVA | — |
| CT-API-01 | api | PASSOU | `api/CT-API-01-response.json` |
| CT-API-02 | api | PASSOU | `api/CT-API-02-response.json` |
| CT-API-03 | api | PASSOU | `api/CT-API-03-response.json` |
| CT-API-04 | api | PASSOU | `api/CT-API-04-response.json` |
| CT-API-05 | api | PASSOU | `api/CT-API-05-response.json` |
| CT-API-06 | api | PASSOU | `api/CT-API-06-response.json` |
| CT-API-07 | api | PASSOU | `api/CT-API-07-response.json` |
| CT-API-08 | api | PASSOU | `api/CT-API-08-response.json` |
| CT-API-09 | api | PASSOU | `api/CT-API-09-response.json` |
| CT-API-10 | api | PASSOU | `api/CT-API-10-response.json` |
| CT-API-11 | api | PASSOU | `api/CT-API-11-response.json` |
| CT-API-12 | api | PASSOU | `api/CT-API-12-response.json` |
| CT-API-13 | api | PASSOU | `api/CT-API-13-response.json` |
| CT-API-14 | api | PASSOU | `api/CT-API-14-response.json` |
| CT-API-15 | api | PASSOU | `api/CT-API-15-response.json` |
| CT-API-16 | api | PASSOU | `api/CT-API-16-response.json` |
| CT-API-17 | api | PASSOU | `api/CT-API-17-response.json` |
