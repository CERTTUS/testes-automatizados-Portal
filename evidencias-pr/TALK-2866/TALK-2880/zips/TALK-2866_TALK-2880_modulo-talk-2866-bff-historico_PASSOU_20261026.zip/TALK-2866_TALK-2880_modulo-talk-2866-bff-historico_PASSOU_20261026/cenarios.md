# Cenários — BFF Portal — histórico, dados do cliente e OS do histórico (TALK-2866 / TALK-2880)

> Hop Dev `qa-pre-cr`: só CT-API-NN. Smoke e E2E = N/A neste hop (WU Teste).
> Produto: `portalcliente-api` (BFF Fastify), rodando na porta local, apontando para um **stub HTTP** do microserviço (`api-microservicos`), que segue o contrato da techspec §Contratos.

## Ambiente e massa do stub (pré-requisito comum)

- Login real: `POST /acesso/telefone` com `{ cToken, cTelefone }`. O BFF chama o stub em `POST /servicos/portal/validar-acesso`, que devolve `{ cToken, cOsPublicId: cToken }`. O BFF grava o cookie `portal_sessao` (httpOnly). A sessão é sempre o `cToken` usado no login (`osPublicId` da sessão).
- O stub responde por **token**. Massa lógica usada abaixo (o tester mapeia para tokens reais do stub):

| Massa | Login (sessão) | Comportamento do stub |
|-------|----------------|-----------------------|
| `TOKEN_OK` | sim | `/historico` 200 com 2 OS; `/cliente` 200; `/detalhe` e `/fotos` 200 quando o header `x-portal-token-origem` = `TOKEN_OK` ou ausente |
| `TOKEN_HISTORICO_422` | sim | `/historico` 422 (histórico desligado) |
| `TOKEN_DADOS_CAMPO_EXTRA` | sim | `/cliente` 200 com `oCliente` contendo campos extras fora do schema |
| `TOKEN_ALVO_OK` | não | `/detalhe` e `/fotos` 200 quando `x-portal-token-origem` = `TOKEN_OK` (com `oFlagsPainel.historico: true`) |
| `TOKEN_ALVO_NEGADO_403` | não | `/detalhe` 403 quando há `x-portal-token-origem` |
| `TOKEN_ALVO_NEGADO_410` | não | `/detalhe` 410 quando há `x-portal-token-origem` |
| `TOKEN_LINK_FAVICON` | não | `/servicos/portal/link/:token` com `cFaviconUrl` string (`https://…/favicon.png`) |
| `TOKEN_LINK_SEM_FAVICON` | não | `/servicos/portal/link/:token` com `cFaviconUrl: null` |

- O stub registra cada requisição recebida (método, path, headers `chaveapi`, `x-portal-token-origem`, `X-Cliente-IP`) para os CTs que afirmam chamadas ao MS ou ausência dela.

---

## 1. API

### CT-API-01 — Landing repassar cFaviconUrl em string

**Descrição:**
Garantir que `GET /portal/:cToken` repassa `cFaviconUrl` como string, sem transformação, quando o MS devolve a URL do favicon da oficina.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /portal/:cToken` (landing) → `GET /servicos/portal/link/:token` do stub
**Pré-requisitos:** stub com `TOKEN_LINK_FAVICON` (cFaviconUrl string)

**Cenário de teste:**
Dado que o stub devolve `cFaviconUrl` string para o token `TOKEN_LINK_FAVICON`
Quando consultar `GET /portal/TOKEN_LINK_FAVICON`
Então validar status 200
E validar que `cFaviconUrl` da resposta é igual à URL devolvida pelo stub

---

### CT-API-02 — Landing repassar cFaviconUrl nulo

**Descrição:**
Garantir que a landing devolve `cFaviconUrl: null` (sem erro de schema) quando a oficina não tem favicon nem logo.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /portal/:cToken` (landing)
**Pré-requisitos:** stub com `TOKEN_LINK_SEM_FAVICON` (cFaviconUrl null)

**Cenário de teste:**
Dado que o stub devolve `cFaviconUrl: null` para o token `TOKEN_LINK_SEM_FAVICON`
Quando consultar `GET /portal/TOKEN_LINK_SEM_FAVICON`
Então validar status 200
E validar que `cFaviconUrl` da resposta é `null`

---

### CT-API-03 — Bloquear histórico sem cookie de sessão

**Descrição:**
Garantir que `GET /cliente/historico` responde 401 sem cookie `portal_sessao` e não chama o MS, pois não há token de sessão para consultar.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/historico`
**Pré-requisitos:** nenhuma sessão (cliente HTTP sem cookie); registro de chamadas do stub zerado

**Cenário de teste:**
Dado que a requisição não envia cookie de sessão
Quando consultar `GET /cliente/historico`
Então validar status 401
E validar `lSucesso: false` e `cMensagem` igual a "Sessão não autenticada"
E validar que o stub não recebeu chamada em `/servicos/portal/os/*/historico`

---

### CT-API-04 — Bloquear dados do cliente sem cookie de sessão

**Descrição:**
Garantir que `GET /cliente/dados` responde 401 sem cookie `portal_sessao` e não chama o MS.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/dados`
**Pré-requisitos:** nenhuma sessão; registro de chamadas do stub zerado

**Cenário de teste:**
Dado que a requisição não envia cookie de sessão
Quando consultar `GET /cliente/dados`
Então validar status 401
E validar `lSucesso: false` e `cMensagem` igual a "Sessão não autenticada"
E validar que o stub não recebeu chamada em `/servicos/portal/os/*/cliente`

---

### CT-API-05 — Devolver histórico com envelope e no-store

**Descrição:**
Garantir que, com sessão válida, `GET /cliente/historico` devolve o envelope `{ lSucesso, cMensagem, oDados }` com `oDados` contendo `nPeriodoDias`, `mFases` e `mOrdens`, e cabeçalho `Cache-Control: no-store`.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/historico` → `GET /servicos/portal/os/TOKEN_OK/historico` do stub
**Pré-requisitos:** login com `TOKEN_OK` (cookie `portal_sessao` obtido por `POST /acesso/telefone`); stub devolve 2 OS em `mOrdens`

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/historico`
Então validar status 200
E validar `lSucesso: true` e `cMensagem` igual a "Histórico de ordens de serviço carregado com sucesso."
E validar que `oDados` contém `nPeriodoDias`, `mFases` e `mOrdens` com 2 itens
E validar o cabeçalho `Cache-Control` igual a `no-store`

---

### CT-API-06 — Ignorar token informado na query do histórico

**Descrição:**
Garantir que `GET /cliente/historico` consulta sempre o token da sessão, mesmo quando a query tenta informar outro token. O token alheio não pode chegar ao MS.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/historico` (query ignorada) → stub `/servicos/portal/os/*/historico`
**Pré-requisitos:** login com `TOKEN_OK`; token alheio de massa `TOKEN_ALVO_OK`; registro de chamadas do stub zerado

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/historico?cOsPublicId=TOKEN_ALVO_OK&cToken=TOKEN_ALVO_OK`
Então validar status 200
E validar que o stub recebeu exatamente uma chamada em `/servicos/portal/os/TOKEN_OK/historico`
Mas não validar nenhuma chamada com `TOKEN_ALVO_OK` na URL do histórico

---

### CT-API-07 — Repassar 422 do MS quando histórico está desligado

**Descrição:**
Garantir que, quando o MS responde 422 (histórico desligado na configuração da empresa), o BFF devolve 422 com envelope de erro, sem transformar em 200 com lista vazia.

**Tag:** [NOVO]
**Prioridade:** P1
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/historico` → stub `/servicos/portal/os/TOKEN_HISTORICO_422/historico` (422)
**Pré-requisitos:** login com `TOKEN_HISTORICO_422`

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_HISTORICO_422` e o stub responde 422 ao histórico
Quando consultar `GET /cliente/historico`
Então validar status 422
E validar `lSucesso: false` e `cMensagem` não vazia

---

### CT-API-08 — Devolver dados do cliente sem campo extra

**Descrição:**
Garantir que `GET /cliente/dados` devolve apenas os campos do schema estrito de `oCliente` (`cNome`, `cTelefone`, `cEmail`, `cDocumentoMascarado`, `cDocumentoTipo`). Campo extra vindo do MS (PII fora do contrato) não pode chegar ao front.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/dados` → stub `/servicos/portal/os/TOKEN_DADOS_CAMPO_EXTRA/cliente`
**Pré-requisitos:** login com `TOKEN_DADOS_CAMPO_EXTRA`; stub devolve `oCliente` com campo extra (ex.: `cCpfCompleto`)

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_DADOS_CAMPO_EXTRA` e o stub devolve `oCliente` com campo fora do schema
Quando consultar `GET /cliente/dados`
Então validar status 200 e cabeçalho `Cache-Control` igual a `no-store`
E validar que `oDados.oCliente` contém somente `cNome`, `cTelefone`, `cEmail`, `cDocumentoMascarado` e `cDocumentoTipo`
Mas não validar a presença do campo extra na resposta

---

### CT-API-09 — Detalhar OS do histórico autorizada pelo MS com flag do painel

**Descrição:**
Garantir que `GET /cliente/os/:id` com rota diferente da sessão chama o MS com `x-portal-token-origem` = token da sessão e, quando o MS autoriza, devolve a OS com `oFlagsPainel.historico` presente (o schema não pode descartar a chave).

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:cOsPublicId` (rota ≠ sessão) → stub `/servicos/portal/os/TOKEN_ALVO_OK/detalhe` com header `x-portal-token-origem`
**Pré-requisitos:** login com `TOKEN_OK`; stub autoriza `TOKEN_ALVO_OK` quando o header de origem é `TOKEN_OK` e devolve `oFlagsPainel.historico: true`

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/TOKEN_ALVO_OK`
Então validar status 200
E validar que a resposta contém `oFlagsPainel.historico` igual a `true`
E validar que o stub recebeu `GET /servicos/portal/os/TOKEN_ALVO_OK/detalhe` com `x-portal-token-origem: TOKEN_OK`, header `chaveapi` e `X-Cliente-IP`

---

### CT-API-10 — Negar OS do histórico com 403 uniforme quando MS nega

**Descrição:**
Garantir que, quando o MS nega o alvo com 403, o BFF responde 403 "Acesso não autorizado" (uniforme, anti-enumeração), sem repassar o código original do MS.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:id` (rota ≠ sessão) → stub `/servicos/portal/os/TOKEN_ALVO_NEGADO_403/detalhe` (403)
**Pré-requisitos:** login com `TOKEN_OK`; stub responde 403 para `TOKEN_ALVO_NEGADO_403` com header de origem

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/TOKEN_ALVO_NEGADO_403`
Então validar status 403
E validar `lSucesso: false` e `cMensagem` igual a "Acesso não autorizado"

---

### CT-API-11 — Negar OS do histórico com 403 uniforme quando link alvo está revogado

**Descrição:**
Garantir que, quando o MS responde 410 para o alvo (link revogado ou OS cancelada), o BFF responde o mesmo 403 "Acesso não autorizado" usado para 403, sem revelar a existência ou o motivo do alvo.

**Tag:** [NOVO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:id` (rota ≠ sessão) → stub `/servicos/portal/os/TOKEN_ALVO_NEGADO_410/detalhe` (410)
**Pré-requisitos:** login com `TOKEN_OK`; stub responde 410 para `TOKEN_ALVO_NEGADO_410` com header de origem

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/TOKEN_ALVO_NEGADO_410`
Então validar status 403
E validar `lSucesso: false` e `cMensagem` igual a "Acesso não autorizado"
Mas não validar status 410 na resposta

---

### CT-API-12 — Autorizar fotos de OS do histórico com header de origem

**Descrição:**
Garantir que `GET /cliente/os/:id/fotos` com rota diferente da sessão chama o MS com `x-portal-token-origem` = token da sessão e devolve 200 quando o MS autoriza. Cobre a rota de fotos, que usa o mesmo resolvedor de acesso do detalhe.

**Tag:** [NOVO]
**Prioridade:** P1
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:cOsPublicId/fotos` (rota ≠ sessão) → stub `/servicos/portal/os/TOKEN_ALVO_OK/fotos`
**Pré-requisitos:** login com `TOKEN_OK`; stub autoriza `TOKEN_ALVO_OK` com header de origem `TOKEN_OK`

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/TOKEN_ALVO_OK/fotos`
Então validar status 200
E validar que o stub recebeu `GET /servicos/portal/os/TOKEN_ALVO_OK/fotos` com `x-portal-token-origem: TOKEN_OK` e `X-Cliente-IP`

---

### CT-API-13 — Manter detalhe da OS própria sem header de origem

**Descrição:**
Garantir regressão: quando a rota é a própria OS da sessão, o BFF chama o MS sem `x-portal-token-origem` e o detalhe segue funcionando como antes.

**Tag:** [REGRESSÃO]
**Prioridade:** P0
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:id` (rota == sessão) → stub `/servicos/portal/os/TOKEN_OK/detalhe`
**Pré-requisitos:** login com `TOKEN_OK`; registro de chamadas do stub zerado

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/TOKEN_OK`
Então validar status 200
E validar que o stub recebeu `GET /servicos/portal/os/TOKEN_OK/detalhe` sem o header `x-portal-token-origem`
Mas não validar bloqueio de acesso na resposta

---

### CT-API-14 — Rejeitar cOsPublicId com mais de 64 caracteres

**Descrição:**
Garantir que `GET /cliente/os/:id` responde 400 quando o identificador da rota passa de 64 caracteres, antes de qualquer chamada ao MS.

**Tag:** [NOVO]
**Prioridade:** P1
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:cOsPublicId` (validação `.max(64)`)
**Pré-requisitos:** login com `TOKEN_OK`; registro de chamadas do stub zerado; id de 65 caracteres

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/{id}` com um identificador de 65 caracteres (ex.: `A` repetido 65 vezes)
Então validar status 400
E validar que o stub não recebeu chamada de detalhe para esse identificador

---

### CT-API-15 — Negar fotos de OS do histórico com 403 uniforme quando MS nega

**Descrição:**
Garantir que `GET /cliente/os/:id/fotos` com rota diferente da sessão devolve 403 «Acesso não autorizado» quando o MS nega o alvo (anti-enumeração), igual ao detalhe.

**Tag:** [NOVO]
**Prioridade:** P1
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:cOsPublicId/fotos` (rota ≠ sessão, MS nega) → stub `/servicos/portal/os/TOKEN_ALVO_NEGADO_403/fotos` responde 403
**Pré-requisitos:** login com `TOKEN_OK`; stub responde 403 em `/fotos` do `TOKEN_ALVO_NEGADO_403` quando vier `x-portal-token-origem`

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/TOKEN_ALVO_NEGADO_403/fotos`
Então validar status 403
E validar corpo `{ lSucesso: false, cMensagem: "Acesso não autorizado" }`

---

### CT-API-16 — Bloquear detalhe de OS sem cookie de sessão

**Descrição:**
Garantir que `GET /cliente/os/:id` sem cookie responde 401 sem consultar o MS (o resolvedor de acesso foi reescrito).

**Tag:** [NOVO]
**Prioridade:** P1
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:cOsPublicId` sem sessão
**Pré-requisitos:** nenhum cookie de sessão

**Cenário de teste:**
Dado que não existe cookie de sessão
Quando consultar `GET /cliente/os/TOKEN_ALVO_OK`
Então validar status 401
E validar que o stub não recebeu chamada de `/servicos/portal/os/TOKEN_ALVO_OK/detalhe`

---

### CT-API-17 — Manter fotos da OS própria sem header de origem e com IP do cliente

**Descrição:**
Regressão: `GET /cliente/os/:id/fotos` com rota igual à sessão continua 200, não envia `x-portal-token-origem` e passa a enviar `X-Cliente-IP` ao MS.

**Tag:** [REGRESSAO]
**Prioridade:** P2
**Modalidade:** automacao-api
**Cobre:** `GET /cliente/os/:cOsPublicId/fotos` (rota == sessão) → stub `/servicos/portal/os/TOKEN_OK/fotos`
**Pré-requisitos:** login com `TOKEN_OK`; stub devolve fotos para `TOKEN_OK`

**Cenário de teste:**
Dado que existe sessão ativa para `TOKEN_OK`
Quando consultar `GET /cliente/os/TOKEN_OK/fotos`
Então validar status 200
E validar que o stub recebeu `X-Cliente-IP` e não recebeu `x-portal-token-origem`

---

## 2. Smoke automatizado

N/A neste hop (WU Teste).

## 3. E2E — Caminho feliz

N/A neste hop (WU Teste).

## 4. E2E — Caminho negativo

N/A neste hop (WU Teste).

## 5. Manual (somente UI)

N/A neste hop (WU Teste). Nenhum CT manual: todos os CTs acima rodam por HTTP no BFF real com o stub.

---

**Status:** este documento aguarda aprovação humana (gate `aprovar_cenarios_pre_cr`) antes de seguir para automação.
