# LEIA-ME — Evidências QA_PRE_CR

Percorra os PNG na ordem numérica (`01-`, `02-`, …, `99-tela-final`).

| CT | Pasta | Sequência | O que cada imagem mostra |
|----|-------|-----------|--------------------------|
| CT-API-01 | `api/` | CT-API-01-response.json, CT-API-01-resumo.md | resposta da API + resumo do CT |
| CT-API-02 | `api/` | CT-API-02-response.json, CT-API-02-resumo.md | resposta da API + resumo do CT |
| CT-API-03 | `api/` | CT-API-03-response.json, CT-API-03-resumo.md | resposta da API + resumo do CT |
| CT-API-04 | `api/` | CT-API-04-response.json, CT-API-04-resumo.md | resposta da API + resumo do CT |
| CT-API-05 | `api/` | CT-API-05-response.json, CT-API-05-resumo.md | resposta da API + resumo do CT |
| CT-API-06 | `api/` | CT-API-06-response.json, CT-API-06-resumo.md | resposta da API + resumo do CT |
| CT-API-07 | `api/` | CT-API-07-response.json, CT-API-07-resumo.md | resposta da API + resumo do CT |
| CT-API-08 | `api/` | CT-API-08-response.json, CT-API-08-resumo.md | resposta da API + resumo do CT |
| CT-API-09 | `api/` | CT-API-09-response.json, CT-API-09-resumo.md | resposta da API + resumo do CT |
| CT-API-10 | `api/` | CT-API-10-response.json, CT-API-10-resumo.md | resposta da API + resumo do CT |
| CT-API-11 | `api/` | CT-API-11-response.json, CT-API-11-resumo.md | resposta da API + resumo do CT |
| CT-API-12 | `api/` | CT-API-12-response.json, CT-API-12-resumo.md | resposta da API + resumo do CT |
| CT-API-13 | `api/` | CT-API-13-response.json, CT-API-13-resumo.md | resposta da API + resumo do CT |
| CT-API-14 | `api/` | CT-API-14-response.json, CT-API-14-resumo.md | resposta da API + resumo do CT |
| CT-API-15 | `api/` | CT-API-15-response.json, CT-API-15-resumo.md | resposta da API + resumo do CT |
| CT-API-16 | `api/` | CT-API-16-response.json, CT-API-16-resumo.md | resposta da API + resumo do CT |
| CT-API-17 | `api/` | CT-API-17-response.json, CT-API-17-resumo.md | resposta da API + resumo do CT |

## API

- **CT-API-01:** `api/CT-API-01-response.json` + `api/CT-API-01-resumo.md`
- **CT-API-02:** `api/CT-API-02-response.json` + `api/CT-API-02-resumo.md`
- **CT-API-03:** `api/CT-API-03-response.json` + `api/CT-API-03-resumo.md`
- **CT-API-04:** `api/CT-API-04-response.json` + `api/CT-API-04-resumo.md`
- **CT-API-05:** `api/CT-API-05-response.json` + `api/CT-API-05-resumo.md`
- **CT-API-06:** `api/CT-API-06-response.json` + `api/CT-API-06-resumo.md`
- **CT-API-07:** `api/CT-API-07-response.json` + `api/CT-API-07-resumo.md`
- **CT-API-08:** `api/CT-API-08-response.json` + `api/CT-API-08-resumo.md`
- **CT-API-09:** `api/CT-API-09-response.json` + `api/CT-API-09-resumo.md`
- **CT-API-10:** `api/CT-API-10-response.json` + `api/CT-API-10-resumo.md`
- **CT-API-11:** `api/CT-API-11-response.json` + `api/CT-API-11-resumo.md`
- **CT-API-12:** `api/CT-API-12-response.json` + `api/CT-API-12-resumo.md`
- **CT-API-13:** `api/CT-API-13-response.json` + `api/CT-API-13-resumo.md`
- **CT-API-14:** `api/CT-API-14-response.json` + `api/CT-API-14-resumo.md`
- **CT-API-15:** `api/CT-API-15-response.json` + `api/CT-API-15-resumo.md`
- **CT-API-16:** `api/CT-API-16-response.json` + `api/CT-API-16-resumo.md`
- **CT-API-17:** `api/CT-API-17-response.json` + `api/CT-API-17-resumo.md`
