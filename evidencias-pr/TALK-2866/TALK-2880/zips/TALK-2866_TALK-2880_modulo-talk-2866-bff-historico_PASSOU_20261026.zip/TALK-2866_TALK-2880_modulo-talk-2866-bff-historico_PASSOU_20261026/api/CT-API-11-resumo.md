# CT-API-11

- **HTTP:** 403
- **URL:** http://127.0.0.1:18880/cliente/os/tokAlvoHist2880Revogado
- **Prova:** resposta da API conforme cenário.
