# CT-API-04

- **HTTP:** 401
- **URL:** http://127.0.0.1:18880/cliente/dados
- **Prova:** resposta da API conforme cenário.
