# CT-API-05

- **HTTP:** 200
- **URL:** http://127.0.0.1:18880/cliente/historico
- **Prova:** resposta da API conforme cenário.
