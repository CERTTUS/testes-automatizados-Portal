# CT-API-06

- **HTTP:** 200
- **URL:** http://127.0.0.1:18880/cliente/historico?cToken=tokAlvoHist2880Negado&cOsPublicId=tokAlvoHist2880Negado
- **Prova:** resposta da API conforme cenário.
