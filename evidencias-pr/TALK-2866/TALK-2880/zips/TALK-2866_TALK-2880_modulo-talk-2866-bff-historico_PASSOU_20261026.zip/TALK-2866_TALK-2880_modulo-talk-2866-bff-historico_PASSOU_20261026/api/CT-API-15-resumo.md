# CT-API-15

- **HTTP:** 403
- **URL:** http://127.0.0.1:18880/cliente/os/tokAlvoHist2880Negado/fotos
- **Prova:** resposta da API conforme cenário.
