# CT-API-09

- **HTTP:** 200
- **URL:** http://127.0.0.1:18880/cliente/os/tokAlvoHist2880Ok
- **Prova:** resposta da API conforme cenário.
