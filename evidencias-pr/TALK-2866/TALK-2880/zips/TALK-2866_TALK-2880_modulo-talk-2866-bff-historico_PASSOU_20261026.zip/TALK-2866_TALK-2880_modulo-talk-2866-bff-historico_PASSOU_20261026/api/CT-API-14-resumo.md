# CT-API-14

- **HTTP:** 400
- **URL:** http://127.0.0.1:18880/cliente/os/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
- **Prova:** resposta da API conforme cenário.
