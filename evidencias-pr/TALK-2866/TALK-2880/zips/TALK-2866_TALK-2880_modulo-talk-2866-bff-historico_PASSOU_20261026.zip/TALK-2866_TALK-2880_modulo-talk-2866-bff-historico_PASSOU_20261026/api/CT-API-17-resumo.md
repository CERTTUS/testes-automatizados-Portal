# CT-API-17

- **HTTP:** 200
- **URL:** http://127.0.0.1:18880/cliente/os/tokSessaoHist2880Ok/fotos
- **Prova:** resposta da API conforme cenário.
