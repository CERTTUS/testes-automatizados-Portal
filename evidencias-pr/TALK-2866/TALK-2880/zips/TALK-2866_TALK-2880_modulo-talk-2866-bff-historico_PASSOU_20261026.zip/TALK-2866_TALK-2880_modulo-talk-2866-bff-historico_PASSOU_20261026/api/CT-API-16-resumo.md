# CT-API-16

- **HTTP:** 401
- **URL:** http://127.0.0.1:18880/cliente/os/tokAlvoHist2880Ok
- **Prova:** resposta da API conforme cenário.
