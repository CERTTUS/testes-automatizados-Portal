# Validação unitária (Vitest) — TALK-2880

- Script: `qa-validar-unitarios.py --git-diff --base HEAD` → `missingTests: []` (6 arquivos de lógica analisados).
- Execução: `npx vitest run` no portalcliente-api → **120/120 passaram**, 0 falhas (`jest/vitest-result.json`, `jest/run.log`).
- Observação: `--run-tests` do script passa `--watchAll` (flag do Jest), que o Vitest não aceita; a execução foi feita à parte.
- Veredito: **OK**.
