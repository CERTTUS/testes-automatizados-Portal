# resultado-execucao-dev

> Dev: `TALK-2771` | HU: `TALK-2637` | Módulo: `modulo-talk-2638`
> Data: 2026-10-09T18:37:27.103Z

Veredito: **PASSOU**

Comando: `npm run test:pre-cr (specs) -- --modulo modulo-talk-2638 --dev-key TALK-2771 --parent-key TALK-2637`
Ambiente: `local`

---

## O que foi testado (linguagem de tela)

- CT-API-01 — Landing com tokens derivados
- CT-API-02 — Landing sem tokens (fail-open)
- CT-SMK-01 — Tela de acesso com marca
- CT-SMK-02 — Tema aplicado na landing
- CT-SMK-03 — Link revogado sem formulário
- CT-SMK-04 — Shell autenticado com menu (TALK-2669 / D4_v2)
- CT-SMK-05 — Painel detalhe com evolução (TALK-2671 / D4_v2)
- CT-SMK-06 — Painel sem timeline (TALK-2671 / FR-016)

E2E e checklist manual: WU Teste (não executados neste hop).

---

## Resumo

| Métrica | Valor |
|---------|-------|
| Jest | 0 com prova |
| API | 2 com prova |
| Smoke | 6 com prova |
| Duração | — |

---

## Evidências por CT (obrigatório no PASS)

| CT | Tipo | Status | Arquivo de prova |
|----|------|--------|------------------|
| CT-API-01 | api | PASSOU | `api/CT-API-01-response.json` |
| CT-API-02 | api | PASSOU | `api/CT-API-02-response.json` |
| CT-SMK-01 | smoke | PASSOU | `smoke/prints/CT-SMK-01/99-tela-final.png` |
| CT-SMK-02 | smoke | PASSOU | `smoke/prints/CT-SMK-02/99-tela-final.png` |
| CT-SMK-03 | smoke | PASSOU | `smoke/prints/CT-SMK-03/99-tela-final.png` |
| CT-SMK-04 | smoke | PASSOU | `smoke/prints/CT-SMK-04/99-tela-final.png` |
| CT-SMK-05 | smoke | PASSOU | `smoke/prints/CT-SMK-05/99-tela-final.png` |
| CT-SMK-06 | smoke | PASSOU | `smoke/prints/CT-SMK-06/99-tela-final.png` |
